<?php
/**
 * KG Database Management uninstall handler.
 * Data is preserved unless the site administrator explicitly confirmed
 * delete_data_on_uninstall in the plugin Settings screen. A clean reinstall gets
 * a new install-generation cache namespace and cannot read data from old cache keys.
 */
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

/** Remove only KGDM-owned data for the currently selected WordPress site. */
$kgdm_uninstall_current_site = static function () {
        global $wpdb;

        $settings = get_option('kgdm_settings', array());
        if (!is_array($settings) || (int)($settings['delete_data_on_uninstall'] ?? 0) !== 1) {
            return;
        }

        // Fixed plugin suffixes, prefixed by the active site's trusted WordPress table prefix.
        $table_suffixes = array(
            'kgdm_records',
            'kgdm_template_versions',
            'kgdm_migration_records',
            'kgdm_migrations',
            'kgdm_collections',
            'kgdm_databases',
        );
        foreach ($table_suffixes as $suffix) {
            $table = $wpdb->prefix . $suffix;
            $wpdb->query($wpdb->prepare('DROP TABLE IF EXISTS %i', $table)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange -- Required one-shot cleanup of only KGDM tables after explicit administrator consent.
        }

        // Enumerate only KGDM-owned options and transients. WordPress APIs keep caches in sync.
        if (!empty($wpdb->options)) {
            $kgdm_options = $wpdb->esc_like('kgdm_') . '%';
            $transient_values = $wpdb->esc_like('_transient_kgdm_') . '%';
            $transient_timeouts = $wpdb->esc_like('_transient_timeout_kgdm_') . '%';
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- One-shot uninstall cleanup reads only KGDM-prefixed option names and deletes them through WordPress APIs.
            $option_names = $wpdb->get_col($wpdb->prepare(
                'SELECT option_name FROM %i WHERE option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s',
                $wpdb->options,
                $kgdm_options,
                $transient_values,
                $transient_timeouts
            ));
            foreach ((array)$option_names as $option_name) {
                $option_name = (string)$option_name;
                if (strpos($option_name, '_transient_timeout_kgdm_') === 0) {
                    $transient_name = substr($option_name, strlen('_transient_timeout_'));
                    delete_transient($transient_name);
                    delete_option($option_name);
                } elseif (strpos($option_name, '_transient_kgdm_') === 0) {
                    $transient_name = substr($option_name, strlen('_transient_'));
                    delete_transient($transient_name);
                } elseif (strpos($option_name, 'kgdm_') === 0) {
                    delete_option($option_name);
                }
            }
        }

        // This legacy V1 payload is owned by KGDM's migration bridge.
        delete_option('kg_genshin_db_manager_v1');

        // Remove the old object-cache group when the backend supports group flush.
        // The install-generation marker is also deleted by the KGDM option sweep;
        // the next activation creates a fresh namespace even on backends without it.
        if (function_exists('wp_cache_flush_group')) {
            wp_cache_flush_group('kgdm_query');
        }

        // Full backup archives are plugin-owned files. Delete only KGDM's private
        // backup directory when the explicit uninstall deletion policy is enabled.
        $content_dir = defined('WP_CONTENT_DIR') ? WP_CONTENT_DIR : (rtrim(ABSPATH, '/\\') . '/wp-content');
        $backup_site_id = function_exists('get_current_blog_id') ? (int)get_current_blog_id() : 1;
        $backup_dir = trailingslashit($content_dir) . 'kgdm-private-backups-site-' . max(1, $backup_site_id);
        $backup_dir = apply_filters('kgdm_backup_directory', $backup_dir, $backup_site_id);
        $real_content = realpath($content_dir);
        $real_backup = is_string($backup_dir) ? realpath($backup_dir) : false;
        if ($real_content && $real_backup && strpos($real_backup, trailingslashit($real_content)) === 0 && basename($real_backup) === 'kgdm-private-backups-site-' . max(1, $backup_site_id)) {
            if (!function_exists('WP_Filesystem')) {
                require_once ABSPATH . 'wp-admin/includes/file.php';
            }
            if (WP_Filesystem()) {
                global $wp_filesystem;
                $wp_filesystem->delete($real_backup, true);
            }
        }

        // Do not delete Media Library attachments/files, posts, users, or any unrelated WordPress/site data.
};

if (is_multisite()) {
    $kgdm_uninstall_offset = 0;
    $kgdm_uninstall_batch_size = 100;
    do {
        $kgdm_uninstall_site_ids = get_sites(array(
            'fields' => 'ids',
            'number' => $kgdm_uninstall_batch_size,
            'offset' => $kgdm_uninstall_offset,
            'orderby' => 'id',
            'order' => 'ASC',
        ));
        foreach ((array)$kgdm_uninstall_site_ids as $kgdm_uninstall_site_id) {
            switch_to_blog((int)$kgdm_uninstall_site_id);
            $kgdm_uninstall_current_site();
            restore_current_blog();
        }
        $kgdm_uninstall_count = count((array)$kgdm_uninstall_site_ids);
        $kgdm_uninstall_offset += $kgdm_uninstall_batch_size;
    } while ($kgdm_uninstall_count === $kgdm_uninstall_batch_size);
} else {
    $kgdm_uninstall_current_site();
}
