<?php
/**
 * Plugin Name: KG Database Management
 * Description: A structured, template-driven database manager for WordPress.
 * Version: 3.2.24
 * Requires at least: 7.0
 * Requires PHP: 7.4
 * Author: KG
 * License: GPL-2.0-or-later
 * Text Domain: kg-database-management
 */

if (!defined('ABSPATH')) { exit; }

// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- KGDM owns normalized relational tables and uses $wpdb for scoped queries, schema checks, and atomic migrations/backups. The public get()/find() paths are object-cached; admin and maintenance reads remain current, and mutations invalidate affected cache generations.
if (!class_exists('KG_Database_Management')) {
final class KG_Database_Management {
    const VERSION = '3.2.24';
    const SCHEMA_VERSION = '2.8.0';
    const MIGRATION_ENGINE_VERSION = 1;
    const PLUGIN_VERSION_OPTION = 'kgdm_plugin_version';
    const RELEASE_MIGRATION_OPTION = 'kgdm_release_migration_ledger';
    const UPDATE_HISTORY_OPTION = 'kgdm_update_history';
    const UPDATE_LOCK_OPTION = 'kgdm_upgrade_lock';
    const UPDATE_LOCK_TTL = 1800;
    const JSON_STORAGE_VERSION = 1;
    const MAX_JSON_DEPTH = 64;
    const ACTIVE_DB_OPTION = 'kgdm_active_database';
    const SCHEMA_OPTION = 'kgdm_schema_version';
    const V1_OPTION = 'kg_genshin_db_manager_v1';
    const MAX_IMPORT_BYTES = 26214400; // 25 MB.
    const MAX_BACKUP_FILE_BYTES = 268435456; // 256 MB compressed/uploaded.
    const MAX_BACKUP_CONTENT_BYTES = 536870912; // 512 MB uncompressed.
    const BACKUP_INDEX_OPTION = 'kgdm_backup_index';
    const MENU_SLUG = 'kg-database-management';
    const QUERY_CACHE_GROUP = 'kgdm_query';
    const QUERY_CACHE_VERSION = 3;
    const QUERY_CACHE_TTL = 300;
    const QUERY_CACHE_RECORD_MAX_BYTES = 1048576; // Do not put individual records larger than 1 MB into object cache.
    const QUERY_CACHE_RESULT_MAX_BYTES = 2097152; // Keep filtered result sets below 2 MB.
    const QUERY_CACHE_COLLECTION_MAX_BYTES = 4194304; // Keep whole-collection cache entries below 4 MB.
    const QUERY_CACHE_COLLECTION_LIMIT = 5000;
    const QUERY_CACHE_GLOBAL_EPOCH_OPTION = 'kgdm_query_cache_epoch';
    const QUERY_CACHE_COLLECTION_EPOCH_PREFIX = 'kgdm_query_cache_collection_';

    private static $instance = null;

    /**
     * Public PHP query API for WordPress snippets and integrations.
     * get() resolves one record by stable record ID; find() filters records by
     * field values/search text and can use the WordPress object cache.
     */
    public function get($database_id, $collection_slug, $record_id, $args = array()) {
        $database_id = sanitize_key((string)$database_id);
        $collection_slug = sanitize_title((string)$collection_slug);
        $record_id = sanitize_title((string)$record_id);
        if ($database_id === '' || $collection_slug === '' || $record_id === '') { return null; }
        $args = is_array($args) ? $args : array();
        $include_deleted = !empty($args['include_deleted']) && current_user_can('manage_options');
        $cache_key = self::query_cache_key('record', $database_id, $collection_slug, array($record_id, $include_deleted ? 1 : 0));
        $cached = wp_cache_get($cache_key, self::QUERY_CACHE_GROUP);
        if (is_array($cached) && ($cached['__kgdm_cache_envelope'] ?? '') === 'record' && array_key_exists('value', $cached)) {
            $cached_record = $cached['value'];
            if (is_array($cached_record) && !current_user_can('manage_options')) {
                if (!self::record_is_public_live($cached_record)) { return null; }
                return self::public_record_payload($cached_record);
            }
            return $cached_record;
        }
        $record = self::get_admin_record($database_id, $collection_slug, $record_id, $include_deleted);
        if (!is_array($record)) { return null; }
        $cache_record = $record;
        if (!current_user_can('manage_options')) {
            if (!self::record_is_public_live($record)) { return null; }
            $record = self::public_record_payload($record);
        }
        $encoded = wp_json_encode($cache_record);
        if (is_string($encoded) && strlen($encoded) <= self::QUERY_CACHE_RECORD_MAX_BYTES) {
            wp_cache_set($cache_key, array('__kgdm_cache_envelope'=>'record', 'value'=>$cache_record), self::QUERY_CACHE_GROUP, self::QUERY_CACHE_TTL);
        }
        return $record;
    }

    public function find($database_id, $collection_slug, $args = array()) {
        $database_id = sanitize_key((string)$database_id);
        $collection_slug = sanitize_title((string)$collection_slug);
        if ($database_id === '' || $collection_slug === '') { return array(); }
        $args = is_array($args) ? $args : array();
        $include_deleted = !empty($args['include_deleted']) && current_user_can('manage_options');
        $where = isset($args['where']) && is_array($args['where']) ? $args['where'] : array();
        $search = self::query_lower(trim((string)($args['search'] ?? '')));
        $section = sanitize_title((string)($args['section'] ?? ''));
        if ($section !== '') {
            $section_collection = self::get_collection($database_id, $collection_slug, false);
            $section_slugs = array_map(static function($term){ return (string)($term['slug'] ?? ''); }, (array)($section_collection['sections'] ?? array()));
            if (!in_array($section, $section_slugs, true)) { return array(); }
        }
        $limit = isset($args['limit']) ? min(1000, max(0, absint($args['limit']))) : 0;
        $offset = isset($args['offset']) ? max(0, absint($args['offset'])) : 0;
        $order_by = self::sanitize_query_path((string)($args['order_by'] ?? 'name'));
        if ($order_by === '') { $order_by = 'name'; }
        $order = strtoupper((string)($args['order'] ?? 'ASC')) === 'DESC' ? 'DESC' : 'ASC';
        $use_cache = !array_key_exists('cache', $args) || !empty($args['cache']);
        $normalized_cache_args = array(
            'include_deleted'=>$include_deleted ? 1 : 0,
            'where'=>$where,
            'search'=>$search,
            'section'=>$section,
            'limit'=>$limit,
            'offset'=>$offset,
            'order_by'=>$order_by,
            'order'=>$order,
        );
        $cache_key = self::query_cache_key('find', $database_id, $collection_slug, $normalized_cache_args);
        if ($use_cache && $cache_key !== '') {
            $cached = wp_cache_get($cache_key, self::QUERY_CACHE_GROUP);
            if (is_array($cached) && ($cached['__kgdm_cache_envelope'] ?? '') === 'find' && isset($cached['value']) && is_array($cached['value'])) {
                $cached_records = $cached['value'];
                if (!current_user_can('manage_options')) { foreach ($cached_records as $cached_id => $cached_record) { if (!is_array($cached_record) || !self::record_is_public_live($cached_record)) { unset($cached_records[$cached_id]); } else { $cached_records[$cached_id] = self::public_record_payload($cached_record); } } }
                return $cached_records;
            }
        }

        $records = self::get_cached_collection_records($database_id, $collection_slug, $include_deleted);
        $out = array();
        foreach ($records as $id => $record) {
            if (!is_array($record)) { continue; }
            if (!current_user_can('manage_options') && !self::record_is_public_live($record)) { continue; }
            if ($section !== '' && !in_array($section, (array)($record['_kgdm_sections'] ?? array()), true)) { continue; }
            $filter_record = current_user_can('manage_options') ? $record : self::public_record_payload($record);
            if (!empty($where) && !self::record_matches_where($filter_record, $where)) { continue; }
            if ($search !== '') {
                $encoded_record = wp_json_encode($filter_record);
                $haystack = self::query_lower(is_string($encoded_record) ? $encoded_record : serialize($filter_record));
                if (strpos($haystack, $search) === false && strpos(self::query_lower((string)$id), $search) === false) { continue; }
            }
            $out[(string)$id] = $record;
        }

        // Resolve nested sort paths once per record rather than once per comparison.
        $sort_values = array();
        foreach ($out as $id => $record) {
            $sort_values[$id] = $order_by === 'id' ? (string)$id : self::query_path_value($record, $order_by, null);
        }
        uksort($out, function($a, $b) use ($sort_values, $order) {
            $cmp = self::query_compare_values($sort_values[$a] ?? null, $sort_values[$b] ?? null);
            if ($cmp === 0) { $cmp = strnatcasecmp((string)$a, (string)$b); }
            return $order === 'DESC' ? -$cmp : $cmp;
        });

        if ($offset > 0 || $limit > 0) { $out = array_slice($out, $offset, $limit > 0 ? $limit : null, true); }
        if ($use_cache && $cache_key !== '') {
            $encoded_result = wp_json_encode($out);
            if (is_string($encoded_result) && strlen($encoded_result) <= self::QUERY_CACHE_RESULT_MAX_BYTES) {
                // Cache the full admin payload. Public callers receive a sanitized copy below.
                wp_cache_set($cache_key, array('__kgdm_cache_envelope'=>'find', 'value'=>$out), self::QUERY_CACHE_GROUP, self::QUERY_CACHE_TTL);
            }
        }
        if (!current_user_can('manage_options')) {
            foreach ($out as $id => $record) { $out[$id] = self::public_record_payload($record); }
        }
        return $out;
    }

    /** Invalidate one collection or every KGDM query without flushing unrelated cache groups. */
    public function clear_query_cache($database_id = '', $collection_slug = '') {
        if ($database_id !== '' && $collection_slug !== '') {
            self::invalidate_collection_query_cache(sanitize_key((string)$database_id), sanitize_title((string)$collection_slug));
        } else {
            self::invalidate_all_query_cache();
        }
        return true;
    }

    private static function query_cache_key($type, $database_id, $collection_slug, $parts = array()) {
        $site_id = function_exists('get_current_blog_id') ? (int)get_current_blog_id() : 1;
        $collection_epoch_key = self::QUERY_CACHE_COLLECTION_EPOCH_PREFIX . md5($site_id . '|' . $database_id . '|' . $collection_slug);
        $scope = array(
            'site'=>$site_id,
            'version'=>self::QUERY_CACHE_VERSION,
            'access_scope'=>current_user_can('manage_options') ? 'admin' : 'public',
            // Distinguishes a clean reinstall from a prior installation even when
            // a persistent object cache still contains old entries with the same IDs.
            'install_generation'=>(string)get_option('kgdm_install_generation', 'legacy-install'),
            'global_epoch'=>(string)get_option(self::QUERY_CACHE_GLOBAL_EPOCH_OPTION, '1'),
            'collection_epoch'=>(string)get_option($collection_epoch_key, '1'),
        );
        $json = wp_json_encode(array($scope, (string)$type, $parts));
        if (!is_string($json)) { return ''; }
        return 'v' . self::QUERY_CACHE_VERSION . ':' . md5($json);
    }

    private static function invalidate_all_query_cache() {
        update_option(self::QUERY_CACHE_GLOBAL_EPOCH_OPTION, wp_generate_uuid4(), false);
        return true;
    }

    private static function invalidate_collection_query_cache($database_id, $collection_slug) {
        if ($database_id === '' || $collection_slug === '') { return self::invalidate_all_query_cache(); }
        $site_id = function_exists('get_current_blog_id') ? (int)get_current_blog_id() : 1;
        $key = self::QUERY_CACHE_COLLECTION_EPOCH_PREFIX . md5($site_id . '|' . $database_id . '|' . $collection_slug);
        update_option($key, wp_generate_uuid4(), false);
        return true;
    }

    private static function get_cached_collection_records($database_id, $collection_slug, $include_deleted = false) {
        $key = self::query_cache_key('collection', $database_id, $collection_slug, array($include_deleted ? 1 : 0));
        if ($key !== '') {
            $cached = wp_cache_get($key, self::QUERY_CACHE_GROUP);
            if (is_array($cached) && ($cached['__kgdm_cache_envelope'] ?? '') === 'collection' && isset($cached['value']) && is_array($cached['value'])) {
                return $cached['value'];
            }
        }
        $records = self::db_records($database_id, $collection_slug, $include_deleted ? 'all' : 'active');
        if ($key !== '' && is_array($records) && count($records) <= self::QUERY_CACHE_COLLECTION_LIMIT) {
            $encoded_records = wp_json_encode($records);
            if (is_string($encoded_records) && strlen($encoded_records) <= self::QUERY_CACHE_COLLECTION_MAX_BYTES) {
                wp_cache_set($key, array('__kgdm_cache_envelope'=>'collection', 'value'=>$records), self::QUERY_CACHE_GROUP, self::QUERY_CACHE_TTL);
            }
        }
        return is_array($records) ? $records : array();
    }

    private static function flush_record_cache($database_id, $collection_slug, $record_id = '') {
        // Versioned keys make invalidation constant-time and collection-scoped.
        // Old entries expire naturally; unrelated databases retain their warm cache.
        self::invalidate_collection_query_cache($database_id, $collection_slug);
    }

    private static function sanitize_query_path($path) {
        $path = trim((string)$path);
        if ($path === '' || strlen($path) > 191) { return ''; }
        $parts = explode('.', $path);
        $clean = array();
        foreach ($parts as $part) {
            if ($part === '') { return ''; }
            $segment = sanitize_key($part);
            if ($segment === '' || $segment !== $part) { return ''; }
            $clean[] = $segment;
        }
        return implode('.', $clean);
    }

    private static function query_lower($value) {
        $value = (string)$value;
        return function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
    }

    private static function query_boolean_value($value) {
        if (is_bool($value)) { return $value; }
        if (is_int($value) || is_float($value)) {
            if ((float)$value === 0.0) { return false; }
            if ((float)$value === 1.0) { return true; }
            return null;
        }
        if (is_string($value)) {
            $value = strtolower(trim($value));
            if (in_array($value, array('1','true','yes','on'), true)) { return true; }
            if (in_array($value, array('0','false','no','off',''), true)) { return false; }
        }
        return null;
    }

    private static function query_compare_values($a, $b) {
        if ($a === $b) { return 0; }
        if ($a === null) { return -1; }
        if ($b === null) { return 1; }
        if (is_bool($a) || is_bool($b)) {
            $bool_a = self::query_boolean_value($a);
            $bool_b = self::query_boolean_value($b);
            if ($bool_a !== null && $bool_b !== null) { return ((int)$bool_a <=> (int)$bool_b); }
        }
        if (is_numeric($a) && is_numeric($b)) { return ((float)$a <=> (float)$b); }
        if (is_array($a)) { $a = wp_json_encode($a); }
        if (is_array($b)) { $b = wp_json_encode($b); }
        return strnatcasecmp((string)$a, (string)$b);
    }

    private static function query_path_value($record, $path, $default = null) {
        $parts = explode('.', (string)$path);
        $value = $record;
        foreach ($parts as $part) {
            if (!is_array($value) || !array_key_exists($part, $value)) { return $default; }
            $value = $value[$part];
        }
        return $value;
    }

    private static function query_path_exists($record, $path) {
        $parts = explode('.', (string)$path);
        $value = $record;
        foreach ($parts as $part) {
            if (!is_array($value) || !array_key_exists($part, $value)) { return false; }
            $value = $value[$part];
        }
        return true;
    }

    private static function query_values_equal($actual, $expected) {
        if ($actual === $expected) { return true; }
        if ($actual === null || $expected === null) { return false; }
        if (is_bool($actual) || is_bool($expected)) {
            $bool_actual = self::query_boolean_value($actual);
            $bool_expected = self::query_boolean_value($expected);
            return $bool_actual !== null && $bool_expected !== null && $bool_actual === $bool_expected;
        }
        if (is_numeric($actual) && is_numeric($expected)) { return (float)$actual === (float)$expected; }
        if (is_array($actual) || is_array($expected)) {
            $actual_json = wp_json_encode($actual);
            $expected_json = wp_json_encode($expected);
            return is_string($actual_json) && is_string($expected_json) && $actual_json === $expected_json;
        }
        if (!is_scalar($actual) || !is_scalar($expected)) { return false; }
        return (string)$actual === (string)$expected;
    }

    private static function record_matches_where($record, $where) {
        foreach ($where as $path => $condition) {
            $path = self::sanitize_query_path((string)$path);
            if ($path === '') { return false; }
            $exists = self::query_path_exists($record, $path);
            $operator = is_array($condition) && isset($condition['operator']) ? strtolower((string)$condition['operator']) : 'eq';
            $expected = (is_array($condition) && array_key_exists('operator', $condition)) ? ($condition['value'] ?? null) : $condition;
            if (!in_array($operator, array('eq','contains','in','not_in','exists','gt','gte','lt','lte'), true)) { return false; }
            if ($operator === 'exists') {
                $expected_exists = self::query_boolean_value($expected);
                if ($expected_exists === null) { $expected_exists = (bool)$expected; }
                if ($exists !== $expected_exists) { return false; }
                continue;
            }
            // A missing path is not the same as an explicitly stored null or empty string.
            if (!$exists) { return false; }
            $actual = self::query_path_value($record, $path, null);
            if ($operator === 'contains') {
                if (is_array($actual)) {
                    $found = false;
                    foreach ($actual as $item) { if (self::query_values_equal($item, $expected)) { $found = true; break; } }
                    if (!$found) { return false; }
                } elseif (is_scalar($actual) && is_scalar($expected)) {
                    $haystack = self::query_lower((string)$actual);
                    $needle = self::query_lower((string)$expected);
                    if (function_exists('mb_strpos')) { if (mb_strpos($haystack, $needle, 0, 'UTF-8') === false) { return false; } }
                    elseif (strpos($haystack, $needle) === false) { return false; }
                } else { return false; }
            } elseif ($operator === 'in') {
                $list = is_array($expected) ? $expected : array($expected);
                $found = false;
                foreach ($list as $item) { if (self::query_values_equal($actual, $item)) { $found = true; break; } }
                if (!$found) { return false; }
            } elseif ($operator === 'not_in') {
                $list = is_array($expected) ? $expected : array($expected);
                foreach ($list as $item) { if (self::query_values_equal($actual, $item)) { return false; } }
            } elseif ($operator === 'gt' || $operator === 'gte' || $operator === 'lt' || $operator === 'lte') {
                if (!is_numeric($actual) || !is_numeric($expected)) { return false; }
                $a = (float)$actual; $e = (float)$expected;
                if (($operator === 'gt' && !($a > $e)) || ($operator === 'gte' && !($a >= $e)) || ($operator === 'lt' && !($a < $e)) || ($operator === 'lte' && !($a <= $e))) { return false; }
            } else {
                if (!self::query_values_equal($actual, $expected)) { return false; }
            }
        }
        return true;
    }

    public static function api_get_databases($include_archived = false) { return self::get_databases($include_archived); }
    public static function api_get_database($id = null) { if ($id === null || $id === '') { $id = get_option(self::ACTIVE_DB_OPTION, ''); } return self::get_database($id, false); }
    public static function api_get_collections($database_id = null, $include_archived = false) { if ($database_id === null || $database_id === '') { $database_id = get_option(self::ACTIVE_DB_OPTION, ''); } return self::get_collections($database_id, $include_archived); }
    public static function api_get_records($database_id, $collection_slug, $args = array()) {
        if ($database_id === null || $database_id === '') { $database_id = get_option(self::ACTIVE_DB_OPTION, ''); }
        $database = self::get_database($database_id, false);
        $collection = self::get_collection($database_id, $collection_slug, false);
        if (!$database || !$collection) { return array(); }
        $limit = isset($args['limit']) ? min(1000, max(0, absint($args['limit']))) : 0;
        $offset = isset($args['offset']) ? max(0, absint($args['offset'])) : 0;
        $search = isset($args['search']) ? self::query_lower(trim((string)$args['search'])) : '';
        $section = sanitize_title((string)($args['section'] ?? ''));
        if ($section !== '') {
            $section_slugs = array_map(static function($term){ return (string)($term['slug'] ?? ''); }, (array)($collection['sections'] ?? array()));
            if (!in_array($section, $section_slugs, true)) { return array(); }
        }
        // Deleted records are an administrative workflow; never expose them through
        // public REST or PHP helper calls made by visitors.
        $include_deleted = !empty($args['include_deleted']) && current_user_can('manage_options');
        $records = self::get_admin_records($database_id, $collection_slug, $include_deleted);
        foreach ($records as $id => $record) {
            if (!is_array($record)) { unset($records[$id]); continue; }
            if (!current_user_can('manage_options')) {
                if (!self::record_is_public_live($record)) { unset($records[$id]); continue; }
                $record = self::public_record_payload($record);
            }
            if ($section !== '' && !in_array($section, (array)($record['_kgdm_sections'] ?? array()), true)) { unset($records[$id]); continue; }
            if ($search !== '') {
                $encoded = wp_json_encode($record);
                $haystack = self::query_lower(is_string($encoded) ? $encoded : serialize($record));
                if (strpos($haystack, $search) === false && strpos(self::query_lower((string)$id), $search) === false) { unset($records[$id]); continue; }
            }
            // foreach iterates by value: write the sanitized public payload back so
            // private publication dates never leak from this helper response.
            $records[$id] = $record;
        }
        if ($limit > 0) { $records = array_slice($records, $offset, $limit, true); }
        elseif ($offset > 0) { $records = array_slice($records, $offset, null, true); }
        return $records;
    }
    public static function api_get_record($database_id, $collection_slug, $record_id) { $record = self::get_admin_record($database_id, $collection_slug, $record_id, false); if (!is_array($record)) { return null; } if (current_user_can('manage_options')) { return $record; } return self::record_is_public_live($record) ? self::public_record_payload($record) : null; }

    public static function boot() {
        if (self::$instance === null) { self::$instance = new self(); }
        add_action('plugins_loaded', array(self::$instance, 'maybe_upgrade'), 2);
        add_action('admin_menu', array(self::$instance, 'admin_menu'));
        add_action('admin_enqueue_scripts', array(self::$instance, 'enqueue_admin_assets'));
        add_action('admin_post_kgdm_create_database', array(self::$instance, 'handle_create_database'));
        add_action('admin_post_kgdm_update_database', array(self::$instance, 'handle_update_database'));
        add_action('admin_post_kgdm_archive_database', array(self::$instance, 'handle_archive_database'));
        add_action('admin_post_kgdm_restore_database', array(self::$instance, 'handle_restore_database'));
        add_action('admin_post_kgdm_purge_database', array(self::$instance, 'handle_purge_database'));
        add_action('admin_post_kgdm_set_active_database', array(self::$instance, 'handle_set_active_database'));
        add_action('admin_post_kgdm_save_collection', array(self::$instance, 'handle_save_collection'));
        add_action('admin_post_kgdm_preview_collection', array(self::$instance, 'handle_preview_collection'));
        add_action('admin_post_kgdm_apply_collection', array(self::$instance, 'handle_apply_collection'));
        add_action('admin_post_kgdm_cancel_collection_preview', array(self::$instance, 'handle_cancel_collection_preview'));
        add_action('admin_post_kgdm_restore_template_revision', array(self::$instance, 'handle_restore_template_revision'));
        add_action('admin_post_kgdm_rollback_migration', array(self::$instance, 'handle_rollback_migration'));
        add_action('admin_post_kgdm_archive_collection', array(self::$instance, 'handle_archive_collection'));
        add_action('admin_post_kgdm_restore_collection', array(self::$instance, 'handle_restore_collection'));
        add_action('admin_post_kgdm_delete_collection', array(self::$instance, 'handle_delete_collection'));
        add_action('admin_post_kgdm_save_record', array(self::$instance, 'handle_save_record'));
        add_action('admin_post_kgdm_bulk_update_records', array(self::$instance, 'handle_bulk_update_records'));
        add_action('kgdm_record_visibility_transition', array(self::$instance, 'handle_record_visibility_transition'), 10, 3);
        add_action('admin_post_kgdm_delete_record', array(self::$instance, 'handle_delete_record'));
        add_action('admin_post_kgdm_restore_record', array(self::$instance, 'handle_restore_record'));
        add_action('admin_post_kgdm_purge_record', array(self::$instance, 'handle_purge_record'));
        add_action('admin_post_kgdm_bulk_trash_action', array(self::$instance, 'handle_bulk_trash_action'));
        add_action('admin_post_kgdm_import', array(self::$instance, 'handle_import'));
        add_action('admin_post_kgdm_export', array(self::$instance, 'handle_export'));
        add_action('admin_post_kgdm_validate_json_storage', array(self::$instance, 'handle_validate_json_storage'));
        add_action('admin_post_kgdm_set_api_access', array(self::$instance, 'handle_set_api_access'));
        add_action('admin_post_kgdm_save_settings', array(self::$instance, 'handle_save_settings'));
        add_action('admin_post_kgdm_retry_upgrade', array(self::$instance, 'handle_retry_upgrade'));
        add_action('admin_post_kgdm_create_backup', array(self::$instance, 'handle_create_backup'));
        add_action('admin_post_kgdm_download_backup', array(self::$instance, 'handle_download_backup'));
        add_action('admin_post_kgdm_restore_backup', array(self::$instance, 'handle_restore_backup'));
        add_action('admin_post_kgdm_delete_backup', array(self::$instance, 'handle_delete_backup'));
        add_action('admin_post_kgdm_upload_backup', array(self::$instance, 'handle_upload_backup'));
        add_action('wp_ajax_kgdm_record_ajax', array(self::$instance, 'ajax_record_action'));
        add_action('wp_ajax_kgdm_set_appearance', array(self::$instance, 'ajax_set_appearance'));
        add_action('rest_api_init', array(self::$instance, 'register_rest_routes'));
        add_filter('kg_genshin_master_data_filter', array(self::$instance, 'filter_genshin_master_data'), 30, 1);
        return self::$instance;
    }

    public static function activate() {
        if (self::run_upgrade(true)) { self::deactivate_previous_plugins(); }
    }

    /**
     * Automatic plugin updates do not invoke the activation hook. Compare both the
     * release version and storage schema on plugins_loaded so an update-in-place
     * is completed before KGDM starts serving its normal UI/API requests.
     */
    public function maybe_upgrade() {
        $installed_release = (string)get_option(self::PLUGIN_VERSION_OPTION, '');
        $installed_schema = (string)get_option(self::SCHEMA_OPTION, '');
        $installed_engine = (int)get_option('kgdm_migration_engine_version', 0);
        if ($installed_release === self::VERSION && $installed_schema === self::SCHEMA_VERSION && $installed_engine === self::MIGRATION_ENGINE_VERSION) {
            return;
        }
        if (get_transient('kgdm_upgrade_retry_after')) {
            return;
        }
        self::run_upgrade(false);
    }

    private static function verify_schema() {
        global $wpdb;
        $tables = self::table_names();
        foreach ($tables as $table) {
            $found = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
            if ((string)$found !== (string)$table) {
                return new WP_Error('kgdm_missing_table', 'A required KGDM table could not be verified: ' . $table);
            }
        }
        $database_columns = $wpdb->get_col($wpdb->prepare('SHOW COLUMNS FROM %i', $tables['databases']), 0);
        if (!is_array($database_columns) || !in_array('visual_json', $database_columns, true)) { return new WP_Error('kgdm_missing_database_visual_column', 'The database appearance settings column is missing.'); }
        $columns = $wpdb->get_col($wpdb->prepare('SHOW COLUMNS FROM %i', $tables['collections']), 0);
        if (!is_array($columns) || !in_array('parent_id', $columns, true) || !in_array('trash_batch_id', $columns, true) || !in_array('template_version', $columns, true) || !in_array('visual_json', $columns, true) || !in_array('sections_json', $columns, true)) {
            return new WP_Error('kgdm_missing_columns', 'The collection table schema is incomplete.');
        }
        $record_columns = $wpdb->get_col($wpdb->prepare('SHOW COLUMNS FROM %i', $tables['records']), 0);
        if (!is_array($record_columns) || !in_array('payload_hash', $record_columns, true) || !in_array('payload_version', $record_columns, true) || !in_array('payload_format', $record_columns, true)) {
            return new WP_Error('kgdm_missing_record_json_columns', 'The record JSON storage schema is incomplete.');
        }
        $revision_columns = $wpdb->get_col($wpdb->prepare('SHOW COLUMNS FROM %i', $tables['template_versions']), 0);
        if (!is_array($revision_columns) || !in_array('schema_json', $revision_columns, true) || !in_array('version', $revision_columns, true)) {
            return new WP_Error('kgdm_missing_revision_table', 'The template revision table schema is incomplete.');
        }
        $migration_columns = $wpdb->get_col($wpdb->prepare('SHOW COLUMNS FROM %i', $tables['migrations']), 0);
        if (!is_array($migration_columns) || !in_array('migration_id', $migration_columns, true) || !in_array('summary_json', $migration_columns, true)) {
            return new WP_Error('kgdm_missing_migration_table', 'The data migration log table schema is incomplete.');
        }
        $snapshot_columns = $wpdb->get_col($wpdb->prepare('SHOW COLUMNS FROM %i', $tables['migration_records']), 0);
        if (!is_array($snapshot_columns) || !in_array('payload_before', $snapshot_columns, true) || !in_array('payload_hash_after', $snapshot_columns, true) || !in_array('status_after', $snapshot_columns, true)) {
            return new WP_Error('kgdm_missing_migration_snapshot_table', 'The migration recovery table schema is incomplete.');
        }
        return true;
    }

    /** Acquire an atomic site-local lock so simultaneous requests cannot run migrations twice. */
    private static function acquire_upgrade_lock() {
        $now = time();
        $existing = get_option(self::UPDATE_LOCK_OPTION, array());
        if (is_array($existing) && !empty($existing['started_at']) && ($now - (int)$existing['started_at']) < self::UPDATE_LOCK_TTL) {
            return false;
        }
        if ($existing !== false && $existing !== null) {
            delete_option(self::UPDATE_LOCK_OPTION);
        }
        $token = wp_generate_uuid4();
        $lock = array('token'=>$token, 'started_at'=>$now, 'expires_at'=>$now + self::UPDATE_LOCK_TTL, 'site_id'=>function_exists('get_current_blog_id') ? (int)get_current_blog_id() : 1);
        if (add_option(self::UPDATE_LOCK_OPTION, $lock, '', 'no')) {
            return $token;
        }
        // Recover one stale-lock race, then fail closed if another request owns it.
        $existing = get_option(self::UPDATE_LOCK_OPTION, array());
        if (!is_array($existing) || empty($existing['started_at']) || ($now - (int)$existing['started_at']) >= self::UPDATE_LOCK_TTL) {
            delete_option(self::UPDATE_LOCK_OPTION);
            if (add_option(self::UPDATE_LOCK_OPTION, $lock, '', 'no')) {
                return $token;
            }
        }
        return false;
    }

    private static function release_upgrade_lock($token) {
        $lock = get_option(self::UPDATE_LOCK_OPTION, array());
        if (is_array($lock) && !empty($lock['token']) && hash_equals((string)$lock['token'], (string)$token)) {
            delete_option(self::UPDATE_LOCK_OPTION);
        }
    }

    private static function append_update_history($entry) {
        $history = get_option(self::UPDATE_HISTORY_OPTION, array());
        if (!is_array($history)) { $history = array(); }
        array_unshift($history, array_merge(array(
            'timestamp'=>self::now(),
            'status'=>'complete',
            'type'=>'update',
            'step'=>'',
            'from'=>'',
            'to'=>'',
            'message'=>'',
        ), (array)$entry));
        update_option(self::UPDATE_HISTORY_OPTION, array_slice($history, 0, 50), false);
    }

    /** Persist a critical option and verify the value through WordPress' option API. */
    private static function update_option_checked($option_name, $value) {
        update_option($option_name, $value, false);
        return get_option($option_name, null) === $value;
    }

    /**
     * Release-level migrations are independent from the WordPress table schema.
     * Add one immutable step per plugin release that changes saved option/data
     * structures. Never edit a shipped step; add a new step for a later release.
     */
    private static function release_migrations() {
        return array(
            array(
                'id' => '3.0.0-update-engine-baseline',
                'version' => '3.0.0',
                'label' => 'Initialize update metadata and safe uninstall defaults',
                'callback' => array(__CLASS__, 'migration_300_update_engine_baseline'),
            ),
            array(
                'id' => '3.1.0-backup-recovery-baseline',
                'version' => '3.1.0',
                'label' => 'Initialize backup and recovery metadata',
                'callback' => array(__CLASS__, 'migration_310_backup_recovery_baseline'),
            ),
            array(
                'id' => '3-2-16-theme-and-install-cache-isolation',
                'version' => '3.2.16',
                'label' => 'Initialize appearance preference and clean-install cache isolation',
                'callback' => array(__CLASS__, 'migration_3216_theme_and_install_cache_isolation'),
            ),
        );
    }

    /** Safe, idempotent 3.0.0 release migration. Existing settings are retained. */
    public static function migration_300_update_engine_baseline() {
        $settings = get_option('kgdm_settings', array());
        if (!is_array($settings)) {
            if (!self::update_option_checked('kgdm_settings_migration_backup', $settings)) {
                return new WP_Error('kgdm_settings_backup_failed', 'Could not preserve the existing KGDM settings value before normalization.');
            }
            $settings = array();
        }
        if (!array_key_exists('delete_data_on_uninstall', $settings)) {
            $settings['delete_data_on_uninstall'] = 0;
            if (!self::update_option_checked('kgdm_settings', $settings)) {
                return new WP_Error('kgdm_settings_default_failed', 'Could not save the safe default for the uninstall data policy.');
            }
        }
        return true;
    }

    /** Initialize backup metadata without modifying database records or storage schema. */
    public static function migration_310_backup_recovery_baseline() {
        $index = get_option(self::BACKUP_INDEX_OPTION, array());
        if (!is_array($index)) {
            update_option('kgdm_backup_index_corrupt_backup', $index, false);
            if (update_option(self::BACKUP_INDEX_OPTION, array(), false) === false && get_option(self::BACKUP_INDEX_OPTION, null) !== array()) {
                return new WP_Error('kgdm_backup_index_init_failed', 'Backup metadata could not be initialized.');
            }
        }
        return true;
    }

    /**
     * Establish an installation-specific cache namespace and a safe default theme.
     * The generation marker is removed by uninstall cleanup, then regenerated on a
     * fresh installation so persistent Redis/Memcached entries from an old install
     * can never be mistaken for data belonging to the new installation.
     */
    public static function migration_3216_theme_and_install_cache_isolation() {
        $generation = (string)get_option('kgdm_install_generation', '');
        if ($generation === '' || !preg_match('/^[a-f0-9-]{36}$/i', $generation)) {
            $generation = wp_generate_uuid4();
            if (!self::update_option_checked('kgdm_install_generation', $generation)) {
                return new WP_Error('kgdm_install_generation_failed', 'Could not create the new installation cache namespace.');
            }
        }

        $settings = get_option('kgdm_settings', array());
        if (!is_array($settings)) {
            if (!self::update_option_checked('kgdm_settings_migration_backup', $settings)) {
                return new WP_Error('kgdm_settings_backup_failed', 'Could not preserve malformed settings before adding the appearance preference.');
            }
            $settings = array();
        }
        $appearance = sanitize_key((string)($settings['appearance_mode'] ?? 'system'));
        if (!in_array($appearance, array('system', 'light', 'dark'), true)) {
            $appearance = 'system';
        }
        if (($settings['appearance_mode'] ?? null) !== $appearance) {
            $settings['appearance_mode'] = $appearance;
            if (!self::update_option_checked('kgdm_settings', $settings)) {
                return new WP_Error('kgdm_appearance_preference_failed', 'Could not save the default system appearance preference.');
            }
        }
        return true;
    }

    private static function run_release_migrations($installed_release) {
        $ledger = get_option(self::RELEASE_MIGRATION_OPTION, array());
        if (!is_array($ledger)) {
            // Preserve malformed ledger content for diagnosis rather than silently losing it.
            update_option('kgdm_release_migration_ledger_backup', $ledger, false);
            $ledger = array();
        }

        foreach (self::release_migrations() as $migration) {
            $migration_id = sanitize_key((string)($migration['id'] ?? ''));
            $target_version = (string)($migration['version'] ?? '');
            $callback = $migration['callback'] ?? null;
            if ($migration_id === '' || $target_version === '' || !is_callable($callback)) {
                return new WP_Error('kgdm_invalid_release_migration', 'A registered plugin release migration is incomplete.');
            }
            if (version_compare($target_version, self::VERSION, '>')) { continue; }

            $existing = isset($ledger[$migration_id]) && is_array($ledger[$migration_id]) ? $ledger[$migration_id] : array();
            if (in_array(($existing['status'] ?? ''), array('complete','skipped_existing_release'), true)) { continue; }
            // When a stored release is already at/after a step, do not replay it if
            // its ledger entry was lost; record that the installed release includes it.
            if ($installed_release !== '' && version_compare($installed_release, $target_version, '>=')) {
                $ledger[$migration_id] = array(
                    'version'=>$target_version,
                    'label'=>(string)($migration['label'] ?? $migration_id),
                    'status'=>'skipped_existing_release',
                    'started_at'=>$existing['started_at'] ?? '',
                    'finished_at'=>self::now(),
                    'attempts'=>(int)($existing['attempts'] ?? 0),
                    'message'=>'The stored plugin release already includes this migration.',
                );
                update_option(self::RELEASE_MIGRATION_OPTION, $ledger, false);
                continue;
            }

            $attempts = (int)($existing['attempts'] ?? 0) + 1;
            $started = self::now();
            $ledger[$migration_id] = array(
                'version'=>$target_version,
                'label'=>(string)($migration['label'] ?? $migration_id),
                'status'=>'running',
                'started_at'=>$started,
                'finished_at'=>'',
                'attempts'=>$attempts,
                'message'=>'',
            );
            update_option(self::RELEASE_MIGRATION_OPTION, $ledger, false);
            $state = get_option('kgdm_upgrade_state', array());
            if (!is_array($state)) { $state = array(); }
            $state['current_step'] = $migration_id;
            $state['message'] = 'Applying ' . (string)($migration['label'] ?? $migration_id) . '.';
            update_option('kgdm_upgrade_state', $state, false);

            try {
                $result = call_user_func($callback);
                if (is_wp_error($result)) { throw new RuntimeException($result->get_error_message()); }
                if ($result === false) { throw new RuntimeException('The migration callback reported a failure.'); }
                $ledger[$migration_id]['status'] = 'complete';
                $ledger[$migration_id]['finished_at'] = self::now();
                $ledger[$migration_id]['message'] = 'Migration completed and verified.';
                update_option(self::RELEASE_MIGRATION_OPTION, $ledger, false);
                self::append_update_history(array(
                    'type'=>'release_migration',
                    'step'=>$migration_id,
                    'from'=>$installed_release !== '' ? $installed_release : 'fresh/unknown',
                    'to'=>$target_version,
                    'status'=>'complete',
                    'message'=>(string)($migration['label'] ?? $migration_id),
                ));
            } catch (Throwable $error) {
                $ledger[$migration_id]['status'] = 'failed';
                $ledger[$migration_id]['finished_at'] = self::now();
                $ledger[$migration_id]['message'] = sanitize_text_field($error->getMessage());
                update_option(self::RELEASE_MIGRATION_OPTION, $ledger, false);
                self::append_update_history(array(
                    'type'=>'release_migration',
                    'step'=>$migration_id,
                    'from'=>$installed_release !== '' ? $installed_release : 'fresh/unknown',
                    'to'=>$target_version,
                    'status'=>'failed',
                    'message'=>$ledger[$migration_id]['message'],
                ));
                return new WP_Error('kgdm_release_migration_failed', $migration_id . ': ' . $error->getMessage());
            }
        }

        update_option('kgdm_migration_engine_version', self::MIGRATION_ENGINE_VERSION, false);
        return true;
    }

    private static function run_upgrade($activation = false) {
        $lock_token = self::acquire_upgrade_lock();
        if (!$lock_token) {
            return false;
        }

        $old_release = (string)get_option(self::PLUGIN_VERSION_OPTION, '');
        $old_schema = (string)get_option(self::SCHEMA_OPTION, '');
        $started_at = self::now();
        $state = array(
            'status'=>'running',
            'from'=>$old_schema,
            'to'=>self::SCHEMA_VERSION,
            'plugin_from'=>$old_release,
            'plugin_to'=>self::VERSION,
            'current_step'=>'preflight',
            'started_at'=>$started_at,
            'finished_at'=>'',
            'message'=>'Preparing the plugin update.',
        );
        update_option('kgdm_upgrade_state', $state, false);

        try {
            if ($old_release !== '' && version_compare($old_release, self::VERSION, '>')) {
                throw new RuntimeException('The saved plugin release is newer than this plugin package. A downgrade was blocked to protect existing data.');
            }
            if ($old_schema !== '' && version_compare($old_schema, self::SCHEMA_VERSION, '>')) {
                throw new RuntimeException('The saved database schema is newer than this plugin package. A schema downgrade was blocked to protect existing data.');
            }

            $verified = self::verify_schema();
            $schema_required = ($old_schema !== self::SCHEMA_VERSION || is_wp_error($verified));
            if ($schema_required) {
                $state['current_step'] = 'storage_schema';
                $state['message'] = 'Creating or updating KGDM storage tables and columns.';
                update_option('kgdm_upgrade_state', $state, false);
                self::install_schema();
                $verified = self::verify_schema();
                if (is_wp_error($verified)) {
                    throw new RuntimeException($verified->get_error_message());
                }

                $state['current_step'] = 'legacy_and_storage_backfill';
                $state['message'] = 'Preserving legacy records and checking JSON/template metadata.';
                update_option('kgdm_upgrade_state', $state, false);
                self::migrate_v1();
                self::backfill_record_json_metadata();
                $history_backfill = self::backfill_template_revision_history();
                if (is_wp_error($history_backfill)) {
                    throw new RuntimeException($history_backfill->get_error_message());
                }
                self::cleanup_legacy_empty_seed();
                if (!self::update_option_checked(self::SCHEMA_OPTION, self::SCHEMA_VERSION)) {
                    throw new RuntimeException('The storage schema was verified, but its version marker could not be saved.');
                }
                self::append_update_history(array(
                    'type'=>'storage_schema',
                    'step'=>'schema-' . self::SCHEMA_VERSION,
                    'from'=>$old_schema !== '' ? $old_schema : 'new',
                    'to'=>self::SCHEMA_VERSION,
                    'status'=>'complete',
                    'message'=>'Storage schema installed/updated and required tables and columns verified.',
                ));
            }

            $state['current_step'] = 'plugin_release_migrations';
            $state['message'] = 'Applying versioned plugin release migrations.';
            update_option('kgdm_upgrade_state', $state, false);
            $release_result = self::run_release_migrations($old_release);
            if (is_wp_error($release_result)) {
                throw new RuntimeException($release_result->get_error_message());
            }

            if (get_option(self::ACTIVE_DB_OPTION, null) === null) {
                update_option(self::ACTIVE_DB_OPTION, '', false);
            }
            if (!self::update_option_checked(self::SCHEMA_OPTION, self::SCHEMA_VERSION)) {
                throw new RuntimeException('The storage schema version could not be committed.');
            }
            if (!self::update_option_checked(self::PLUGIN_VERSION_OPTION, self::VERSION)) {
                throw new RuntimeException('The installed plugin release version could not be committed.');
            }
            if (!self::update_option_checked('kgdm_migration_engine_version', self::MIGRATION_ENGINE_VERSION)) {
                throw new RuntimeException('The update migration engine version could not be committed.');
            }
            delete_transient('kgdm_upgrade_retry_after');

            $state['status'] = 'complete';
            $state['current_step'] = '';
            $state['finished_at'] = self::now();
            $state['message'] = ($old_release === '' && $old_schema === '')
                ? 'Fresh installation prepared. Plugin release migrations and storage verification completed.'
                : 'Plugin update completed. Release migrations and storage schema were verified; existing data was retained.';
            update_option('kgdm_upgrade_state', $state, false);
            self::append_update_history(array(
                'type'=>'plugin_update',
                'step'=>'release-' . self::VERSION,
                'from'=>$old_release !== '' ? $old_release : 'fresh/unknown',
                'to'=>self::VERSION,
                'status'=>'complete',
                'message'=>$state['message'],
            ));
            if (!$activation) {
                self::deactivate_previous_plugins();
            }
            return true;
        } catch (Throwable $error) {
            $message = sanitize_text_field($error->getMessage());
            $latest_state = get_option('kgdm_upgrade_state', array());
            if (is_array($latest_state) && !empty($latest_state['current_step'])) {
                $state['current_step'] = (string)$latest_state['current_step'];
            }
            set_transient('kgdm_upgrade_retry_after', 1, 15 * MINUTE_IN_SECONDS);
            $state['status'] = 'failed';
            $state['finished_at'] = self::now();
            $state['message'] = $message;
            update_option('kgdm_upgrade_state', $state, false);
            self::append_update_history(array(
                'type'=>'plugin_update',
                'step'=>(string)($state['current_step'] ?? 'unknown'),
                'from'=>$old_release !== '' ? $old_release : 'fresh/unknown',
                'to'=>self::VERSION,
                'status'=>'failed',
                'message'=>$message,
            ));
            return false;
        } finally {
            self::release_upgrade_lock($lock_token);
        }
    }

    public function handle_retry_upgrade() {
        self::require_admin();
        check_admin_referer('kgdm_retry_upgrade');
        delete_transient('kgdm_upgrade_retry_after');
        $success = self::run_upgrade(false);
        self::redirect(array('tab'=>'update-log','notice'=>$success ? 'update_retry_complete' : 'update_retry_failed'));
    }

    private static function table_names() {
        global $wpdb;
        return array(
            'databases' => $wpdb->prefix . 'kgdm_databases',
            'collections' => $wpdb->prefix . 'kgdm_collections',
            'records' => $wpdb->prefix . 'kgdm_records',
            'template_versions' => $wpdb->prefix . 'kgdm_template_versions',
            'migrations' => $wpdb->prefix . 'kgdm_migrations',
            'migration_records' => $wpdb->prefix . 'kgdm_migration_records',
        );
    }

    /**
     * Shared metric-card template used by dashboard and completeness counters.
     * Keeping markup here gives every overview a consistent and accessible structure.
     */
    private static function overview_metric_html($label, $value, $description, $icon, $variant = '') {
        $icon = sanitize_html_class((string)$icon);
        $variant = sanitize_html_class((string)$variant);
        return '<article class="kgdm-overview-stat kgdm-ui-metric-card'.($variant !== '' ? ' is-'.$variant : '').'">'
            .'<span class="kgdm-overview-stat-icon"><span class="dashicons '.esc_attr($icon).'" aria-hidden="true"></span></span>'
            .'<span class="kgdm-overview-stat-copy"><span class="kgdm-overview-stat-label">'.esc_html($label).'</span><strong>'.esc_html((string)$value).'</strong><small>'.esc_html($description).'</small></span>'
            .'</article>';
    }

    /** Shared compact metric template for completeness and other status summaries. */
    private static function summary_metric_html($value, $label, $variant = '') {
        $variant = sanitize_html_class((string)$variant);
        return '<div class="kgdm-completeness-card kgdm-ui-metric-card'.($variant !== '' ? ' is-'.$variant : '').'"><strong>'.esc_html((string)$value).'</strong><span>'.esc_html($label).'</span></div>';
    }

    /**
     * Shared empty-state template. Actions are structured data, never prebuilt HTML,
     * so every label, URL, icon and class is escaped at the output boundary.
     */
    private static function empty_state_html($icon, $title, $description, $actions = array(), $classes = '') {
        $icon = sanitize_html_class((string)$icon);
        $classes = trim(preg_replace('/[^a-zA-Z0-9_ -]/', '', (string)$classes));
        $html = '<div class="kgdm-ui-empty-state'.($classes !== '' ? ' '.esc_attr($classes) : '').'">'
            .'<span class="kgdm-ui-empty-icon"><span class="dashicons '.esc_attr($icon).'" aria-hidden="true"></span></span>'
            .'<strong>'.esc_html($title).'</strong><p>'.esc_html($description).'</p>';
        if (is_array($actions) && !empty($actions)) {
            $html .= '<div class="kgdm-ui-empty-actions">';
            foreach ($actions as $action) {
                if (!is_array($action) || empty($action['url']) || empty($action['label'])) { continue; }
                $action_class = in_array(($action['variant'] ?? ''), array('primary','secondary','link'), true) ? (string)$action['variant'] : 'secondary';
                $action_icon = !empty($action['icon']) ? sanitize_html_class((string)$action['icon']) : '';
                $html .= '<a class="button'.($action_class === 'primary' ? ' button-primary' : '').'" href="'.esc_url($action['url']).'">';
                if ($action_icon !== '') { $html .= '<span class="dashicons '.esc_attr($action_icon).'" aria-hidden="true"></span> '; }
                $html .= esc_html($action['label']).'</a>';
            }
            $html .= '</div>';
        }
        return $html.'</div>';
    }

    /** Shared placeholder for record, profile and media previews. */
    private static function image_placeholder_html($class = 'kgdm-record-thumb-placeholder', $label = 'No image selected') {
        $class = trim(preg_replace('/[^a-zA-Z0-9_ -]/', '', (string)$class));
        return '<span class="kgdm-ui-image-placeholder '.esc_attr($class).'" role="img" aria-label="'.esc_attr($label).'"><span class="dashicons dashicons-format-image" aria-hidden="true"></span><span class="screen-reader-text">'.esc_html($label).'</span></span>';
    }

    /**
     * Render an attached image using WordPress responsive image metadata.
     * Only real image attachments are accepted; thumbnails are lazy-loaded and
     * decoded asynchronously so large source images are not sent to admin tables.
     */
    private static function attachment_image_html($attachment_id, $size = 'thumbnail', $class = 'kgdm-record-thumb', $alt = '') {
        $attachment_id = absint($attachment_id);
        if (!$attachment_id || !function_exists('wp_attachment_is_image') || !wp_attachment_is_image($attachment_id)) { return ''; }
        $classes = is_array($class) ? $class : preg_split('/\s+/', trim((string)$class));
        $classes = array_values(array_filter(array_map('sanitize_html_class', (array)$classes)));
        if (empty($classes)) { $classes = array('kgdm-record-thumb'); }
        $alt = sanitize_text_field((string)$alt);
        if ($alt === '' && function_exists('get_post_meta')) {
            $alt = sanitize_text_field((string)get_post_meta($attachment_id, '_wp_attachment_image_alt', true));
        }
        $sizes = ($size === 'thumbnail') ? '(max-width: 782px) 48px, 64px' : '(max-width: 782px) 96px, 160px';
        $attributes = array(
            'class' => implode(' ', $classes),
            'alt' => $alt,
            'loading' => 'lazy',
            'decoding' => 'async',
            'fetchpriority' => 'low',
            'sizes' => $sizes,
        );
        $html = wp_get_attachment_image($attachment_id, $size, false, $attributes);
        return is_string($html) && $html !== '' ? wp_kses_post($html) : '';
    }

    /**
     * One grouped query supplies active folder and record totals for every database.
     * The bundled Genshin provider is then reconciled separately so source records and
     * local override/tombstone records retain their existing semantics.
     */
    private static function database_overview_summaries($databases) {
        global $wpdb;
        $active_ids = array();
        foreach ((array)$databases as $database) {
            if (($database['status'] ?? 'active') === 'active' && !empty($database['id'])) { $active_ids[] = sanitize_key((string)$database['id']); }
        }
        $summaries = array();
        foreach ($active_ids as $id) { $summaries[$id] = array('folders'=>0,'records'=>0); }
        if (empty($active_ids)) { return $summaries; }

        $tables = self::table_names();
        $in = implode(',', array_fill(0, count($active_ids), '%s'));
        $sql = 'SELECT d.id AS database_id, COUNT(DISTINCT c.id) AS folder_count, COUNT(r.record_id) AS record_count '
            .'FROM %i d LEFT JOIN %i c ON c.database_id = d.id AND c.status = %s '
            .'LEFT JOIN %i r ON r.database_id = d.id AND r.collection_id = c.id AND r.status = %s '
            .'WHERE d.status = %s AND d.id IN ('.$in.') GROUP BY d.id';
        $args = array_merge(array($tables['databases'],$tables['collections'],'active',$tables['records'],'active','active'), $active_ids);
        $prepared = $wpdb->prepare($sql, $args);
        $rows = $prepared ? $wpdb->get_results($prepared, ARRAY_A) : array();
        if (is_array($rows)) {
            foreach ($rows as $row) {
                $id = (string)($row['database_id'] ?? '');
                if (!isset($summaries[$id])) { continue; }
                $summaries[$id] = array('folders'=>(int)$row['folder_count'],'records'=>(int)$row['record_count']);
            }
        }
        // If the grouped query is unavailable on an unusual database adapter, fall
        // back to the established collection/count helpers rather than showing zeros.
        if (!$prepared || !is_array($rows) || !empty($wpdb->last_error)) {
            foreach ($active_ids as $database_id) {
                $collections = self::get_collections($database_id, false);
                $record_counts = self::collection_record_counts($database_id, false);
                $record_total = 0;
                foreach ($collections as $collection) {
                    $record_total += is_array($record_counts)
                        ? (int)($record_counts[(string)$collection['id']] ?? 0)
                        : self::count_admin_records($database_id, (string)$collection['slug'], false);
                }
                $summaries[$database_id] = array('folders'=>count($collections),'records'=>$record_total);
            }
        }

        if (in_array('genshin-impact', $active_ids, true) && function_exists('kg_genshin_master_data')) {
            $collections = self::get_collections('genshin-impact', false);
            $master = kg_genshin_master_data();
            $source_total = 0;
            foreach ($collections as $collection) {
                $merged = self::extract_legacy_collection($master, (string)$collection['slug']);
                $managed = self::db_record_entries('genshin-impact', (string)$collection['slug'], 'all');
                foreach ($managed as $record_id => $entry) {
                    if (in_array(($entry['status'] ?? ''), array('deleted','purged'), true)) { unset($merged[$record_id]); }
                    else { $merged[$record_id] = $entry['record']; }
                }
                $source_total += count($merged);
            }
            $summaries['genshin-impact'] = array('folders'=>count($collections),'records'=>$source_total);
        }
        return $summaries;
    }

    /** Returns the combined data+index bytes for KGDM tables, or null when unavailable. */
    private static function get_storage_usage_bytes() {
        global $wpdb;
        $tables = array_values(self::table_names());
        if (empty($tables)) { return null; }
        $placeholders = implode(', ', array_fill(0, count($tables), '%s'));
        $sql = "SELECT COALESCE(SUM(data_length + index_length), 0) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ({$placeholders})";
        $prepared = $wpdb->prepare($sql, $tables);
        if (!$prepared) { return null; }
        $value = $wpdb->get_var($prepared);
        if (!empty($wpdb->last_error) || $value === null || $value === false) { return null; }
        return max(0, (int)$value);
    }

    private static function format_storage_usage($bytes) {
        if ($bytes === null) { return 'Unavailable'; }
        if (function_exists('size_format')) { return size_format((int)$bytes, 1); }
        $units = array('B', 'KB', 'MB', 'GB', 'TB');
        $value = (float)$bytes; $unit = 0;
        while ($value >= 1024 && $unit < count($units) - 1) { $value /= 1024; $unit++; }
        return number_format_i18n($value, $unit === 0 ? 0 : 1) . ' ' . $units[$unit];
    }

    private static function install_schema() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $tables = self::table_names();
        $charset = $wpdb->get_charset_collate();
        $sql_databases = "CREATE TABLE {$tables['databases']} (
 id varchar(64) NOT NULL,
 name varchar(191) NOT NULL,
 slug varchar(191) NOT NULL,
 description text NULL,
 visual_json longtext NULL,
 kind varchar(40) NOT NULL DEFAULT 'general',
 api_access varchar(20) NOT NULL DEFAULT 'private',
 status varchar(20) NOT NULL DEFAULT 'active',
 created_at datetime NOT NULL,
 updated_at datetime NOT NULL,
 PRIMARY KEY  (id),
 UNIQUE KEY slug (slug),
 KEY status (status)
) {$charset};";
        $sql_collections = "CREATE TABLE {$tables['collections']} (
 id varchar(64) NOT NULL,
 database_id varchar(64) NOT NULL,
 slug varchar(191) NOT NULL,
 name varchar(191) NOT NULL,
 singular_name varchar(191) NOT NULL,
 description text NULL,
 visual_json longtext NULL,
 sections_json longtext NULL,
 schema_json longtext NULL,
 collection_mode varchar(20) NOT NULL DEFAULT 'form',
 form_templates_json longtext NULL,
 parent_id varchar(64) NOT NULL DEFAULT '',
 trash_batch_id varchar(36) NOT NULL DEFAULT '',
 template_version int(11) NOT NULL DEFAULT 1,
 sort_order int(11) NOT NULL DEFAULT 0,
 status varchar(20) NOT NULL DEFAULT 'active',
 created_at datetime NOT NULL,
 updated_at datetime NOT NULL,
 PRIMARY KEY  (id),
 UNIQUE KEY db_slug (database_id,slug),
 KEY database_id (database_id),
 KEY status (status)
) {$charset};";
        $sql_records = "CREATE TABLE {$tables['records']} (
 record_id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
 database_id varchar(64) NOT NULL,
 collection_id varchar(64) NOT NULL,
 item_key varchar(191) NOT NULL,
 item_name varchar(255) NOT NULL,
 payload longtext NOT NULL,
 payload_hash char(64) NOT NULL DEFAULT '',
 payload_version int(11) NOT NULL DEFAULT 1,
 payload_format varchar(20) NOT NULL DEFAULT 'json',
 status varchar(20) NOT NULL DEFAULT 'active',
 created_at datetime NOT NULL,
 updated_at datetime NOT NULL,
 updated_by bigint(20) unsigned NOT NULL DEFAULT 0,
 PRIMARY KEY  (record_id),
 UNIQUE KEY collection_item (collection_id,item_key),
 KEY database_id (database_id),
 KEY collection_id (collection_id),
 KEY status (status),
 KEY item_name (item_name)
) {$charset};";
        dbDelta($sql_databases);
        dbDelta($sql_collections);
        dbDelta($sql_records);
        $sql_revisions = "CREATE TABLE {$tables['template_versions']} (
 revision_id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
 database_id varchar(64) NOT NULL,
 collection_id varchar(64) NOT NULL,
 collection_slug varchar(191) NOT NULL,
 version int(11) NOT NULL DEFAULT 1,
 schema_json longtext NOT NULL,
 form_templates_json longtext NULL,
 change_summary longtext NULL,
 created_at datetime NOT NULL,
 created_by bigint(20) unsigned NOT NULL DEFAULT 0,
 PRIMARY KEY  (revision_id),
 UNIQUE KEY collection_version (collection_id,version),
 KEY database_id (database_id),
 KEY collection_id (collection_id)
) {$charset};";
        dbDelta($sql_revisions);
        $sql_migrations = "CREATE TABLE {$tables['migrations']} (
 migration_id varchar(36) NOT NULL,
 database_id varchar(64) NOT NULL,
 collection_id varchar(64) NOT NULL,
 collection_slug varchar(191) NOT NULL,
 from_version int(11) NOT NULL DEFAULT 1,
 to_version int(11) NOT NULL DEFAULT 1,
 status varchar(32) NOT NULL DEFAULT 'completed',
 summary_json longtext NULL,
 record_count int(11) NOT NULL DEFAULT 0,
 changed_count int(11) NOT NULL DEFAULT 0,
 conflict_count int(11) NOT NULL DEFAULT 0,
 error_message text NULL,
 created_at datetime NOT NULL,
 created_by bigint(20) unsigned NOT NULL DEFAULT 0,
 rolled_back_at datetime NULL,
 PRIMARY KEY  (migration_id),
 KEY database_id (database_id),
 KEY collection_id (collection_id),
 KEY status (status),
 KEY created_at (created_at)
) {$charset};";
        $sql_migration_records = "CREATE TABLE {$tables['migration_records']} (
 snapshot_id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
 migration_id varchar(36) NOT NULL,
 record_id bigint(20) unsigned NOT NULL,
 item_key varchar(191) NOT NULL,
 payload_before longtext NOT NULL,
 payload_hash_before char(64) NOT NULL DEFAULT '',
 payload_version_before int(11) NOT NULL DEFAULT 1,
 payload_format_before varchar(20) NOT NULL DEFAULT 'json',
 payload_hash_after char(64) NOT NULL DEFAULT '',
 status_before varchar(20) NOT NULL DEFAULT 'active',
 status_after varchar(20) NOT NULL DEFAULT 'active',
 created_at datetime NOT NULL,
 PRIMARY KEY  (snapshot_id),
 KEY migration_id (migration_id),
 KEY record_id (record_id),
 KEY item_key (item_key)
) {$charset};";
        dbDelta($sql_migrations);
        dbDelta($sql_migration_records);
    }


    private static function now() { return current_time('mysql'); }

    /** Canonical JSON encoding for every stored record. The database always stores a JSON object,
     * while payload_hash lets validation detect corruption or manual database edits later. */
    private static function encode_record_payload($record) {
        if (!is_array($record) || isset($record[0])) {
            return new WP_Error('kgdm_invalid_record_payload', 'Record storage requires a JSON object.');
        }
        $json = wp_json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        if (!is_string($json) || $json === '') {
            return new WP_Error('kgdm_record_json_encode_failed', 'The record could not be encoded as valid JSON.');
        }
        $decoded = json_decode($json, true, self::MAX_JSON_DEPTH);
        if (!is_array($decoded) || json_last_error() !== JSON_ERROR_NONE || isset($decoded[0])) {
            return new WP_Error('kgdm_record_json_roundtrip_failed', 'The record failed JSON round-trip validation.');
        }
        return array('json'=>$json, 'hash'=>hash('sha256', $json), 'version'=>self::JSON_STORAGE_VERSION, 'format'=>'json');
    }

    private static function decode_record_payload($payload, $expected_hash = '') {
        $payload = (string)$payload;
        if ($payload === '') { return new WP_Error('kgdm_empty_record_payload', 'The saved record payload is empty.'); }
        $record = json_decode($payload, true, self::MAX_JSON_DEPTH);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($record) || isset($record[0])) {
            return new WP_Error('kgdm_corrupt_record_json', 'The saved record contains invalid JSON.');
        }
        $canonical = wp_json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        if (!is_string($canonical)) { return new WP_Error('kgdm_corrupt_record_json', 'The saved record could not be re-encoded as JSON.'); }
        $hash = hash('sha256', $canonical);
        if ($expected_hash !== '' && !hash_equals((string)$expected_hash, $hash)) {
            return new WP_Error('kgdm_record_hash_mismatch', 'The saved record JSON failed integrity validation.');
        }
        return $record;
    }

    private static function backfill_record_json_metadata() {
        global $wpdb;
        $tables = self::table_names();
        $rows = $wpdb->get_results($wpdb->prepare('SELECT record_id, payload, payload_hash, payload_version, payload_format FROM %i', $tables['records']), ARRAY_A);
        foreach ((array)$rows as $row) {
            $payload = self::decode_record_payload($row['payload'], '');
            if (is_wp_error($payload)) { continue; }
            $encoded = self::encode_record_payload($payload);
            if (is_wp_error($encoded)) { continue; }
            if ((string)$row['payload_hash'] !== $encoded['hash'] || (int)$row['payload_version'] !== self::JSON_STORAGE_VERSION || (string)$row['payload_format'] !== 'json') {
                $wpdb->update($tables['records'], array('payload'=>$encoded['json'],'payload_hash'=>$encoded['hash'],'payload_version'=>$encoded['version'],'payload_format'=>$encoded['format']), array('record_id'=>(int)$row['record_id']));
            }
        }
    }

    /** Default visual style shared by database and folder cards. */
    private static function default_visual_settings($is_database = false) {
        return array(
            'dashicon' => $is_database ? 'dashicons-database' : 'dashicons-open-folder',
            'icon_attachment_id' => 0,
            'background_attachment_id' => 0,
            'background_color' => '#f5f8ff',
            'accent_color' => '#2271b1',
        );
    }

    /** Sanitize appearance settings. Only WordPress image attachments can be selected. */
    private static function sanitize_visual_settings($raw, $is_database = false, $require_upload_cap = false) {
        $defaults = self::default_visual_settings($is_database);
        if (!is_array($raw)) { $raw = array(); }
        $allowed_icons = array(
            'dashicons-database','dashicons-open-folder','dashicons-category','dashicons-format-image',
            'dashicons-admin-site-alt3','dashicons-book','dashicons-archive','dashicons-groups',
            'dashicons-gamepad','dashicons-layout','dashicons-screenoptions','dashicons-networking',
            'dashicons-admin-tools','dashicons-media-document','dashicons-star-filled','dashicons-chart-bar',
        );
        $dashicon = sanitize_html_class((string)($raw['dashicon'] ?? $defaults['dashicon']));
        if (!in_array($dashicon, $allowed_icons, true)) { $dashicon = $defaults['dashicon']; }
        $color = static function($value, $fallback) {
            $value = sanitize_hex_color((string)$value);
            return $value ? strtolower($value) : $fallback;
        };
        $out = array(
            'dashicon' => $dashicon,
            'icon_attachment_id' => 0,
            'background_attachment_id' => 0,
            'background_color' => $color($raw['background_color'] ?? '', $defaults['background_color']),
            'accent_color' => $color($raw['accent_color'] ?? '', $defaults['accent_color']),
        );
        if ($is_database) {
            foreach (array('icon_attachment_id','background_attachment_id') as $key) {
                $attachment_id = absint($raw[$key] ?? 0);
                $can_use_media = !$require_upload_cap || current_user_can('upload_files');
                if ($can_use_media && $attachment_id && wp_attachment_is_image($attachment_id)) { $out[$key] = $attachment_id; }
            }
        }
        return $out;
    }

    private static function decode_visual_settings($json, $is_database = false) {
        $decoded = json_decode((string)$json, true);
        return self::sanitize_visual_settings(is_array($decoded) ? $decoded : array(), $is_database);
    }

    private static function render_visual_settings_fields($prefix, $visual, $allow_images = false, $is_database = false) {
        $visual = self::sanitize_visual_settings($visual, $is_database);
        $icons = array(
            'dashicons-database'=>'Database','dashicons-open-folder'=>'Folder','dashicons-category'=>'Category',
            'dashicons-format-image'=>'Image','dashicons-admin-site-alt3'=>'Website','dashicons-book'=>'Book',
            'dashicons-archive'=>'Archive','dashicons-groups'=>'Groups','dashicons-gamepad'=>'Gamepad',
            'dashicons-layout'=>'Layout','dashicons-screenoptions'=>'Grid','dashicons-networking'=>'Network',
            'dashicons-admin-tools'=>'Tools','dashicons-media-document'=>'Document','dashicons-star-filled'=>'Star',
            'dashicons-chart-bar'=>'Chart',
        );
        echo '<section class="kgdm-visual-settings"><div class="kgdm-section-head"><div><h3>Appearance</h3><p>Customize the icon and card colours. These settings can be changed later.</p></div></div>';
        echo '<div class="kgdm-visual-grid"><label>Icon<select name="'.esc_attr($prefix).'[dashicon]">';
        foreach ($icons as $class=>$label) { echo '<option value="'.esc_attr($class).'" '.selected($visual['dashicon'],$class,false).'>'.esc_html($label).'</option>'; }
        echo '</select></label><label>Background colour<input type="color" name="'.esc_attr($prefix).'[background_color]" value="'.esc_attr($visual['background_color']).'"></label><label>Accent colour<input type="color" name="'.esc_attr($prefix).'[accent_color]" value="'.esc_attr($visual['accent_color']).'"></label></div>';
        if ($allow_images && $is_database && current_user_can('upload_files')) {
            foreach (array('icon_attachment_id'=>'Icon image','background_attachment_id'=>'Background image') as $key=>$label) {
                $id = absint($visual[$key] ?? 0); $preview = $id ? wp_get_attachment_image($id, 'medium', false, array('class'=>'kgdm-visual-media-preview-img','loading'=>'lazy','decoding'=>'async')) : '<span class="kgdm-visual-placeholder">No image selected</span>';
                echo '<div class="kgdm-visual-media-control"><strong>'.esc_html($label).'</strong><input type="hidden" class="kgdm-visual-media-id" id="'.esc_attr($prefix.'-'.$key).'" name="'.esc_attr($prefix).'['.esc_attr($key).']" value="'.(int)$id.'"><div class="kgdm-visual-media-preview" data-empty="No image selected">'.wp_kses_post($preview).'</div><button type="button" class="button kgdm-visual-media-choose" data-target="#'.esc_attr($prefix.'-'.$key).'">Choose image</button> <button type="button" class="button-link kgdm-visual-media-clear" data-target="#'.esc_attr($prefix.'-'.$key).'">Remove</button></div>';
            }
        }
        echo '</section>';
    }

    /** Serialize card visuals for public REST output without exposing attachment IDs. */
    private static function public_visual_payload($visual, $is_database = false) {
        $visual = self::sanitize_visual_settings($visual, $is_database);
        $icon_url = '';
        $background_url = '';
        if ($is_database && !empty($visual['icon_attachment_id']) && function_exists('wp_get_attachment_image_url')) {
            $icon_url = (string)wp_get_attachment_image_url((int)$visual['icon_attachment_id'], 'thumbnail');
        }
        if ($is_database && !empty($visual['background_attachment_id']) && function_exists('wp_get_attachment_image_url')) {
            $background_url = (string)wp_get_attachment_image_url((int)$visual['background_attachment_id'], 'large');
        }
        return array(
            'dashicon'=>(string)$visual['dashicon'],
            'background_color'=>(string)$visual['background_color'],
            'accent_color'=>(string)$visual['accent_color'],
            'icon_url'=>$icon_url !== '' ? esc_url_raw($icon_url) : null,
            'background_url'=>$background_url !== '' ? esc_url_raw($background_url) : null,
        );
    }

    private static function visual_icon_html($visual, $is_database = false) {
        $visual = self::sanitize_visual_settings($visual, $is_database);
        $attachment_id = absint($visual['icon_attachment_id'] ?? 0);
        if ($is_database && $attachment_id && wp_attachment_is_image($attachment_id)) {
            $image = wp_get_attachment_image($attachment_id, 'thumbnail', false, array('class'=>'kgdm-visual-icon-image','loading'=>'lazy','decoding'=>'async'));
            if ($image) { return $image; }
        }
        return '<span class="dashicons '.esc_attr($visual['dashicon']).'" aria-hidden="true"></span>';
    }

    /** WordPress-style hierarchical terms, one path per line (Parent > Child). */
    private static function sanitize_collection_sections($raw) {
        if (is_array($raw)) {
            $lines = array();
            foreach ($raw as $item) {
                if (is_array($item) && (!empty($item['path']) || !empty($item['name']))) { $lines[] = sanitize_text_field((string)($item['path'] ?? $item['name'])); }
                elseif (is_string($item)) { $lines[] = $item; }
            }
        } else {
            $raw = (string)$raw;
            $decoded = json_decode($raw, true);
            $lines = is_array($decoded) ? $decoded : preg_split('/\r\n|\r|\n/', $raw);
        }
        $terms = array(); $paths = array();
        foreach (array_slice((array)$lines, 0, 200) as $line) {
            if (is_array($line)) { $line = $line['name'] ?? ''; }
            $parts = array_values(array_filter(array_map('sanitize_text_field', array_map('trim', explode('>', (string)$line))), function($v){ return $v !== ''; }));
            if (empty($parts) || count($parts) > 5) { continue; }
            $parent = '';
            foreach ($parts as $name) {
                $base_slug = sanitize_title($name);
                if ($base_slug === '') { continue; }
                $slug = $parent !== '' ? sanitize_title($parent . '-' . $base_slug) : $base_slug;
                $key = $parent . '|' . $base_slug;
                if (!isset($paths[$key])) {
                    $paths[$key] = true;
                    $terms[] = array('slug'=>$slug,'name'=>$name,'parent'=>$parent,'path'=>trim($parent === '' ? $name : self::section_path_label($terms,$parent).' > '.$name));
                }
                $parent = $slug;
            }
        }
        return $terms;
    }

    private static function section_path_label($terms, $slug) {
        foreach ((array)$terms as $term) { if (($term['slug'] ?? '') === $slug) { return (string)($term['path'] ?? $term['name'] ?? $slug); } }
        return $slug;
    }

    private static function collection_sections_text($terms) {
        $lines = array();
        foreach ((array)$terms as $term) { if (!empty($term['path'])) { $lines[] = (string)$term['path']; } elseif (!empty($term['name'])) { $lines[] = (string)$term['name']; } }
        return implode("\n", $lines);
    }

    private static function normalize_publication_date($value) {
        $value = trim((string)$value);
        if ($value === '') { return ''; }
        $value = str_replace('T', ' ', $value);
        if (!preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}(:\d{2})?$/', $value)) { return ''; }
        if (strlen($value) === 16) { $value .= ':00'; }
        $date = DateTime::createFromFormat('Y-m-d H:i:s', $value, wp_timezone());
        return ($date && $date->format('Y-m-d H:i:s') === $value) ? $value : '';
    }

    /** Reject invalid input instead of silently discarding an impossible visibility window. */
    private static function validate_record_publication_dates($record) {
        $publication = is_array($record['_kgdm_publication'] ?? null) ? $record['_kgdm_publication'] : array();
        $raw_publish = trim((string)($publication['publish_at'] ?? ''));
        $raw_hide = trim((string)($publication['hide_at'] ?? ''));
        $publish = self::normalize_publication_date($raw_publish);
        $hide = self::normalize_publication_date($raw_hide);
        if (($raw_publish !== '' && $publish === '') || ($raw_hide !== '' && $hide === '')) {
            return new WP_Error('kgdm_invalid_publication_date', 'Enter valid show and hide dates using your WordPress site timezone.');
        }
        if ($publish !== '' && $hide !== '' && $hide <= $publish) {
            return new WP_Error('kgdm_invalid_publication_range', 'The hide date must be later than the show date.');
        }
        return true;
    }

    private static function sanitize_record_metadata($record, $collection) {
        if (!is_array($record)) { $record = array(); }
        $allowed = array();
        foreach ((array)($collection['sections'] ?? array()) as $term) { $allowed[(string)$term['slug']] = true; }
        $assigned = array();
        foreach ((array)($record['_kgdm_sections'] ?? array()) as $slug) { $slug = sanitize_title((string)$slug); if ($slug !== '' && isset($allowed[$slug])) { $assigned[$slug] = true; } }
        $record['_kgdm_sections'] = array_keys($assigned);
        $publication = is_array($record['_kgdm_publication'] ?? null) ? $record['_kgdm_publication'] : array();
        $visibility = sanitize_key((string)($publication['visibility'] ?? 'public'));
        if (!in_array($visibility, array('public','private'), true)) { $visibility = 'public'; }
        $publish_at = self::normalize_publication_date($publication['publish_at'] ?? '');
        $hide_at = self::normalize_publication_date($publication['hide_at'] ?? '');
        if ($publish_at !== '' && $hide_at !== '' && $hide_at <= $publish_at) { $hide_at = ''; }
        $record['_kgdm_publication'] = array('visibility'=>$visibility,'publish_at'=>$publish_at,'hide_at'=>$hide_at);
        return $record;
    }

    private static function record_publication_state($record) {
        $publication = is_array($record['_kgdm_publication'] ?? null) ? $record['_kgdm_publication'] : array();
        $visibility = (string)($publication['visibility'] ?? 'public');
        if ($visibility !== 'public') { return 'private'; }
        $now = current_time('mysql');
        $publish_at = (string)($publication['publish_at'] ?? '');
        $hide_at = (string)($publication['hide_at'] ?? '');
        if ($publish_at !== '' && $publish_at > $now) { return 'scheduled'; }
        if ($hide_at !== '' && $hide_at <= $now) { return 'hidden'; }
        return 'public';
    }

    private static function public_record_payload($record) {
        if (!is_array($record)) { return $record; }
        // Publication controls are administrative metadata; public consumers receive
        // the live record and its section assignments, but not private scheduling dates.
        unset($record['_kgdm_publication']);
        return $record;
    }

    private static function record_is_public_live($record) {
        return self::record_publication_state($record) === 'public';
    }

    private static function schedule_record_visibility_events($database_id, $collection_slug, $record_id, $record, $status = 'active') {
        if (!function_exists('wp_clear_scheduled_hook') || !function_exists('wp_schedule_single_event')) { return; }
        wp_clear_scheduled_hook('kgdm_record_visibility_transition', array($database_id, $collection_slug, $record_id));
        if ($status !== 'active' || !is_array($record)) { return; }
        $publication = (array)($record['_kgdm_publication'] ?? array());
        foreach (array('publish_at','hide_at') as $key) {
            $value = (string)($publication[$key] ?? '');
            if ($value === '') { continue; }
            $local = DateTime::createFromFormat('Y-m-d H:i:s', $value, wp_timezone());
            if (!$local) { continue; }
            $timestamp = $local->getTimestamp();
            if ($timestamp > time()) { wp_schedule_single_event($timestamp + 1, 'kgdm_record_visibility_transition', array($database_id, $collection_slug, $record_id)); }
        }
    }

    public function handle_record_visibility_transition($database_id, $collection_slug, $record_id) {
        $database_id = sanitize_key((string)$database_id);
        $collection_slug = sanitize_title((string)$collection_slug);
        $record_id = sanitize_title((string)$record_id);
        $record = self::get_admin_record($database_id, $collection_slug, $record_id, false);
        if (is_array($record)) {
            // Rebuild remaining future transitions after the publish/hide boundary.
            self::schedule_record_visibility_events($database_id, $collection_slug, $record_id, $record, 'active');
        }
        self::invalidate_collection_query_cache($database_id, $collection_slug);
    }

    private static function insert_database($id, $name, $description, $kind, $status = 'active', $visual = null) {
        global $wpdb;
        $tables = self::table_names();
        $existing = $wpdb->get_var($wpdb->prepare('SELECT id FROM %i WHERE id = %s', $tables['databases'], $id));
        $data = array(
            'id' => $id,
            'name' => $name,
            'slug' => $id,
            'description' => $description,
            'visual_json' => wp_json_encode(self::sanitize_visual_settings($visual === null ? (self::get_database($id, true)['visual'] ?? array()) : $visual, true)),
            'kind' => $kind,
            'status' => $status,
            'updated_at' => self::now(),
        );
        if ($existing) {
            $wpdb->update($tables['databases'], $data, array('id' => $id));
        } else {
            $data['created_at'] = self::now();
            $wpdb->insert($tables['databases'], $data);
        }
        return self::get_database($id, true);
    }


    private static function collection_id($database_id, $slug) {
        return substr(hash('sha256', $database_id . '|' . $slug), 0, 40);
    }

    private static function insert_collection($database_id, $slug, $name, $singular, $description, $schema, $sort_order = 0, $status = 'active', $mode = 'form', $form_templates = array(), $parent_id = '', $template_version = 1, $trash_batch_id = null, $visual = null, $sections = null) {
        global $wpdb;
        $tables = self::table_names();
        $id = self::collection_id($database_id, $slug);
        $existing = $wpdb->get_var($wpdb->prepare('SELECT id FROM %i WHERE id = %s', $tables['collections'], $id));
        $data = array(
            'id' => $id,
            'database_id' => $database_id,
            'slug' => $slug,
            'name' => $name,
            'singular_name' => $singular,
            'description' => $description,
            'visual_json' => wp_json_encode(self::sanitize_visual_settings($visual === null ? (self::get_collection($database_id, $slug, true)['visual'] ?? array()) : $visual, false)),
            'sections_json' => wp_json_encode($sections === null ? (self::get_collection($database_id, $slug, true)['sections'] ?? array()) : self::sanitize_collection_sections($sections)),
            'schema_json' => wp_json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'collection_mode' => in_array($mode, array('form','list'), true) ? $mode : 'form',
            'form_templates_json' => wp_json_encode($form_templates, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'parent_id' => (string)$parent_id,
            'template_version' => max(1, (int)$template_version),
            'sort_order' => (int)$sort_order,
            'status' => $status,
            'updated_at' => self::now(),
        );
        if ($existing) {
            // Normal edits preserve the existing Trash group. Imports can pass an
            // explicit source group; new collections always start outside Trash.
            $data['trash_batch_id'] = $trash_batch_id === null
                ? (string)$wpdb->get_var($wpdb->prepare('SELECT trash_batch_id FROM %i WHERE id = %s LIMIT 1', $tables['collections'], $id))
                : (string)$trash_batch_id;
            $result = $wpdb->update($tables['collections'], $data, array('id' => $id));
            if ($result === false) { return false; }
        } else {
            $data['trash_batch_id'] = $trash_batch_id === null ? '' : (string)$trash_batch_id;
            $data['created_at'] = self::now();
            if ($wpdb->insert($tables['collections'], $data) === false) { return false; }
        }
        return self::get_collection($database_id, $slug, true);
    }

    private static function get_collection($database_id, $slug, $include_archived = false) {
        global $wpdb;
        $tables = self::table_names();
        $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE database_id = %s AND slug = %s LIMIT 1', $tables['collections'], $database_id, $slug), ARRAY_A);
        if (!$row || (!$include_archived && ($row['status'] ?? '') !== 'active')) { return null; }
        $schema = json_decode((string)($row['schema_json'] ?? '[]'), true);
        $templates = json_decode((string)($row['form_templates_json'] ?? '[]'), true);
        $row['schema'] = is_array($schema) ? $schema : array();
        $row['form_templates'] = is_array($templates) ? $templates : array();
        $row['visual'] = self::decode_visual_settings($row['visual_json'] ?? '', false);
        $sections = json_decode((string)($row['sections_json'] ?? '[]'), true);
        $row['sections'] = self::sanitize_collection_sections(is_array($sections) ? $sections : array());
        $row['collection_mode'] = in_array(($row['collection_mode'] ?? 'form'), array('form','list'), true) ? $row['collection_mode'] : 'form';
        $row['parent_id'] = (string)($row['parent_id'] ?? '');
        $row['trash_batch_id'] = (string)($row['trash_batch_id'] ?? '');
        $row['template_version'] = max(1, (int)($row['template_version'] ?? 1));
        return $row;
    }



    private static function migrate_v1() {
        if (get_option('kgdm_v1_migrated') === '1') { return; }
        $old = get_option(self::V1_OPTION, array());
        if (!is_array($old)) { $old = array(); }
        $old_records = isset($old['records']) && is_array($old['records']) ? $old['records'] : array();
        $old_deleted = isset($old['deleted']) && is_array($old['deleted']) ? $old['deleted'] : array();
        $collections = array_values(array_unique(array_merge(array_keys($old_records), array_keys($old_deleted))));
        $has_legacy_data = false;
        foreach ($collections as $collection_slug) {
            if (!empty($old_records[$collection_slug]) || !empty($old_deleted[$collection_slug])) { $has_legacy_data = true; break; }
        }
        // A clean installation creates no database or collection. Only create the legacy
        // workspace when V1 actually contains user-managed records to preserve.
        if ($has_legacy_data) {
            if (!self::get_database('genshin-impact', true)) {
                self::insert_database('genshin-impact', 'Genshin Impact (Migrated)', 'Records preserved from the previous KG Database Manager.', 'game');
            }
            foreach ($collections as $collection_slug) {
                $slug = sanitize_title((string)$collection_slug);
                if ($slug === '') { continue; }
                if (!self::get_collection('genshin-impact', $slug, true)) {
                    $label = ucwords(str_replace(array('-', '_'), ' ', $slug));
                    self::insert_collection('genshin-impact', $slug, $label, rtrim($label, 's'), 'Migrated V1 collection. Define its fields in Collections.', array(), 0);
                }
                foreach ((array)($old_records[$collection_slug] ?? array()) as $id => $record) {
                    if (!is_array($record)) { continue; }
                    $safe_id = sanitize_title((string)($record['id'] ?? $id));
                    if ($safe_id === '') { continue; }
                    $record['id'] = $safe_id;
                    $status = !empty($old_deleted[$collection_slug][$safe_id]) ? 'deleted' : 'active';
                    if ($status === 'deleted' && isset($old['deleted_snapshots'][$collection_slug][$safe_id]) && is_array($old['deleted_snapshots'][$collection_slug][$safe_id])) {
                        $record = $old['deleted_snapshots'][$collection_slug][$safe_id];
                        $record['id'] = $safe_id;
                    }
                    self::upsert_record('genshin-impact', $slug, $safe_id, $record, $status);
                }
                foreach ((array)($old_deleted[$collection_slug] ?? array()) as $id => $flag) {
                    if (!$flag) { continue; }
                    $safe_id = sanitize_title((string)$id);
                    if ($safe_id === '') { continue; }
                    $snapshot = $old['deleted_snapshots'][$collection_slug][$safe_id]
                        ?? ($old_records[$collection_slug][$safe_id] ?? array('id'=>$safe_id));
                    if (is_array($snapshot)) {
                        $snapshot['id'] = $safe_id;
                        self::upsert_record('genshin-impact', $slug, $safe_id, $snapshot, 'deleted');
                    }
                }
            }
            update_option(self::ACTIVE_DB_OPTION, 'genshin-impact', false);
        }
        update_option('kgdm_v1_migrated', '1', false);
    }


    private static function legacy_v21_scaffold_signature() {
        // Compact fingerprints let the upgrader identify the exact V2.1 starter
        // without bundling its Genshin sample records or field schemas as content.
        return array(
            'collections' => array(
                'characters' => array('Characters','Character','Playable characters and Traveler variants.',0,'3beb18a50b14a7f132b373260ef23cca724bd75374952867e3ffed1b3d25d4e8'),
                'weapons' => array('Weapons','Weapon','Weapons and weapon progression data.',10,'8ea8e85a92f4841079de152aca3f461c1b48a7b156453c3655b54885b67d0dfe'),
                'artifact_sets' => array('Artifact Sets','Artifact Set','Artifact set effects and metadata.',20,'e7b6ce56bc482f2f97467513a97df7d8dd61422095c7008d8764772d13dae7cb'),
                'factions' => array('Factions / Organizations','Faction','Factions, groups and organizations.',30,'06768210a27d7648b97b43bc64482b23673dc7324c5ec463c9a31cf3b83ce912'),
                'enemies' => array('Enemies / Bosses','Enemy','Enemies, bosses and encounter data.',40,'c7cb94d2a0e093c92342dbaa36c0f61e4533e2cb5b9cad3734733152b4a3f68e'),
            ),
            'sample_record_hashes' => array(
                'knights-of-favonius' => 'f0a5e934b35da2829e1cf153da02cca7a0a16f2b2673d88f43b70b55bacd6b77',
                'fatui-harbingers' => 'f0edfb2d2b4e81e5595ea79bbd3544b595fdef25dd5692affb18438b4e36735c',
                'liyue-qixing' => '932a0a65b6cb0dba419b92fbd3b859de40da277f6e836f7b3cbc780ff3157ee8',
                'house-of-the-hearth' => 'f5c4ecdb4f192e8e7832384e81e9a127ec43f3b3b3a9bd68ea71fe12dffe360e',
            ),
        );
    }


    private static function cleanup_legacy_empty_seed() {
        global $wpdb;
        $database = self::get_database('genshin-impact', true);
        $legacy_description = 'Genshin Impact game database. Connected to the legacy KumarGaming Genshin tools.';
        if (!$database || ($database['name'] ?? '') !== 'Genshin Impact' || ($database['description'] ?? '') !== $legacy_description || ($database['kind'] ?? '') !== 'game' || ($database['status'] ?? '') !== 'active' || ($database['api_access'] ?? 'private') !== 'private') {
            return false;
        }

        // Compare the complete untouched V2.1 scaffold. A renamed database, edited
        // collection, changed schema, API setting, missing sample or real record is
        // preserved. Cleanup must never infer that an empty workspace is disposable.
        $signature = self::legacy_v21_scaffold_signature();
        $expected_collections = $signature['collections'];
        $collections = self::get_collections('genshin-impact', true);
        if (count($collections) !== count($expected_collections)) { return false; }
        foreach ($collections as $collection) {
            $slug = $collection['slug'];
            if (!isset($expected_collections[$slug])) { return false; }
            $expected = $expected_collections[$slug];
            $schema_hash = hash('sha256', (string)($collection['schema_json'] ?? ''));
            if ($collection['name'] !== $expected[0] || $collection['singular_name'] !== $expected[1] || $collection['description'] !== $expected[2] || (int)$collection['sort_order'] !== $expected[3] || $collection['status'] !== 'active' || !hash_equals($expected[4], $schema_hash)) {
                return false;
            }
        }

        $tables = self::table_names();
        $rows = $wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE database_id = %s', $tables['records'], 'genshin-impact'), ARRAY_A);
        $sample_hashes = $signature['sample_record_hashes'];
        if (count((array)$rows) !== count($sample_hashes)) { return false; }
        $expected_records = array();
        foreach ($collections as $collection) { $expected_records[$collection['id']] = $collection['slug']; }
        foreach ((array)$rows as $row) {
            $collection_slug = $expected_records[$row['collection_id'] ?? ''] ?? '';
            $id = (string)($row['item_key'] ?? '');
            $payload_hash = hash('sha256', (string)($row['payload'] ?? ''));
            if ($collection_slug !== 'factions' || !isset($sample_hashes[$id]) || !hash_equals($sample_hashes[$id], $payload_hash) || ($row['status'] ?? '') !== 'active') {
                return false;
            }
        }

        if ($wpdb->query('START TRANSACTION') === false) { return false; }
        $deleted_records = $wpdb->delete($tables['records'], array('database_id'=>'genshin-impact'));
        $deleted_collections = $wpdb->delete($tables['collections'], array('database_id'=>'genshin-impact'));
        $deleted_database = $wpdb->delete($tables['databases'], array('id'=>'genshin-impact'));
        if ($deleted_records === false || $deleted_records !== count($sample_hashes) || $deleted_collections === false || $deleted_collections !== count($expected_collections) || $deleted_database === false || $deleted_database < 1) {
            $wpdb->query('ROLLBACK');
            return false;
        }
        if ($wpdb->query('COMMIT') === false) {
            $wpdb->query('ROLLBACK');
            return false;
        }
        if (get_option(self::ACTIVE_DB_OPTION) === 'genshin-impact') { update_option(self::ACTIVE_DB_OPTION, '', false); }
        self::invalidate_all_query_cache();
        return true;
    }


    private static function deactivate_previous_plugins() {
        if (!function_exists('is_plugin_active')) { require_once ABSPATH . 'wp-admin/includes/plugin.php'; }
        if (!function_exists('is_plugin_active') || !function_exists('deactivate_plugins')) { return; }
        $previous = array(
            'kumar-database-manager/kumar-database-manager.php',
            'kg-genshin-database-manager/kg-genshin-database-manager.php',
        );
        foreach ($previous as $plugin_file) {
            if (is_plugin_active($plugin_file)) { deactivate_plugins($plugin_file, true); }
        }
    }


    private static function get_database($id_or_slug, $include_archived = false) {
        global $wpdb;
        $tables = self::table_names();
        $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE id = %s LIMIT 1', $tables['databases'], sanitize_key($id_or_slug)), ARRAY_A);
        if (!$row || (!$include_archived && $row['status'] !== 'active')) { return null; }
        $row['visual'] = self::decode_visual_settings($row['visual_json'] ?? '', true);
        return $row;
    }


    private static function get_databases($include_archived = false) {
        global $wpdb;
        $tables = self::table_names();
        $rows = $include_archived
            ? $wpdb->get_results($wpdb->prepare('SELECT * FROM %i ORDER BY name ASC', $tables['databases']), ARRAY_A)
            : $wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE status = %s ORDER BY name ASC", $tables['databases'], 'active'), ARRAY_A);
        if (!is_array($rows)) { return array(); }
        foreach ($rows as &$row) { $row['visual'] = self::decode_visual_settings($row['visual_json'] ?? '', true); }
        unset($row);
        return $rows;
    }

    /** Preserve a baseline snapshot for collections that predate revision history. */
    private static function backfill_template_revision_history() {
        global $wpdb;
        $tables = self::table_names();
        $rows = $wpdb->get_results($wpdb->prepare('SELECT database_id, slug, id, schema_json, form_templates_json, template_version FROM %i', $tables['collections']), ARRAY_A);
        if (!is_array($rows)) { return new WP_Error('kgdm_revision_backfill_read_failed', 'Could not inspect existing collections while preserving template history.'); }
        foreach ($rows as $row) {
            $version = max(1, (int)($row['template_version'] ?? 1));
            $exists = (int)$wpdb->get_var($wpdb->prepare(
                'SELECT COUNT(*) FROM %i WHERE collection_id = %s AND version = %d',
                $tables['template_versions'], (string)$row['id'], $version
            ));
            if ($exists > 0) { continue; }
            $schema = json_decode((string)($row['schema_json'] ?? '[]'), true);
            $templates = json_decode((string)($row['form_templates_json'] ?? '[]'), true);
            if (!is_array($schema)) { $schema = array(); }
            if (!is_array($templates)) { $templates = array(); }
            if (self::add_template_revision((string)$row['database_id'], (string)$row['slug'], $version, $schema, $templates, array('baseline'=>true,'backfilled'=>true,'note'=>'Baseline captured during Phase 5 upgrade.')) === false) {
                return new WP_Error('kgdm_revision_backfill_failed', 'Could not preserve the current template definition for collection ' . (string)$row['slug'] . '.');
            }
        }
        return true;
    }

    private static function add_template_revision($database_id, $collection_slug, $version, $schema, $templates, $summary = array()) {
        global $wpdb;
        $tables = self::table_names();
        $collection_id = self::collection_id($database_id, $collection_slug);
        $existing = (int)$wpdb->get_var($wpdb->prepare('SELECT revision_id FROM %i WHERE collection_id = %s AND version = %d', $tables['template_versions'], $collection_id, (int)$version));
        if ($existing) { return $existing; }
        $ok = $wpdb->insert($tables['template_versions'], array(
            'database_id' => $database_id,
            'collection_id' => $collection_id,
            'collection_slug' => $collection_slug,
            'version' => max(1, (int)$version),
            'schema_json' => wp_json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'form_templates_json' => wp_json_encode($templates, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'change_summary' => wp_json_encode($summary, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'created_at' => self::now(),
            'created_by' => get_current_user_id(),
        ));
        return $ok ? (int)$wpdb->insert_id : false;
    }

    private static function get_template_revisions($database_id, $collection_slug, $limit = 25) {
        global $wpdb;
        $tables = self::table_names();
        $collection_id = self::collection_id($database_id, $collection_slug);
        $rows = $wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE collection_id = %s ORDER BY version DESC LIMIT %d', $tables['template_versions'], $collection_id, max(1, (int)$limit)), ARRAY_A);
        if (!is_array($rows)) { $rows = array(); }
        foreach ($rows as &$row) {
            $row['schema'] = json_decode((string)$row['schema_json'], true) ?: array();
            $row['form_templates'] = json_decode((string)$row['form_templates_json'], true) ?: array();
            $row['change_summary_data'] = json_decode((string)$row['change_summary'], true) ?: array();
        }
        unset($row);
        return is_array($rows) ? $rows : array();
    }

    private static function flatten_schema_fields($schema, $prefix = '') {
        $flat = array();
        foreach ((array)$schema as $field) {
            $key = (string)($field['key'] ?? '');
            if ($key === '') { continue; }
            $path = $prefix === '' ? $key : $prefix . '.' . $key;
            $flat[$path] = $field;
            if (in_array(($field['type'] ?? ''), array('group','repeater'), true)) {
                foreach (self::flatten_schema_fields($field['children'] ?? array(), $path) as $child_path => $child) {
                    $flat[$child_path] = $child;
                }
            }
        }
        return $flat;
    }

    private static function schema_diff($old_schema, $new_schema, $old_templates = array(), $new_templates = array()) {
        $old = self::flatten_schema_fields($old_schema);
        $new = self::flatten_schema_fields($new_schema);
        $added = array_values(array_diff(array_keys($new), array_keys($old)));
        $removed = array_values(array_diff(array_keys($old), array_keys($new)));
        $changed = array();
        foreach (array_intersect(array_keys($old), array_keys($new)) as $key) {
            if (wp_json_encode($old[$key]) !== wp_json_encode($new[$key])) {
                $changed[] = array(
                    'key' => $key,
                    'old_type' => (string)($old[$key]['type'] ?? 'text'),
                    'new_type' => (string)($new[$key]['type'] ?? 'text'),
                    'type_changed' => (string)($old[$key]['type'] ?? '') !== (string)($new[$key]['type'] ?? ''),
                );
            }
        }
        $old_tpl = array(); foreach ((array)$old_templates as $tpl) { if (!empty($tpl['category'])) { $old_tpl[$tpl['category']] = $tpl; } }
        $new_tpl = array(); foreach ((array)$new_templates as $tpl) { if (!empty($tpl['category'])) { $new_tpl[$tpl['category']] = $tpl; } }
        return array(
            'added_fields' => $added,
            'removed_fields_retained' => $removed,
            'changed_fields' => $changed,
            'added_templates' => array_values(array_diff(array_keys($new_tpl), array_keys($old_tpl))),
            'removed_templates' => array_values(array_diff(array_keys($old_tpl), array_keys($new_tpl))),
            'templates_changed' => wp_json_encode($old_templates) !== wp_json_encode($new_templates),
            'old_field_count' => count($old),
            'new_field_count' => count($new),
        );
    }

    private static function is_list_array($value) {
        if (!is_array($value)) { return false; }
        $expected = 0;
        foreach (array_keys($value) as $key) { if ($key !== $expected++) { return false; } }
        return true;
    }

    private static function template_default_paths($defaults, $prefix = '') {
        $paths = array();
        foreach ((array)$defaults as $key => $value) {
            $key = (string)$key;
            if ($key === '') { continue; }
            $path = $prefix === '' ? $key : $prefix . '.' . $key;
            $paths[] = $path;
            if (is_array($value) && !self::is_list_array($value)) {
                $paths = array_merge($paths, self::template_default_paths($value, $path));
            }
        }
        return $paths;
    }

    private static function validate_templates_against_schema($templates, $schema) {
        $available = self::flatten_schema_fields($schema);
        $top_level = array();
        foreach ((array)$schema as $field) { if (!empty($field['key'])) { $top_level[$field['key']] = true; } }
        $check_conditions = function($fields, $prefix = '') use (&$check_conditions, $available, $top_level) {
            $siblings = array();
            foreach ((array)$fields as $candidate) { if (!empty($candidate['key'])) { $siblings[(string)$candidate['key']] = true; } }
            foreach ((array)$fields as $field) {
                $key = (string)($field['key'] ?? '');
                if ($key === '') { continue; }
                $path = $prefix === '' ? $key : $prefix . '.' . $key;
                $dependency = (string)($field['show_if']['field'] ?? '');
                $relative_dependency = $prefix !== '' && $dependency !== '' ? $prefix . '.' . $dependency : '';
                if ($dependency !== '' && !isset($available[$dependency]) && !isset($available[$relative_dependency]) && !isset($siblings[$dependency]) && !isset($top_level[$dependency])) {
                    return new WP_Error('schema_condition_unknown_field', 'Conditional field "' . ($field['label'] ?? $key) . '" refers to an unknown dependency: ' . $dependency);
                }
                if (in_array(($field['type'] ?? ''), array('group','repeater'), true)) {
                    $nested = $check_conditions($field['children'] ?? array(), $path);
                    if (is_wp_error($nested)) { return $nested; }
                }
            }
            return true;
        };
        $condition_check = $check_conditions($schema);
        if (is_wp_error($condition_check)) { return $condition_check; }
        foreach ((array)$templates as $template) {
            foreach ((array)($template['visible_fields'] ?? array()) as $key) {
                if (!isset($top_level[$key])) { return new WP_Error('template_unknown_field', 'Template "' . ($template['name'] ?? '') . '" refers to a visible field that is not in the collection schema: ' . $key); }
            }
            foreach ((array)($template['required_fields'] ?? array()) as $key) {
                if (!isset($top_level[$key])) { return new WP_Error('template_unknown_field', 'Template "' . ($template['name'] ?? '') . '" refers to a required field that is not in the collection schema: ' . $key); }
                if (!empty($template['visible_fields']) && !in_array($key, $template['visible_fields'], true)) {
                    return new WP_Error('template_required_hidden', 'Required template field "' . $key . '" must also be visible.');
                }
            }
            foreach (self::template_default_paths((array)($template['defaults'] ?? array())) as $path) {
                if (!isset($available[$path])) {
                    return new WP_Error('template_unknown_field', 'Template "' . ($template['name'] ?? '') . '" default refers to a field that is not in the collection schema: ' . $path);
                }
            }
        }
        return true;
    }

    private static function set_default_paths(&$record, $old_fields, $new_schema, $prefix = '') {
        $changed = false;
        foreach ((array)$new_schema as $field) {
            $key = (string)($field['key'] ?? '');
            if ($key === '') { continue; }
            $path = $prefix === '' ? $key : $prefix . '.' . $key;
            $exists_in_old = isset($old_fields[$path]);
            $has_value = array_key_exists($key, $record);
            if (!$exists_in_old && !$has_value && array_key_exists('default', $field)) {
                $record[$key] = $field['default'];
                $has_value = true;
                $changed = true;
            }
            if (($field['type'] ?? '') === 'group') {
                if (!$has_value && !$exists_in_old) { $record[$key] = array(); $has_value = true; $changed = true; }
                if (isset($record[$key]) && is_array($record[$key])) {
                    $sub_changed = self::set_default_paths($record[$key], $old_fields, $field['children'] ?? array(), $path);
                    $changed = $changed || $sub_changed;
                }
            } elseif (($field['type'] ?? '') === 'repeater' && isset($record[$key]) && is_array($record[$key])) {
                foreach ($record[$key] as $row_index => $row_value) {
                    if (!is_array($row_value)) { continue; }
                    $sub_changed = self::set_default_paths($record[$key][$row_index], $old_fields, $field['children'] ?? array(), $path);
                    $changed = $changed || $sub_changed;
                }
            }
        }
        return $changed;
    }

    private static function apply_added_field_defaults($database_id, $collection_slug, $old_schema, $new_schema) {
        global $wpdb;
        $tables = self::table_names();
        $old_fields = self::flatten_schema_fields($old_schema);
        $collection = self::get_collection($database_id, $collection_slug, true);
        if (!$collection) { return 0; }
        $rows = $wpdb->get_results($wpdb->prepare('SELECT record_id, payload FROM %i WHERE database_id = %s AND collection_id = %s', $tables['records'], $database_id, $collection['id']), ARRAY_A);
        $updated = 0;
        foreach ((array)$rows as $row) {
            $record = json_decode((string)$row['payload'], true);
            if (!is_array($record)) { continue; }
            if (self::set_default_paths($record, $old_fields, $new_schema)) {
                $encoded = self::encode_record_payload($record);
                $result = is_wp_error($encoded) ? false : $wpdb->update($tables['records'], array('payload'=>$encoded['json'],'payload_hash'=>$encoded['hash'],'payload_version'=>$encoded['version'],'payload_format'=>$encoded['format'],'updated_at'=>self::now()), array('record_id'=>(int)$row['record_id']));
                if ($result !== false) { $updated++; }
            }
        }
        return $updated;
    }

    private static function collection_parent_slug($collection) {
        if (empty($collection['parent_id'])) { return ''; }
        $parent = self::get_collection_by_id((string)$collection['database_id'], (string)$collection['parent_id'], true);
        return $parent ? (string)$parent['slug'] : '';
    }

    private static function get_collection_by_id($database_id, $collection_id, $include_archived = false) {
        global $wpdb;
        $tables = self::table_names();
        $row = $wpdb->get_row($wpdb->prepare('SELECT slug FROM %i WHERE database_id = %s AND id = %s LIMIT 1', $tables['collections'], $database_id, $collection_id), ARRAY_A);
        if (!$row) { return null; }
        return self::get_collection($database_id, $row['slug'], $include_archived);
    }

    private static function get_collections($database_id, $include_archived = false) {
        global $wpdb;
        $tables = self::table_names();
        $rows = ($include_archived
                ? $wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE database_id = %s ORDER BY sort_order ASC, name ASC', $tables['collections'], $database_id), ARRAY_A)
                : $wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE database_id = %s AND status = %s ORDER BY sort_order ASC, name ASC", $tables['collections'], $database_id, 'active'), ARRAY_A));
        $out = array();
        foreach ((array)$rows as $row) {
            $schema = json_decode((string)$row['schema_json'], true);
            $templates = json_decode((string)($row['form_templates_json'] ?? '[]'), true);
            $row['schema'] = is_array($schema) ? $schema : array();
            $row['form_templates'] = is_array($templates) ? $templates : array();
            $row['visual'] = self::decode_visual_settings($row['visual_json'] ?? '', false);
            $sections = json_decode((string)($row['sections_json'] ?? '[]'), true);
            $row['sections'] = self::sanitize_collection_sections(is_array($sections) ? $sections : array());
            $row['collection_mode'] = in_array(($row['collection_mode'] ?? 'form'), array('form','list'), true) ? $row['collection_mode'] : 'form';
            $row['parent_id'] = (string)($row['parent_id'] ?? '');
            $row['trash_batch_id'] = (string)($row['trash_batch_id'] ?? '');
            $out[] = $row;
        }
        return $out;
    }

    /** Return a folder and all descendants once, even if legacy data contains a parent cycle. */
    private static function collection_subtree($collections, $root_id) {
        $children = array();
        foreach ((array)$collections as $collection) {
            $parent_id = (string)($collection['parent_id'] ?? '');
            if (!isset($children[$parent_id])) { $children[$parent_id] = array(); }
            $children[$parent_id][] = $collection;
        }
        $by_id = array();
        foreach ((array)$collections as $collection) { $by_id[(string)$collection['id']] = $collection; }
        if (!isset($by_id[(string)$root_id])) { return array(); }
        $result = array(); $visited = array();
        $visit = function($id) use (&$visit, &$result, &$visited, $children, $by_id) {
            $id = (string)$id;
            if (isset($visited[$id]) || !isset($by_id[$id])) { return; }
            $visited[$id] = true;
            $result[] = $by_id[$id];
            foreach ((array)($children[$id] ?? array()) as $child) { $visit($child['id']); }
        };
        $visit($root_id);
        return $result;
    }

    /** Archive a folder and only its currently-active descendants as one recoverable Trash group. */
    private static function archive_collection_subtree($database_id, $root_collection) {
        global $wpdb;
        $tables = self::table_names();
        if (!$root_collection || ($root_collection['status'] ?? 'active') !== 'active') { return false; }
        $all = self::get_collections($database_id, true);
        $subtree = self::collection_subtree($all, $root_collection['id']);
        if (empty($subtree)) { return false; }
        $batch_id = wp_generate_uuid4();
        if ($wpdb->query('START TRANSACTION') === false) { return false; }
        $changed = array();
        $preserved_archived_ancestors = array();
        foreach ($subtree as $item) {
            $item_id = (string)$item['id'];
            $parent_id = (string)($item['parent_id'] ?? '');
            // A separately trashed folder owns its own subtree state. Do not
            // include it or its descendants in this parent's trash batch.
            if ($item_id !== (string)$root_collection['id'] && isset($preserved_archived_ancestors[$parent_id])) {
                $preserved_archived_ancestors[$item_id] = true;
                continue;
            }
            if (($item['status'] ?? 'active') !== 'active') {
                $preserved_archived_ancestors[$item_id] = true;
                continue;
            }
            $result = $wpdb->update($tables['collections'], array(
                'status'=>'archived',
                'trash_batch_id'=>$batch_id,
                'updated_at'=>self::now(),
            ), array('id'=>$item_id, 'database_id'=>$database_id, 'status'=>'active'));
            if ($result === false || $result < 1) { $wpdb->query('ROLLBACK'); return false; }
            $changed[] = (string)$item['slug'];
        }
        if (empty($changed) || $wpdb->query('COMMIT') === false) {
            $wpdb->query('ROLLBACK');
            return false;
        }
        foreach ($changed as $slug) { self::invalidate_collection_query_cache($database_id, $slug); }
        return true;
    }

    /** Restore only the folder group moved by the same parent delete action. */
    private static function restore_collection_subtree($database_id, $root_collection) {
        global $wpdb;
        $tables = self::table_names();
        if (!$root_collection || ($root_collection['status'] ?? '') !== 'archived') { return false; }
        $ancestor_id = (string)($root_collection['parent_id'] ?? '');
        $ancestor_seen = array();
        while ($ancestor_id !== '' && !isset($ancestor_seen[$ancestor_id])) {
            $ancestor_seen[$ancestor_id] = true;
            $ancestor = self::get_collection_by_id($database_id, $ancestor_id, true);
            if (!$ancestor) { break; }
            if (($ancestor['status'] ?? 'active') === 'archived') {
                return new WP_Error('kgdm_trash_parent_first', 'Restore the parent folder first. This item will become available in Trash after its parent is restored.');
            }
            $ancestor_id = (string)($ancestor['parent_id'] ?? '');
        }
        $batch_id = (string)($root_collection['trash_batch_id'] ?? '');
        if ($batch_id !== '') {
            $rows = $wpdb->get_results($wpdb->prepare('SELECT id, slug FROM %i WHERE database_id = %s AND status = %s AND trash_batch_id = %s', $tables['collections'], $database_id, 'archived', $batch_id), ARRAY_A);
            if (!is_array($rows) || empty($rows)) { return false; }
        } else {
            // Legacy v3.2.14 folders have no batch metadata; restore only the selected row.
            $rows = array(array('id'=>$root_collection['id'], 'slug'=>$root_collection['slug']));
        }
        if ($wpdb->query('START TRANSACTION') === false) { return false; }
        $slugs = array();
        foreach ($rows as $row) {
            $result = $wpdb->update($tables['collections'], array('status'=>'active','trash_batch_id'=>'','updated_at'=>self::now()), array('id'=>(string)$row['id'],'database_id'=>$database_id,'status'=>'archived'));
            if ($result === false || $result < 1) { $wpdb->query('ROLLBACK'); return false; }
            $slugs[] = (string)$row['slug'];
        }
        if ($wpdb->query('COMMIT') === false) { $wpdb->query('ROLLBACK'); return false; }
        foreach ($slugs as $slug) { self::invalidate_collection_query_cache($database_id, $slug); }
        return true;
    }

    /** Only top-level entries of a grouped folder deletion are shown in Trash. */
    private static function collection_is_trash_root($collection, $by_id) {
        // An archived item is visible in Trash only when every known ancestor is
        // active. This prevents actions on a child hidden inside a trashed parent.
        $ancestor_id = (string)($collection['parent_id'] ?? '');
        $seen = array();
        while ($ancestor_id !== '' && !isset($seen[$ancestor_id])) {
            $seen[$ancestor_id] = true;
            if (!isset($by_id[$ancestor_id])) { return true; }
            $ancestor = $by_id[$ancestor_id];
            if (($ancestor['status'] ?? 'active') === 'archived') { return false; }
            $ancestor_id = (string)($ancestor['parent_id'] ?? '');
        }
        return true;
    }

    private static function get_trashed_records($database_id = '', $collection_slug = '', $limit = 50, $offset = 0) {
        global $wpdb;
        $tables = self::table_names();
        $sql = 'SELECT r.record_id, r.database_id, r.collection_id, r.item_key, r.item_name, r.updated_at, c.slug AS collection_slug, c.name AS collection_name, d.name AS database_name FROM %i r INNER JOIN %i c ON c.id = r.collection_id AND c.status = %s INNER JOIN %i d ON d.id = r.database_id AND d.status = %s WHERE r.status = %s';
        $args = array($tables['records'], $tables['collections'], 'active', $tables['databases'], 'active', 'deleted');
        if ($database_id !== '') { $sql .= ' AND r.database_id = %s'; $args[] = $database_id; }
        if ($collection_slug !== '') { $sql .= ' AND c.slug = %s'; $args[] = $collection_slug; }
        $limit = min(200, max(1, (int)$limit));
        $offset = max(0, (int)$offset);
        $sql .= ' ORDER BY r.updated_at DESC, r.item_name ASC LIMIT %d OFFSET %d';
        $args[] = $limit; $args[] = $offset;
        $rows = $wpdb->get_results($wpdb->prepare($sql, $args), ARRAY_A);
        return is_array($rows) ? $rows : array();
    }

    private static function get_trash_counts($database_id = '', $collection_slug = '') {
        global $wpdb;
        $tables = self::table_names();
        $archived_databases = count(array_filter(self::get_databases(true), function($row) { return ($row['status'] ?? '') === 'archived'; }));
        $folder_count = 0;
        $databases = $database_id !== '' ? array_filter(self::get_databases(false), function($row) use ($database_id) { return $row['id'] === $database_id; }) : self::get_databases(false);
        foreach ($databases as $db) {
            $collections = self::get_collections($db['id'], true); $by_id = array();
            foreach ($collections as $collection) { $by_id[(string)$collection['id']] = $collection; }
            foreach ($collections as $collection) {
                if (($collection['status'] ?? '') === 'archived' && self::collection_is_trash_root($collection, $by_id)) { $folder_count++; }
            }
        }
        $record_sql = 'SELECT COUNT(*) FROM %i r INNER JOIN %i c ON c.id = r.collection_id AND c.status = %s INNER JOIN %i d ON d.id = r.database_id AND d.status = %s WHERE r.status = %s';
        $record_args = array($tables['records'], $tables['collections'], 'active', $tables['databases'], 'active', 'deleted');
        if ($database_id !== '') { $record_sql .= ' AND r.database_id = %s'; $record_args[] = $database_id; }
        if ($collection_slug !== '') { $record_sql .= ' AND c.slug = %s'; $record_args[] = $collection_slug; }
        $record_count = (int)$wpdb->get_var($wpdb->prepare($record_sql, $record_args));
        return array('databases'=>$archived_databases,'folders'=>$folder_count,'records'=>$record_count);
    }

    /** Fetch counts for every folder in one query instead of issuing a query per tree row. */
    private static function collection_record_counts($database_id, $include_deleted = false) {
        global $wpdb;
        if ($database_id === 'genshin-impact' && function_exists('kg_genshin_master_data')) { return null; }
        $tables = self::table_names();
        $query = $include_deleted
            ? $wpdb->prepare('SELECT collection_id, COUNT(*) AS record_count FROM %i WHERE database_id = %s AND status IN (%s, %s) GROUP BY collection_id', $tables['records'], $database_id, 'active', 'deleted')
            : $wpdb->prepare('SELECT collection_id, COUNT(*) AS record_count FROM %i WHERE database_id = %s AND status = %s GROUP BY collection_id', $tables['records'], $database_id, 'active');
        $rows = $wpdb->get_results($query, ARRAY_A);
        if ($wpdb->last_error !== '') { return null; }
        $counts = array();
        foreach ((array)$rows as $row) { $counts[(string)$row['collection_id']] = (int)$row['record_count']; }
        return $counts;
    }

    /** Delete rows by a bounded, prepared IN list; an optional scope keeps IDs tied to their database. */
    private static function delete_rows_in_column($table, $column, $ids, $scope_column = '', $scope_value = '') {
        global $wpdb;
        $ids = array_values(array_unique(array_filter(array_map('strval', (array)$ids), function($id) { return $id !== ''; })));
        if (empty($ids)) { return 0; }
        $placeholders = implode(',', array_fill(0, count($ids), '%s'));
        $query = 'DELETE FROM %i WHERE ';
        $args = array($table);
        if ($scope_column !== '') {
            $query .= '%i = %s AND ';
            $args[] = $scope_column;
            $args[] = (string)$scope_value;
        }
        $query .= '%i IN (' . $placeholders . ')';
        $args[] = $column;
        $args = array_merge($args, $ids);
        return $wpdb->query($wpdb->prepare($query, $args));
    }

    private static function db_record_entries($database_id, $collection_slug, $status = 'all', $limit = 0, $offset = 0) {
        global $wpdb;
        $tables = self::table_names();
        $collection = self::get_collection($database_id, $collection_slug, true);
        if (!$collection) { return array(); }
        if (!in_array($status, array('all','active','deleted'), true)) { $status = 'active'; }
        $limit = max(0, (int)$limit);
        $offset = max(0, (int)$offset);
        if ($status === 'all' && $limit > 0) {
            $rows = $wpdb->get_results($wpdb->prepare('SELECT item_key, payload, payload_hash, status FROM %i WHERE database_id = %s AND collection_id = %s ORDER BY item_name ASC LIMIT %d OFFSET %d', $tables['records'], $database_id, $collection['id'], $limit, $offset), ARRAY_A);
        } elseif ($status === 'all') {
            $rows = $wpdb->get_results($wpdb->prepare('SELECT item_key, payload, payload_hash, status FROM %i WHERE database_id = %s AND collection_id = %s ORDER BY item_name ASC', $tables['records'], $database_id, $collection['id']), ARRAY_A);
        } elseif ($limit > 0) {
            $rows = $wpdb->get_results($wpdb->prepare('SELECT item_key, payload, payload_hash, status FROM %i WHERE database_id = %s AND collection_id = %s AND status = %s ORDER BY item_name ASC LIMIT %d OFFSET %d', $tables['records'], $database_id, $collection['id'], $status, $limit, $offset), ARRAY_A);
        } else {
            $rows = $wpdb->get_results($wpdb->prepare('SELECT item_key, payload, payload_hash, status FROM %i WHERE database_id = %s AND collection_id = %s AND status = %s ORDER BY item_name ASC', $tables['records'], $database_id, $collection['id'], $status), ARRAY_A);
        }
        $out = array();
        foreach ((array)$rows as $row) {
            $record = self::decode_record_payload((string)$row['payload'], (string)($row['payload_hash'] ?? ''));
            if (is_wp_error($record)) { continue; }
            $record['id'] = $row['item_key'];
            $out[$row['item_key']] = array('record'=>$record,'status'=>$row['status']);
        }
        return $out;
    }

    private static function db_records($database_id, $collection_slug, $status = 'active', $limit = 0, $offset = 0) {
        $entries = self::db_record_entries($database_id, $collection_slug, $status, $limit, $offset);
        $out = array();
        foreach ($entries as $id => $entry) { $out[$id] = $entry['record']; }
        return $out;
    }

    /** Fetch one managed record without loading its entire collection. */
    private static function db_record_entry($database_id, $collection_slug, $record_id) {
        global $wpdb;
        $tables = self::table_names();
        $collection = self::get_collection($database_id, $collection_slug, true);
        if (!$collection) { return null; }
        $row = $wpdb->get_row($wpdb->prepare(
            'SELECT item_key, payload, payload_hash, status FROM %i WHERE database_id = %s AND collection_id = %s AND item_key = %s LIMIT 1',
            $tables['records'], $database_id, $collection['id'], sanitize_title((string)$record_id)
        ), ARRAY_A);
        if (!$row) { return null; }
        $record = self::decode_record_payload($row['payload'], (string)($row['payload_hash'] ?? ''));
        if (is_wp_error($record)) { return null; }
        $record['id'] = $row['item_key'];
        return array('record'=>$record,'status'=>$row['status']);
    }

    /** Resolve one active or deleted record, using the legacy master only for Genshin. */
    private static function get_admin_record($database_id, $collection_slug, $record_id, $include_deleted = false) {
        $id = sanitize_title((string)$record_id);
        if ($id === '') { return null; }
        if ($database_id === 'genshin-impact' && function_exists('kg_genshin_master_data')) {
            $records = self::get_admin_records($database_id, $collection_slug, $include_deleted);
            return isset($records[$id]) ? $records[$id] : null;
        }
        $entry = self::db_record_entry($database_id, $collection_slug, $id);
        if (!$entry || (!$include_deleted && $entry['status'] !== 'active')) { return null; }
        return $entry['record'];
    }

    private static function upsert_record($database_id, $collection_slug, $id, $record, $status = 'active', $invalidate_cache = true) {
        global $wpdb;
        $tables = self::table_names();
        $collection = self::get_collection($database_id, $collection_slug, true);
        if (!$collection) { return false; }
        $id = sanitize_title((string)$id);
        if ($id === '' || !is_array($record)) { return false; }
        if (array_key_exists('_kgdm_publication', $record)) {
            $publication_check = self::validate_record_publication_dates($record);
            if (is_wp_error($publication_check)) { return false; }
        }
        $record['id'] = $id;
        $name = (string)($record['name'] ?? $record['title'] ?? $record['label'] ?? $id);
        $encoded = self::encode_record_payload($record);
        if (is_wp_error($encoded)) { return false; }
        $payload = $encoded['json'];
        $existing = $wpdb->get_var($wpdb->prepare('SELECT record_id FROM %i WHERE collection_id = %s AND item_key = %s LIMIT 1', $tables['records'], $collection['id'], $id));
        $data = array(
            'database_id' => $database_id,
            'collection_id' => $collection['id'],
            'item_key' => $id,
            'item_name' => sanitize_text_field($name),
            'payload' => $payload,
            'payload_hash' => $encoded['hash'],
            'payload_version' => $encoded['version'],
            'payload_format' => $encoded['format'],
            'status' => $status,
            'updated_at' => self::now(),
            'updated_by' => get_current_user_id(),
        );
        if ($existing) {
            $ok = $wpdb->update($tables['records'], $data, array('record_id' => (int)$existing)) !== false;
            if ($ok) { self::schedule_record_visibility_events($database_id, $collection_slug, $id, $record, $status); if ($invalidate_cache) { self::flush_record_cache($database_id, $collection_slug, $id); } }
            return $ok;
        }
        $data['created_at'] = self::now();
        $ok = $wpdb->insert($tables['records'], $data) !== false;
        if ($ok) { self::schedule_record_visibility_events($database_id, $collection_slug, $id, $record, $status); if ($invalidate_cache) { self::flush_record_cache($database_id, $collection_slug, $id); } }
        return $ok;
    }

    /** Rename a record atomically so a failed insert cannot leave the original inactive. */
    private static function rename_record($database_id, $collection_slug, $old_id, $new_id, $old_record, $new_record) {
        global $wpdb;
        $old_id = sanitize_title((string)$old_id);
        $new_id = sanitize_title((string)$new_id);
        if ($old_id === '' || $new_id === '' || $old_id === $new_id || !is_array($old_record) || !is_array($new_record)) { return false; }
        if ($wpdb->query('START TRANSACTION') === false) { return false; }
        $old_saved = self::upsert_record($database_id, $collection_slug, $old_id, $old_record, 'deleted', false);
        $new_saved = $old_saved && self::upsert_record($database_id, $collection_slug, $new_id, $new_record, 'active', false);
        if (!$old_saved || !$new_saved) {
            $wpdb->query('ROLLBACK');
            return false;
        }
        if ($wpdb->query('COMMIT') === false) {
            $wpdb->query('ROLLBACK');
            return false;
        }
        self::invalidate_collection_query_cache($database_id, $collection_slug);
        return true;
    }

    private static function is_legacy_master_record($database_id, $collection_slug, $record_id) {
        if ($database_id !== 'genshin-impact' || !function_exists('kg_genshin_master_data')) { return false; }
        $master = kg_genshin_master_data();
        $source = self::extract_legacy_collection($master, $collection_slug);
        return isset($source[sanitize_title((string)$record_id)]);
    }

    private static function extract_legacy_collection($dataset, $collection) {
        if (!is_array($dataset)) { return array(); }
        if ($collection === 'characters') {
            $source = isset($dataset['characters']['items']) && is_array($dataset['characters']['items']) ? $dataset['characters']['items'] : (isset($dataset['characters']) && is_array($dataset['characters']) ? $dataset['characters'] : array());
        } else {
            $source = isset($dataset[$collection]['items']) && is_array($dataset[$collection]['items']) ? $dataset[$collection]['items'] : array();
        }
        $out = array();
        foreach ($source as $key => $record) {
            if (!is_array($record)) { continue; }
            $id = sanitize_title((string)($record['id'] ?? $key));
            if ($id !== '') { $record['id'] = $id; $out[$id] = $record; }
        }
        return $out;
    }

    private static function write_legacy_collection(&$dataset, $collection, $items) {
        if ($collection === 'characters') { $dataset['characters'] = array_values($items); return; }
        if (!isset($dataset[$collection]) || !is_array($dataset[$collection])) { $dataset[$collection] = array(); }
        $dataset[$collection]['status'] = !empty($items) ? 'loaded_with_database_manager' : 'empty';
        $dataset[$collection]['items'] = $items;
        $dataset[$collection]['count'] = count($items);
    }

    public function filter_genshin_master_data($dataset) {
        if (!is_array($dataset)) { return $dataset; }
        $legacy = array('characters','weapons','artifact_sets','factions','enemies');
        foreach ($legacy as $collection) {
            $items = self::extract_legacy_collection($dataset, $collection);
            $managed = self::db_record_entries('genshin-impact', $collection, 'all');
            foreach ($managed as $id => $entry) {
                if (in_array($entry['status'], array('deleted','purged'), true)) { unset($items[$id]); }
                else { $items[$id] = $entry['record']; }
            }
            self::write_legacy_collection($dataset, $collection, $items);
        }
        $character_items = isset($dataset['characters']) && is_array($dataset['characters']) ? $dataset['characters'] : array();
        $playable_count = 0;
        $playable_without_traveler = 0;
        $rarity_counts = array(4 => 0, 5 => 0);
        $weapon_counts = array();
        foreach ($character_items as $character) {
            if (!is_array($character)) { continue; }
            $id = sanitize_title((string)($character['id'] ?? ''));
            $playable = !isset($character['is_playable']) || !empty($character['is_playable']);
            if ($playable) {
                $playable_count++;
                if ($id !== 'traveler') {
                    $rarity = (int)($character['rarity'] ?? 0);
                    if (isset($rarity_counts[$rarity])) { $rarity_counts[$rarity]++; }
                    if (!empty($character['weapon'])) { $weapon = (string)$character['weapon']; $weapon_counts[$weapon] = (int)($weapon_counts[$weapon] ?? 0) + 1; }
                    $playable_without_traveler++;
                }
            }
        }
        if (!isset($dataset['meta']) || !is_array($dataset['meta'])) { $dataset['meta'] = array(); }
        $dataset['meta']['roster_count'] = count($character_items);
        $dataset['meta']['playable_character_count_including_traveler'] = $playable_count;
        $dataset['meta']['playable_character_count_excluding_traveler'] = $playable_without_traveler;
        if (!isset($dataset['meta']['catalogue_summary']) || !is_array($dataset['meta']['catalogue_summary'])) { $dataset['meta']['catalogue_summary'] = array(); }
        $dataset['meta']['catalogue_summary']['rarity_5_star_excluding_traveler'] = $rarity_counts[5];
        $dataset['meta']['catalogue_summary']['rarity_4_star'] = $rarity_counts[4];
        $dataset['meta']['catalogue_summary']['weapon_counts_excluding_traveler'] = $weapon_counts;
        if (isset($dataset['meta']['phase_status']) && is_array($dataset['meta']['phase_status'])) { $dataset['meta']['phase_status']['character_catalogue'] = 'master_database_with_database_manager_v2'; }
        $managed_count = 0;
        foreach ($legacy as $collection) { $managed_count += count(self::db_record_entries('genshin-impact', $collection, 'all')); }
        $dataset['meta']['data_manager'] = array(
            'plugin' => 'KG Database Management',
            'plugin_version' => self::VERSION,
            'plugin_connected' => true,
            'updated_at' => self::database_updated_at('genshin-impact'),
            'managed_record_count' => $managed_count,
            'database_id' => 'genshin-impact',
        );
        return $dataset;
    }

    private static function record_status($database_id, $collection_slug, $item_key) {
        global $wpdb;
        $tables = self::table_names();
        $collection = self::get_collection($database_id, $collection_slug, true);
        if (!$collection) { return ''; }
        return (string)$wpdb->get_var($wpdb->prepare('SELECT status FROM %i WHERE collection_id = %s AND item_key = %s LIMIT 1', $tables['records'], $collection['id'], $item_key));
    }

    private static function database_updated_at($database_id) {
        global $wpdb;
        $tables = self::table_names();
        return (string)$wpdb->get_var($wpdb->prepare('SELECT updated_at FROM %i WHERE id = %s', $tables['databases'], $database_id));
    }

    private static function require_admin() {
        if (!current_user_can('manage_options')) { wp_die(esc_html__('You do not have permission to manage databases.', 'kg-database-management')); }
    }

    private static function changelog() {
        return array(
            array('version'=>'3.2.23','date'=>'2026-11-13','title'=>'Modern Trash recovery center, List/Grid views and bulk actions','items'=>array(
                'Rebuilt Trash with clearer recovery guidance, category summaries, scoped search, modern item cards and responsive List/Grid layouts for Databases, Folders & forms and Records.',
                'Added single-item selection, select-this-page controls, selected counts and bulk Restore / Delete permanently actions for each Trash category. Bulk operations validate each item separately and report completed/skipped totals.',
                'Added independent 20-item pagination to database, folder and record sections, preserving other section page indexes, database/collection scope and selected layout.',
                'Kept individual Restore and Delete permanently actions alongside bulk actions. Permanent deletion still requires confirmation in the UI and retains transaction, snapshot, parent/child and Genshin source tombstone safeguards.',
                'Added accessible selection controls, page-level selection state, search-aware selection clearing, selected-card styling and responsive action layouts.',
                'No database schema, record format, REST endpoint, import/export, backup or uninstall behavior changes.'
            )),
            array('version'=>'3.2.21','date'=>'2026-11-13','title'=>'Cleaner page header, breadcrumb, bulk toolbar and theme quick toggle','items'=>array(
                'Removed the redundant KGDM page-level brand header and reclaimed vertical space in every workspace view.',
                'Moved the database selector into the right side of the view header so database context remains accessible without the extra header.',
                'Added a compact view-header Light/Dark toggle with an amber sun and blue moon icon; it switches immediately and saves the appearance preference through a capability-checked, nonce-protected AJAX action.',
                'Preserved System appearance as the default. The quick toggle selects an explicit Light or Dark mode; users can return to System from Settings.',
                'Restyled record breadcrumbs with clear database/folder hierarchy, compact separators, accessible current-page semantics and responsive wrapping.',
                'Rebuilt the bulk-edit toolbar with a clear heading, grouped controls, consistent input sizing, stronger action hierarchy and responsive layouts.',
                'No storage schema, record format, import/export, Trash, backup, publication or REST behavior changes.'
            )),
            array('version'=>'3.2.20','date'=>'2026-11-13','title'=>'Appearance and publishing reliability fixes','items'=>array(
                'Fixed database background-image CSS URL escaping so selected Media Library backgrounds render correctly on database cards.',
                'Preserved existing database icon and background attachments when editing database settings without the upload_files capability.',
                'Added safe database and folder appearance metadata to public REST responses; attachment IDs are converted to image URLs and are not exposed.',
                'Included hierarchical section definitions in public REST collection responses and added section filtering to the public records endpoint.',
                'Rejected invalid show/hide dates and hide-before-show ranges in the record editor, form save handler, shared record writer and database JSON import validator.',
                'No storage schema, JSON storage, import/export, Trash, backup, or uninstall behavior changes.'
            )),
            array('version'=>'3.2.19','date'=>'2026-11-13','title'=>'Database and folder appearance, record sections and publishing','items'=>array('Added editable database icon, image, background and accent settings.','Added folder icon and colour customization without folder image uploads.','Added hierarchical multi-section taxonomy for records, with bulk assignment.','Added public/private visibility and optional show/hide scheduling.','Restricted public PHP/REST data access to records currently published and visible.','Preserved appearance and section metadata in database JSON exports and full backups.')),
            array('version'=>'3.2.16','date'=>'2026-11-13','title'=>'Clean reinstall lifecycle and Light / Dark / System appearance','items'=>array(
                'Hardened explicit uninstall cleanup: removes KGDM-owned storage tables, KGDM-prefixed site options/transients, legacy bridge data, release/update metadata and the protected local backup directory; deactivation continues to preserve all data.',
                'Added a fresh-install generation token to query-cache keys so Redis, Memcached or other persistent object caches cannot return records from a prior deleted installation after reinstall.',
                'A reinstall with the uninstall-delete policy enabled starts with empty KGDM tables, default settings, no old active database selection and a newly generated cache namespace; the uninstall policy defaults back to OFF.',
                'Added Light, Dark and System appearance modes in Settings. System is the default and automatically follows the operating system or device color preference through prefers-color-scheme.',
                'Added shared theme color tokens for panels, forms, tables, folder cards, modals, builder controls, navigation and status elements, with accessible contrast adjustments for dark mode.',
                'Preserved appearance preference in full KGDM backup/restore while deliberately excluding the uninstall deletion policy from backup restoration.',
                'No WordPress content, users, themes, unrelated plugin data or Media Library attachments/files are removed by KGDM uninstall cleanup.'
            )),
            array('version'=>'3.2.15','date'=>'2026-11-13','title'=>'Unified Workspace Trash, restore and permanent deletion','items'=>array(
                'Added one shared Trash workspace for Databases, Folders & forms and Records, accessible from the Workspace navigation and contextual links across Databases, Folders & forms, Records and Completeness.',
                'Standardized soft-delete actions as Move to Trash, with dedicated Restore and Delete permanently actions; permanent delete requires an existing trashed state, an administrator capability check, a nonce and an explicit confirmation.',
                'Added transaction-protected permanent deletion for archived databases and trashed records, including their KGDM-owned records, template revisions, migration logs and recovery snapshots.',
                'Added folder trash batches so moving a parent folder to Trash also archives its active descendants as one recoverable group; separately trashed descendants retain their state and are hidden until the parent is restored.',
                'Guarded child restore/purge actions while an ancestor remains in Trash, and preserve folder group state through database JSON export/import.',
                'Added collection-scoped record Trash, accurate SQL-based counts, collection-context-preserving Trash navigation and legacy Trash URL routing.',
                'Advanced the WordPress storage schema to 2.7.0 with a collection trash_batch_id column. The update engine adds the column through dbDelta; v3.2.14 and earlier full backups are normalized with an empty group ID when restored.',
                'KGDM Trash never deletes WordPress posts, users or Media Library attachments; permanent deletion is scoped to KGDM-owned data only.'
            )),
            array('version'=>'3.2.14','date'=>'2026-11-13','title'=>'Cleaner workspace, reduced duplicate actions and unified navigation','items'=>array(
                'Replaced repeated workflow labels, step cards and path context with one compact progress bar; the grouped WordPress sidebar is the single navigation source.',
                'Removed the repeated Current database badge because the top database selector already provides that context; selected folder/collection context remains preserved during navigation.',
                'Simplified the Databases page by using non-interactive summary metrics, removing the duplicate database picker on the library page, and keeping one Create database action.',
                'Made the folder tree navigation-only; folder editing is now available once from the selected-folder panel or folder content card. Database cards retain one open target and a separate Settings action.',
                'Removed the extra Check completeness shortcut from Records, the repeated folder-tree Edit controls, and the extra record-editor Close button; the sidebar, folder content and Cancel action each have one clear purpose.',
                'Removed duplicate active-workspace counts from the Database library header and improved empty-Trash recovery navigation by keeping its Back to folders action visible.',
                'No database schema, record payload, public API, import/export, backup, migration or uninstall behavior changes.'
            )),
            array('version'=>'3.2.12','date'=>'2026-11-13','title'=>'Context-aware database workflow navigation','items'=>array(
                'Added a four-step workspace flow across Databases, Folders & forms, Records and Completeness with context-preserving links.',
                'Kept the selected database and folder context while moving between workspace steps, with clear previous/next actions and readiness hints.',
                'Separated folder browsing from schema/form setup using distinct browse guidance and direct Setup folder & form actions.',
                'Added direct completeness-to-record navigation that opens the selected record editor, including records outside the currently displayed page.',
                'Added direct links between record management and the matching completeness audit, while retaining flexible-JSON guidance for folders without a schema.',
                'No database schema, record payload, public API, import format, backup format or migration-engine changes.'
            )),
            array('version'=>'3.2.11','date'=>'2026-11-13','title'=>'Folder editor, modal and form builder UI polish','items'=>array(
                'Refined the Create / Edit Folder workspace, folder cards, card actions and empty states for better spacing, alignment and responsive behavior.',
                'Improved modal sizing, close controls, sticky folder-editor heading and sticky Review changes / Cancel actions.',
                'Reworked field-builder cards, drag handles, required controls, advanced settings, nested option controls and category-template cards with clearer grouping.',
                'Improved the Faction preset panel, schema JSON panel, migration-safety notice and form-builder status presentation.',
                'Kept the update focused on CSS and presentation; record behavior, templates, data formats, APIs and database schema are unchanged.'
            )),
            array('version'=>'3.2.10','date'=>'2026-11-13','title'=>'Grouped workspace navigation and modern admin layout','items'=>array(
                'Replaced the crowded horizontal section tabs with grouped navigation for Workspace, Data tools and System sections.',
                'Consolidated Help and updates into one destination with separate Help & system info and Release notes & updates sub-tabs; legacy update-log links continue to work.',
                'Added consistent page headings, section descriptions and current-database context across the admin screens.',
                'Refreshed shared styling for panels, tables, forms, cards, action bars, code examples, statuses and responsive navigation using native WordPress admin patterns.',
                'Preserved existing routes, records, templates, PHP APIs, import/export formats, migration engine, backup/recovery and uninstall behavior.',
                'No database schema, record or public API changes.'
            )),
            array('version'=>'3.2.9','date'=>'2026-11-13','title'=>'Faction and Organization form preset','items'=>array(
                'Added a validated, reusable Faction / Organization collection form preset with identity, leadership, members, ranks, goals, history, relationships, quests, media and source references.',
                'Added category templates for general factions, military orders, governments / political groups, secret societies and guilds / associations.',
                'Added a guarded Load Faction form action that warns before replacing unsaved builder fields and templates.',
                'Existing records are not changed by loading the preset; schema changes still use the existing preview, migration, revision and recovery workflow.',
                'Retained the WordPress-native admin styling and form-builder refinements from versions 3.2.6, 3.2.7 and 3.2.8.',
                'No database schema, record, public API or import format changes.'
            )),
            array('version'=>'3.2.8','date'=>'2026-11-12','title'=>'Compact forms, Trash and accessibility fixes','items'=>array(
                'Reduced field-builder spacing and clarified migration-safety guidance in the folder editor.',
                'Added accessible IDs to schema-driven and generated form controls without changing submitted record data.',
                'Added explicit dimensions to dynamically loaded media thumbnails to prevent layout shifts.',
                'Added a folder Trash view with restore and confirmed permanent deletion of a folder subtree.',
                'Invalidated cached folder queries after moving folders to or restoring them from Trash.',
                'Improved editor dialog sizing and desktop scrollbar visibility.',
                'Kept the storage schema, records, public APIs and import formats unchanged.',
            )),
            array('version'=>'3.2.7','date'=>'2026-11-12','title'=>'Update log and folder navigation refinements','items'=>array(
                'Added saved List and Grid layouts to the dedicated Update log tab; the List layout keeps the vertical release timeline and Grid shows release cards.',
                'Restyled folder navigation rows as compact, clickable folder cards with clearer open and edit actions.',
                'Replaced the unavailable Create database Dashicon with a visible plus icon.',
                'Kept the storage schema, records, public APIs and import formats unchanged.',
            )),
            array('version'=>'3.2.6','date'=>'2026-11-12','title'=>'Plugin Check hardening and safer data handling','items'=>array(
                'Escaped admin output and prepared custom-table identifiers and values, including fixed-shape record queries.',
                'Hardened JSON record/import processing, admin query state and uploaded-file metadata while keeping JSON formats unchanged.',
                'Used WordPress filesystem APIs for backup deletion, permissions and uploaded backup handling; preserved streaming downloads for large validated archives.',
                'Removed development-only var_export usage from the copyable PHP examples and updated readme compatibility metadata.',
                'Hardened remaining scalar/map input handling and removed unnecessary vertical alignment from folder action buttons.',
                'Added a dedicated Update log tab with a chronological release timeline and kept runtime migration history alongside it.',
                'Kept storage schema, record data, APIs and import formats unchanged.',
            )),
            array('version'=>'3.2.5','date'=>'2026-11-11','title'=>'Native admin navigation and database settings flow','items'=>array(
                'Replaced the custom section bar with WordPress native admin tabs and simplified the main workflow by removing the duplicate Dashboard tab and combining system information with Help and updates.',
                'Made database settings open only from an explicit Settings link, kept the popup open after saving, and cleared the deep-link flag when it closes.',
                'Restyled collection form templates and database settings fields to use clearer layouts and WordPress admin form patterns.',
                'Kept storage schema, record data, APIs and import formats unchanged.',
            )),
            array('version'=>'3.2.4','date'=>'2026-11-11','title'=>'Completeness checker script fix','items'=>array(
                'Scoped selector helpers inside the completeness checker so it runs independently of the main admin script closure.',
                'Resolved the JavaScript runtime error that prevented completeness filters from initializing.',
                'Kept storage schema, records, APIs and import formats unchanged.',
            )),
            array('version'=>'3.2.3','date'=>'2026-11-11','title'=>'Modal keyboard access and admin layout polish','items'=>array(
                'Kept keyboard focus inside database and folder editor dialogs and returned focus to the opener when a dialog closes.',
                'Added dialog state and control relationships for the Create database action, plus a sensible focus target for dialogs opened from deep links.',
                'Standardized icon alignment and keyboard focus outlines across section navigation, action buttons and modal controls.',
                'Kept the database schema, stored records, APIs and import formats unchanged.',
            )),
            array('version'=>'3.2.2','date'=>'2026-11-11','title'=>'Database tools, modal editors and file-manager navigation','items'=>array(
                'Added a dedicated Database tools header with aligned icon-and-label actions.',
                'Moved database creation and database settings into accessible modal dialogs while keeping the database library visible underneath.',
                'Moved folder creation/editing into large modal dialogs so the file-manager workspace remains visible behind the editor.',
                'Made database tiles behave like file-manager items with keyboard-accessible click navigation.',
                'Improved icon/text alignment across database cards and action buttons without changing storage, APIs or data formats.',
            )),
            array('version'=>'3.2.1','date'=>'2026-11-11','title'=>'Maintenance, query correctness and cache efficiency','items'=>array(
                'Verified record payload hashes on collection reads so get() and find() enforce the same JSON integrity rules.',
                'Replaced cache marker mutation with isolated cache envelopes so user-defined record fields are never overwritten or removed.',
                'Added per-site, per-collection cache generations for constant-time invalidation without flushing unrelated KGDM query entries.',
                'Added bounded cache sizes for individual records, filtered result sets and full collections to avoid oversized object-cache entries.',
                'Fixed boolean, missing-field and exists comparisons; nested dot-path sorting now works and sort values are resolved once per record.',
                'Invalidated query caches after template migrations, migration rollback and full backup restore.',
                'Improved record save, rename, delete and restore error handling so failed database writes are not reported as successful.',
                'Made record renames transactional and prevented the non-AJAX editor from overwriting an unrelated record with a duplicate ID.',
                'Made legacy sample cleanup transactional and invalidate all query cache generations after its direct table changes.',
                'Rejected unsupported query operators and retained nested dot paths in sorting; cached query results remain enabled by default.',
                'Made JSON imports invalidate cache generations after commit (once per affected scope) and check transaction start/commit failures before reporting success.'
            )),
            array('version'=>'3.2.0','date'=>'2026-11-11','title'=>'PHP query API and object-cache layer','items'=>array(
                'Added a public kgdm() PHP facade with get() for fast single-record reads and find() for field-aware record queries.',
                'Added where operators for exact matches, contains, in, not_in, exists and numeric gt/gte/lt/lte comparisons, plus nested dot-path lookup.',
                'Added search, ordering, pagination and include_deleted controls to find() without exposing SQL to snippets.',
                'Added WordPress object-cache support for record and collection reads, with automatic invalidation after record writes/restores/deletes.',
                'Added copy-ready PHP snippet documentation showing direct get(), find(), cached lookups and safe field rendering.',
                'Kept the existing kgdm_get_* helper functions and REST API backward compatible.',
                'Kept WordPress storage schema 2.6.0, JSON storage format 1 and migration engine 1.'
            )),
            array('version'=>'3.1.0','date'=>'2026-11-11','title'=>'Backup, export and recovery','items'=>array(
                'Added site-wide compressed backups for all six KGDM tables, including archived/deleted records, template revisions, migration logs and per-record migration snapshots.',
                'Added archive format versioning, SHA-256 checksum verification, compressed/decompressed file limits and strict current-schema column validation.',
                'Added protected local backup storage, authenticated download, uploaded archive validation, backup listing and backup deletion.',
                'Added guarded full restore with typed confirmation, an automatic pre-restore safety backup, InnoDB transaction enforcement and rollback on failed writes or row-count checks.',
                'Preserved WordPress content, users and Media Library attachments/files; full restore only replaces the six KGDM-owned tables.',
                'Preserved the current uninstall deletion policy and plugin/schema/migration version markers during restore; backups are removed during uninstall only when explicit destructive cleanup is enabled.',
                'Kept WordPress storage schema 2.6.0 and JSON storage format 1.'
            )),
            array('version'=>'3.0.0','date'=>'2026-11-11','title'=>'Versioned plugin update migration engine','items'=>array(
                'Separated plugin release migrations from the WordPress storage schema version; plugin release and schema versions now advance independently.',
                'Added a sequential, immutable release-migration registry with a persistent per-step ledger, attempt counts and completion/failure states.',
                'Added an atomic site-local update lock with stale-lock recovery to prevent simultaneous requests from running migrations twice.',
                'Automatic updates are detected on plugins_loaded even when WordPress does not invoke the activation hook.',
                'Storage schema creation/upgrades run only when the stored schema is behind or verification detects missing required tables/columns.',
                'Plugin version is committed only after all required storage checks and release migrations succeed; failures preserve the old plugin version and retry safely.',
                'Added bounded update history, current migration-step reporting, an administrator-only manual retry action and downgrade protection.',
                'Kept JSON storage format 1 and WordPress storage schema 2.6.0; no record payload migration is needed for this release.'
            )),
            array('version'=>'2.9.0','date'=>'2026-11-11','title'=>'Explicit uninstall data policy and cleanup hardening','items'=>array(
                'Made data preservation the explicit default for plugin uninstall; deactivation has no data-deletion hook.',
                'Required the exact phrase DELETE KGDM DATA before an administrator can newly enable permanent uninstall cleanup.',
                'Documented the exact plugin-owned tables and namespaced options covered by cleanup, and explicitly excluded Media Library files and unrelated WordPress data.',
                'Hardened uninstall cleanup to remove only KGDM-owned tables, options and transients, using WordPress APIs for cache-safe option/transient deletion.',
                'Preserved per-site uninstall policy behavior on multisite installations; each site is cleaned only when its own setting is enabled.',
                'Kept the WordPress table schema at 2.6.0; no record, template, JSON storage or migration data migration is required.'
            )),
            array('version'=>'2.8.0','date'=>'2026-11-11','title'=>'Missing data and completeness checker','items'=>array(
                'Added a dedicated Completeness checker for every form collection.',
                'Added required-field and recommended-field coverage counts with record-level missing field paths.',
                'Added nested group and repeater completeness reporting, including per-row missing values.',
                'Added template assignment and template-version status to completeness reports.',
                'Added quick links from completeness results to edit the affected record.',
                'Added filters for incomplete, partially complete, complete, unassigned and flexible records.',
                'Kept completeness checks read-only; the checker never changes stored record data.'
            )),
            array('version'=>'2.7.0','date'=>'2026-11-11','title'=>'Versioned template migrations and guarded recovery','items'=>array(
                'Added a dedicated data migration log and per-record before/after recovery snapshots.',
                'Added explicit field-key mapping from removed fields to new fields; source values remain preserved as legacy data.',
                'Applied new-field defaults only where the value is missing and recorded migration counts.',
                'Advanced known record template-version tags only when the record had explicit version metadata; unversioned legacy records are not guessed.',
                'Added guarded migration rollback that restores only records whose current hash still matches the post-migration snapshot.',
                'Added migration history to each collection and baseline revision backfill for existing collections.',
                'Added transactional migration and recovery table verification; failed migration writes roll back with the collection update.'
            )),
            array('version'=>'2.5.0','date'=>'2026-11-11','title'=>'Dynamic record form generation','items'=>array(
                'Generated record forms from the selected collection schema, including nested groups, nested repeaters and WordPress media fields.',
                'Added repeater row creation/removal, row limits and preservation of row-level legacy values when entries are removed or reindexed.',
                'Applied collection defaults to new records and category-template defaults to newly generated nested repeater rows.',
                'Added conditional field visibility and template-aware client and server required-field validation.',
                'Added record completeness indicators and template-version metadata for saved records.',
                'Fixed empty repeater submission and preserved unknown fields while editing structured records.',
                'Kept the WordPress table schema at 2.4.0; plugin, collection-template and storage-schema versions remain separate.'
            )),
            array('version'=>'2.4.0','date'=>'2026-11-11','title'=>'Custom template builder completion','items'=>array(
                'Added drag-and-drop field ordering with keyboard-safe move controls and field duplication.',
                'Added template duplication and a compact template summary showing visible/required field counts.',
                'Added live builder status showing schema field count, template count and validation state before save.',
                'Improved builder grouping so field settings, nested schema and defaults remain editable without leaving the template screen.',
                'Preserved stable field keys and existing record data while template labels/layout change.',
                'Kept existing template revision, audit, migration preview, default backfill and restore workflows intact.'
            )),
            array('version'=>'2.3.0','date'=>'2026-11-11','title'=>'Database workspace and folder browser','items'=>array(
                'Redesigned the Databases screen as a database workspace with icon-led actions, database cards, record counts and direct open/settings links.',
                'Changed the Folders screen into a file-manager-style browser with a navigable nested folder tree, breadcrumbs, child-folder cards and separate Open / Edit actions.',
                'New folders inherit the currently open folder as their parent, while the parent selector remains available for manual placement.',
                'Added icon-and-label navigation buttons for the main database manager sections.',
                'Preserved database IDs, collection IDs, existing records, API helpers and the current WordPress table schema; no destructive migration is required.'
            )),
            array('version'=>'2.2.0','date'=>'2026-11-11','title'=>'Versioned full-form builder and nested database folders','items'=>array(
                'Added a visual field builder with sections, help text, placeholders, defaults, widths, nested object groups and repeater values.',
                'Added category-specific templates with field visibility, required-field rules and record template metadata.',
                'Added immutable template revision snapshots and schema change summaries; removed field values are retained as legacy JSON.',
                'Added a complete field coverage audit for every field, including nested group and repeater fields, across active and deleted records.',
                'Added category-specific required-field audit, unassigned-template counts and manual review counts for changed field types.',
                'Added safe default-value backfill for newly added fields without overwriting existing values.',
                'Validated imported template revision history before writes and roll back database imports if a revision cannot be stored.',
                'Added nested collection folders with parent-child navigation and breadcrumbs.',
                'Database IDs now preview from the database name and default to the normalized name slug when left blank.',
                'Added an opt-in uninstall cleanup setting; plugin deletion preserves data unless the setting is enabled.',
                'Added idempotent background schema upgrades with verification and an Update Log status instead of noisy front-end errors.',
                'Kept existing kgdm_get_* snippet functions and V2.1.2 database contents compatible.'
            )),
            array('version'=>'2.1.2','date'=>'2026-11-11','title'=>'Media Library, form templates and list collections','items'=>array(
                'Added WordPress Media Library fields for single images and multi-image galleries; records store attachment IDs and support choose, replace and remove actions.',
                'Added small WordPress-style record thumbnails sourced from the collection image field.',
                'Added reusable collection form templates grouped by category, including validated JSON default values.',
                'Added list-only collections for flexible JSON records without a schema-driven form.',
                'Improved collection export/import to preserve mode, templates and media attachment references.',
                'Made media scripts load only on Records screens for collections that use image or gallery fields.',
                'Fixed replace-import behavior so obsolete collection definitions are removed transactionally before importing the replacement.',
                'Upgraded the internal database schema to 2.2.1 while keeping the requested public plugin release at 2.1.2.'
            )),
            array('version'=>'2.1.1','date'=>'2026-11-11','title'=>'Clean, empty-by-default release','items'=>array(
                'Renamed the plugin to KG Database Management.',
                'New installations start with no databases, collections, sample records or preset data.',
                'Removed automatic Genshin database and faction sample creation; legacy V1 records are migrated only when present.',
                'Added horizontal-tab and WordPress-style side navigation layouts.',
                'Moved all global interface and REST access toggles to Settings.',
                'Added paste-or-upload JSON import with strict structure and record validation before writes.',
                'Moved admin CSS and JavaScript into page-only assets to prevent code output and reduce unnecessary loading.',
                'Kept the kgdm_get_* PHP functions stable for existing snippets.'
            )),
            array('version'=>'2.1.0','date'=>'2026-11-11','title'=>'Admin workspace and data access redesign','items'=>array(
                'Replaced the single long admin screen with Dashboard, Databases, Collections, Records, Data Access, Import / Export, Update Log and About tabs.',
                'Removed the Genshin master-snippet activation warning. The manager works independently; the Genshin compatibility bridge remains optional.',
                'Added a schema-driven record editor with text, textarea, number, boolean, URL, date, select and JSON fields.',
                'Added AJAX record viewing, creation, editing, soft deletion and restoration to reduce full-page reloads.',
                'Added an optional read-only REST API that can be enabled separately for each database. Public access is disabled by default.',
                'Added copy-ready PHP integration examples, database endpoint links, plugin update history and an About tab.',
                'Added the api_access database setting while preserving existing databases and V1 migration data.'
            )),
            array('version'=>'2.0.0','date'=>'2026-11-11','title'=>'Multi-database foundation','items'=>array(
                'Introduced independent databases, custom collections and record schemas.',
                'Moved managed records into dedicated WordPress database tables.',
                'Added V1 migration, soft deletion, restoration and JSON backup import/export.',
                'Added the optional Genshin master-data compatibility bridge and starter faction records.'
            )),
            array('version'=>'1.0.0','date'=>'2026-11-10','title'=>'Genshin Database Manager','items'=>array(
                'Introduced the original Genshin-focused manager for characters, weapons, artifact sets, factions and enemies.',
                'Added create, edit, soft-delete, restore and JSON import/export actions.'
            )),
        );
    }

    public function handle_set_api_access() {
        self::require_admin();
        check_admin_referer('kgdm_set_api_access');
        global $wpdb;
        $tables = self::table_names();
        $id = sanitize_key(wp_unslash($_POST['database_id'] ?? ''));
        $access = sanitize_key(wp_unslash($_POST['api_access'] ?? 'private'));
        if (!in_array($access, array('private','public'), true) || !self::get_database($id, true)) {
            self::redirect(array('tab'=>'data-access','db'=>$id,'notice'=>'api_access_invalid'));
        }
        $wpdb->update($tables['databases'], array('api_access'=>$access,'updated_at'=>self::now()), array('id'=>$id));
        self::redirect(array('tab'=>'data-access','db'=>$id,'notice'=>$access === 'public' ? 'api_access_public' : 'api_access_private'));
    }

    public function ajax_record_action() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message'=>'You do not have permission to manage records.'), 403);
        }
        check_ajax_referer('kgdm_record_action', 'nonce');
        $database_id = sanitize_key(wp_unslash($_POST['database_id'] ?? ''));
        $collection_slug = sanitize_title(wp_unslash($_POST['collection_slug'] ?? ''));
        $operation = sanitize_key(wp_unslash($_POST['operation'] ?? ''));
        if (!self::get_database($database_id, false) || !self::get_collection($database_id, $collection_slug, false)) {
            wp_send_json_error(array('message'=>'The selected database or collection is unavailable.'), 400);
        }

        if ($operation === 'get') {
            $id = sanitize_title(wp_unslash($_POST['record_id'] ?? ''));
            $active = self::get_admin_record($database_id, $collection_slug, $id, false);
            if ($active !== null) {
                wp_send_json_success(array('record'=>$active,'status'=>'active'));
            }
            $deleted = self::get_admin_record($database_id, $collection_slug, $id, true);
            if ($deleted !== null) {
                wp_send_json_success(array('record'=>$deleted,'status'=>'deleted'));
            }
            wp_send_json_error(array('message'=>'Record not found.'), 404);
        }

        if ($operation === 'save') {
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON must be decoded before recursive sanitization; sanitize_tree() and schema validation run before saving.
            $raw = wp_unslash($_POST['record_json'] ?? '');
            $original_id = sanitize_title(wp_unslash($_POST['original_record_id'] ?? ''));
            $collection = self::get_collection($database_id, $collection_slug, false);
            if (!is_string($raw) || strlen($raw) > self::MAX_IMPORT_BYTES) {
                wp_send_json_error(array('message'=>'The record is empty or exceeds the maximum allowed size.'), 400);
            }
            $record = json_decode($raw, true, 64);
            if (!is_array($record) || json_last_error() !== JSON_ERROR_NONE || isset($record[0])) {
                wp_send_json_error(array('message'=>'Record data must be a valid JSON object.'), 400);
            }
            $record = self::sanitize_tree($record);
            $template_id = sanitize_title((string)($record['_kgdm_template'] ?? ''));
            $template_definition = null;
            if (!empty($collection['form_templates']) && $template_id === '') {
                wp_send_json_error(array('message'=>'Choose an entry template before saving this record.'), 400);
            }
            if ($template_id !== '') {
                foreach ((array)($collection['form_templates'] ?? array()) as $candidate) {
                    if (($candidate['category'] ?? '') === $template_id) { $template_definition = $candidate; break; }
                }
                if (!$template_definition) { wp_send_json_error(array('message'=>'The selected entry template no longer exists. Reload the Records page and choose a current template.'), 400); }
            }
            $name = sanitize_text_field((string)($record['name'] ?? $record['title'] ?? $record['label'] ?? ''));
            $id = sanitize_title((string)($record['id'] ?? $name));
            if ($id === '') {
                wp_send_json_error(array('message'=>'A record needs a unique ID. Other fields are defined by your collection schema or JSON payload.'), 400);
            }
            if (($original_id === '' || $original_id !== $id) && (self::db_record_entry($database_id, $collection_slug, $id) !== null || self::get_admin_record($database_id, $collection_slug, $id, false) !== null)) {
                wp_send_json_error(array('message'=>'That record ID already exists. Open the existing record to edit it, or choose a different ID.'), 409);
            }
            $record['id'] = $id;
            $record['_kgdm_template_version'] = (int)($collection['template_version'] ?? 1);
            $publication_check = self::validate_record_publication_dates($record);
            if (is_wp_error($publication_check)) {
                wp_send_json_error(array('message'=>$publication_check->get_error_message()), 400);
            }
            $record = self::sanitize_record_metadata($record, $collection);
            $valid = self::validate_record_schema($record, $collection['schema'], $template_definition);
            if (is_wp_error($valid)) {
                wp_send_json_error(array('message'=>$valid->get_error_message()), 400);
            }
            if ($original_id !== '' && $original_id !== $id) {
                $existing = self::get_admin_record($database_id, $collection_slug, $original_id, false);
                if ($existing === null) {
                    wp_send_json_error(array('message'=>'The original record could not be found. Reload the Records page before saving this change.'), 404);
                }
                if (!self::rename_record($database_id, $collection_slug, $original_id, $id, $existing, $record)) {
                    wp_send_json_error(array('message'=>'The record could not be renamed safely. The original record was preserved.'), 500);
                }
                wp_send_json_success(array('message'=>'Record saved.','record'=>$record,'id'=>$id,'status'=>'active','completeness'=>self::record_completeness($record, $collection),'publication_state'=>self::record_publication_state($record)));
            }
            if (!self::upsert_record($database_id, $collection_slug, $id, $record, 'active')) {
                wp_send_json_error(array('message'=>'The record could not be saved to the WordPress database.'), 500);
            }
            wp_send_json_success(array('message'=>'Record saved.','record'=>$record,'id'=>$id,'status'=>'active','completeness'=>self::record_completeness($record, $collection),'publication_state'=>self::record_publication_state($record)));
        }

        $id = sanitize_title(wp_unslash($_POST['record_id'] ?? ''));
        if ($id === '') {
            wp_send_json_error(array('message'=>'A record ID is required.'), 400);
        }
        if ($operation === 'delete') {
            $active = self::get_admin_record($database_id, $collection_slug, $id, false);
            if ($active === null) {
                wp_send_json_error(array('message'=>'The active record could not be found.'), 404);
            }
            if (!self::upsert_record($database_id, $collection_slug, $id, $active, 'deleted')) {
                wp_send_json_error(array('message'=>'The record could not be moved to the deleted records view.'), 500);
            }
            wp_send_json_success(array('message'=>'Record moved to the deleted records view.','id'=>$id));
        }
        if ($operation === 'restore') {
            $entry = self::db_record_entry($database_id, $collection_slug, $id);
            if (!$entry || $entry['status'] !== 'deleted') {
                wp_send_json_error(array('message'=>'The saved deleted record could not be found.'), 404);
            }
            if (!empty($entry['record']['__kgdm_restore_base'])) {
                global $wpdb; $tables = self::table_names(); $collection = self::get_collection($database_id, $collection_slug, true);
                $deleted = $collection ? $wpdb->delete($tables['records'], array('collection_id'=>$collection['id'],'item_key'=>$id)) : false;
                if ($deleted === false || $deleted < 1) { wp_send_json_error(array('message'=>'The base record override could not be removed.'), 500); }
                self::flush_record_cache($database_id, $collection_slug, $id);
            } elseif (!self::upsert_record($database_id, $collection_slug, $id, $entry['record'], 'active')) {
                wp_send_json_error(array('message'=>'The record could not be restored.'), 500);
            }
            wp_send_json_success(array('message'=>'Record restored.','id'=>$id));
        }
        wp_send_json_error(array('message'=>'Unsupported record action.'), 400);
    }

    public function register_rest_routes() {
        register_rest_route('kgdm/v1', '/databases', array(
            'methods'=>'GET',
            'callback'=>array($this,'rest_public_databases'),
            'permission_callback'=>'__return_true',
        ));
        register_rest_route('kgdm/v1', '/databases/(?P<database>[a-z0-9_-]+)/collections', array(
            'methods'=>'GET',
            'callback'=>array($this,'rest_public_collections'),
            'permission_callback'=>array($this,'rest_public_database_permission'),
            'args'=>array('database'=>array('required'=>true)),
        ));
        register_rest_route('kgdm/v1', '/databases/(?P<database>[a-z0-9_-]+)/collections/(?P<collection>[a-z0-9_-]+)', array(
            'methods'=>'GET',
            'callback'=>array($this,'rest_public_records'),
            'permission_callback'=>array($this,'rest_public_database_permission'),
        ));
        register_rest_route('kgdm/v1', '/databases/(?P<database>[a-z0-9_-]+)/collections/(?P<collection>[a-z0-9_-]+)/(?P<record>[a-z0-9_-]+)', array(
            'methods'=>'GET',
            'callback'=>array($this,'rest_public_record'),
            'permission_callback'=>array($this,'rest_public_database_permission'),
        ));
    }

    public function rest_public_database_permission($request) {
        $database_id = sanitize_key((string)$request['database']);
        $database = self::get_database($database_id, false);
        if (!$database) {
            return new WP_Error('kgdm_database_not_found','Database not found.',['status'=>404]);
        }
        if (($database['api_access'] ?? 'private') !== 'public') {
            return new WP_Error('kgdm_database_private','Public API access is disabled for this database.',['status'=>403]);
        }
        return true;
    }

    public function rest_public_databases($request) {
        $rows = array_values(array_filter(self::get_databases(false), function($db) { return ($db['api_access'] ?? 'private') === 'public'; }));
        $out = array_map(function($db) {
            return array('id'=>$db['id'],'name'=>$db['name'],'description'=>$db['description'],'kind'=>$db['kind'],'visual'=>self::public_visual_payload($db['visual'] ?? array(), true),'collections'=>rest_url('kgdm/v1/databases/'.$db['id'].'/collections'));
        }, $rows);
        return rest_ensure_response(array('success'=>true,'count'=>count($out),'items'=>$out));
    }

    public function rest_public_collections($request) {
        $database_id = sanitize_key((string)$request['database']);
        $items = array_map(function($collection) use ($database_id) {
            return array(
                'id'=>$collection['slug'],
                'name'=>$collection['name'],
                'singular_name'=>$collection['singular_name'],
                'description'=>$collection['description'],
                'visual'=>self::public_visual_payload($collection['visual'] ?? array(), false),
                'sections'=>array_values((array)($collection['sections'] ?? array())),
                'schema'=>$collection['schema'],
                'endpoint'=>rest_url('kgdm/v1/databases/'.$database_id.'/collections/'.$collection['slug'])
            );
        }, self::get_collections($database_id, false));
        return rest_ensure_response(array('success'=>true,'database'=>$database_id,'count'=>count($items),'items'=>$items));
    }

    public function rest_public_records($request) {
        $database_id = sanitize_key((string)$request['database']);
        $collection_slug = sanitize_title((string)$request['collection']);
        if (!self::get_collection($database_id, $collection_slug, false)) {
            return new WP_Error('kgdm_collection_not_found','Collection not found.',['status'=>404]);
        }
        $limit = min(500, max(1, absint($request->get_param('limit') ?: 100)));
        $offset = max(0, absint($request->get_param('offset') ?: 0));
        $args = array('limit'=>$limit,'offset'=>$offset);
        $search = sanitize_text_field((string)$request->get_param('search'));
        if ($search !== '') { $args['search'] = $search; }
        $section = sanitize_title((string)$request->get_param('section'));
        if ($section !== '') { $args['section'] = $section; }
        $records = self::api_get_records($database_id, $collection_slug, $args);
        $items = array_values($records);
        return rest_ensure_response(array('success'=>true,'database'=>$database_id,'collection'=>$collection_slug,'count'=>count($items),'limit'=>$limit,'offset'=>$offset,'items'=>$items));
    }

    public function rest_public_record($request) {
        $database_id = sanitize_key((string)$request['database']);
        $collection_slug = sanitize_title((string)$request['collection']);
        $record_id = sanitize_title((string)$request['record']);
        $record = self::api_get_record($database_id, $collection_slug, $record_id);
        if (!$record) {
            return new WP_Error('kgdm_record_not_found','Record not found.',['status'=>404]);
        }
        return rest_ensure_response(array('success'=>true,'database'=>$database_id,'collection'=>$collection_slug,'item'=>$record));
    }

    private static function get_settings() {
        $saved = get_option('kgdm_settings', array());
        if (!is_array($saved)) { $saved = array(); }
        $settings = wp_parse_args($saved, array(
            'navigation_layout' => 'tabs',
            'compact_ui' => 0,
            'show_help' => 1,
            'appearance_mode' => 'system',
            'delete_data_on_uninstall' => 0,
        ));
        if (!in_array(($settings['appearance_mode'] ?? 'system'), array('system','light','dark'), true)) {
            $settings['appearance_mode'] = 'system';
        }
        return $settings;
    }

    public function handle_save_settings() {
        self::require_admin();
        check_admin_referer('kgdm_save_settings');
        $navigation = sanitize_key(wp_unslash($_POST['navigation_layout'] ?? 'tabs'));
        if (!in_array($navigation, array('tabs','sidebar'), true)) { $navigation = 'tabs'; }
        $previous_settings = self::get_settings();
        $delete_requested = !empty($_POST['delete_data_on_uninstall']);
        $confirmation = strtoupper(trim(sanitize_text_field(wp_unslash($_POST['delete_data_confirmation'] ?? ''))));
        $uninstall_delete_enabled = !empty($previous_settings['delete_data_on_uninstall']);
        $uninstall_confirmation_failed = false;
        if (!$delete_requested) {
            $uninstall_delete_enabled = false;
        } elseif (!$uninstall_delete_enabled && $confirmation !== 'DELETE KGDM DATA') {
            $uninstall_delete_enabled = false;
            $uninstall_confirmation_failed = true;
        }
        $appearance_mode = sanitize_key(wp_unslash($_POST['appearance_mode'] ?? 'system'));
        if (!in_array($appearance_mode, array('system','light','dark'), true)) { $appearance_mode = 'system'; }
        $settings = array(
            'navigation_layout' => $navigation,
            'compact_ui' => !empty($_POST['compact_ui']) ? 1 : 0,
            'show_help' => !empty($_POST['show_help']) ? 1 : 0,
            'appearance_mode' => $appearance_mode,
            'delete_data_on_uninstall' => $uninstall_delete_enabled ? 1 : 0,
        );
        update_option('kgdm_settings', $settings, false);
        $database_id = sanitize_key(wp_unslash($_POST['database_id'] ?? ''));
        if ($database_id !== '' && self::get_database($database_id, true)) {
            global $wpdb;
            $tables = self::table_names();
            $api_access = !empty($_POST['public_api_enabled']) ? 'public' : 'private';
            $wpdb->update($tables['databases'], array('api_access'=>$api_access,'updated_at'=>self::now()), array('id'=>$database_id));
        }
        self::redirect(array('tab'=>'settings','db'=>$database_id,'notice'=>$uninstall_confirmation_failed ? 'uninstall_confirmation_required' : 'settings_saved'));
    }

    /** Persist the compact header theme toggle without rewriting unrelated plugin settings. */
    public function ajax_set_appearance() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message'=>'You do not have permission to change KGDM appearance.'), 403);
        }
        check_ajax_referer('kgdm_set_appearance', 'nonce');
        $mode = sanitize_key(wp_unslash($_POST['mode'] ?? ''));
        if (!in_array($mode, array('light','dark'), true)) {
            wp_send_json_error(array('message'=>'Choose either light or dark appearance.'), 400);
        }
        $settings = self::get_settings();
        $settings['appearance_mode'] = $mode;
        if (!self::update_option_checked('kgdm_settings', $settings)) {
            wp_send_json_error(array('message'=>'The appearance preference could not be saved.'), 500);
        }
        wp_send_json_success(array('mode'=>$mode));
    }

    public function enqueue_admin_assets($hook_suffix) {
        $page_slug = sanitize_key(self::admin_query_param('page', ''));
        if (!in_array($page_slug, self::workspace_page_slugs(), true)) { return; }
        // The workspace is registered as native WordPress submenu pages. Load the same
        // styles and scripts on every submenu, not only the top-level Databases page.
        // KGDM uses WordPress Dashicons as its single icon source. Enqueue explicitly
        // so icons do not depend on incidental admin/theme asset loading.
        wp_enqueue_style('dashicons');
        wp_enqueue_style('kgdm-admin', plugins_url('assets/admin.css', __FILE__), array('dashicons'), self::VERSION);
        $needs_media = in_array($page_slug, array(self::MENU_SLUG, self::MENU_SLUG . '-folders'), true);
        if (sanitize_key(self::admin_query_param('tab', self::tab_for_page_slug($page_slug))) === 'records') {
            $db = sanitize_key(self::admin_query_param('db', get_option(self::ACTIVE_DB_OPTION, '')));
            $collection_slug = sanitize_title(self::admin_query_param('collection'));
            if ($db !== '' && $collection_slug === '') {
                $default_collections = self::get_collections($db, false);
                $collection_slug = !empty($default_collections) ? (string)$default_collections[0]['slug'] : '';
            }
            $collection = $db !== '' && $collection_slug !== '' ? self::get_collection($db, $collection_slug, false) : null;
            if ($collection && self::first_media_field($collection['schema'] ?? array())) { $needs_media = true; }
        }
        if ($needs_media) { wp_enqueue_media(); }
        wp_enqueue_script('kgdm-admin', plugins_url('assets/admin.js', __FILE__), $needs_media ? array('jquery','media-editor') : array(), self::VERSION, true);
    }

    /** Map an internal workspace tab to its native WordPress admin page slug. */
    private static function page_slug_for_tab($tab) {
        $map = array(
            'databases' => self::MENU_SLUG,
            'collections' => self::MENU_SLUG . '-folders',
            'records' => self::MENU_SLUG . '-records',
            'completeness' => self::MENU_SLUG . '-completeness',
            'trash' => self::MENU_SLUG . '-trash',
            'import-export' => self::MENU_SLUG . '-import-export',
            'developer' => self::MENU_SLUG . '-developer',
            'settings' => self::MENU_SLUG . '-settings',
            'help' => self::MENU_SLUG . '-help',
        );
        $aliases = array('dashboard'=>'databases', 'data-access'=>'developer', 'about'=>'help', 'update-log'=>'help', 'updates'=>'help');
        $tab = $aliases[$tab] ?? $tab;
        return $map[$tab] ?? self::MENU_SLUG;
    }

    /** Resolve a KGDM native submenu slug back to its workspace tab. */
    private static function tab_for_page_slug($page_slug) {
        $map = array(
            self::MENU_SLUG => 'databases',
            self::MENU_SLUG . '-folders' => 'collections',
            self::MENU_SLUG . '-records' => 'records',
            self::MENU_SLUG . '-completeness' => 'completeness',
            self::MENU_SLUG . '-trash' => 'trash',
            self::MENU_SLUG . '-import-export' => 'import-export',
            self::MENU_SLUG . '-developer' => 'developer',
            self::MENU_SLUG . '-settings' => 'settings',
            self::MENU_SLUG . '-help' => 'help',
        );
        return $map[$page_slug] ?? 'databases';
    }

    /** Return all native page slugs used by the plugin so assets load on every submenu. */
    private static function workspace_page_slugs() {
        return array(
            self::MENU_SLUG,
            self::MENU_SLUG . '-folders',
            self::MENU_SLUG . '-records',
            self::MENU_SLUG . '-completeness',
            self::MENU_SLUG . '-trash',
            self::MENU_SLUG . '-import-export',
            self::MENU_SLUG . '-developer',
            self::MENU_SLUG . '-settings',
            self::MENU_SLUG . '-help',
        );
    }

    public function admin_menu() {
        add_menu_page('KG Database Management', 'KG Database Management', 'manage_options', self::MENU_SLUG, array($this, 'render_admin_page'), 'dashicons-database', 58);

        // Put each workspace destination directly in the native WordPress admin menu.
        // The first child reuses the parent slug so WordPress labels it "Databases".
        $submenu_pages = array(
            'databases' => 'Databases',
            'collections' => 'Folders & forms',
            'records' => 'Records',
            'completeness' => 'Completeness',
            'trash' => 'Trash',
            'import-export' => 'Import / Export',
            'developer' => 'Developer',
            'settings' => 'Settings',
            'help' => 'Help & updates',
        );
        foreach ($submenu_pages as $tab => $label) {
            $slug = self::page_slug_for_tab($tab);
            add_submenu_page(self::MENU_SLUG, $label, $label, 'manage_options', $slug, array($this, 'render_admin_page'));
        }
    }

    private static function page_url($args = array()) {
        $args = is_array($args) ? $args : array();
        $tab = sanitize_key($args['tab'] ?? 'databases');
        unset($args['tab']);
        $args['page'] = self::page_slug_for_tab($tab);
        return add_query_arg($args, admin_url('admin.php'));
    }

    private static function redirect($args = array()) {
        wp_safe_redirect(self::page_url($args));
        exit;
    }

    private static function clean_text($value) { return sanitize_text_field(wp_unslash($value)); }

    /** Read scalar query parameters used only to render or navigate the admin UI. */
    private static function admin_query_param($key, $default = '') {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Query parameters only select read-only admin views; state changes use nonce-verified POST actions.
        if (!isset($_GET[$key])) { return $default; }
        return sanitize_text_field(wp_unslash($_GET[$key])); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin navigation; state changes use nonce-verified POST actions.
    }

    /** Read a scalar field from an admin-post request after its handler verifies the action nonce. */
    private static function admin_post_param($key, $default = '') {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.NonceVerification.Recommended -- All callers are admin-post handlers that verify their action-specific nonce before reading the field.
        if (!isset($_POST[$key])) { return $default; }
        return sanitize_text_field(wp_unslash($_POST[$key])); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Every caller verifies its action-specific nonce before invoking this helper.
    }

    /** Normalize PHP upload metadata; callers still verify the upload and validate its contents. */
    private static function uploaded_file($key) {
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing -- Both callers verify their action nonce; PHP file metadata is validated by shape, is_uploaded_file(), size, extension and content checks.
        $file = $_FILES[$key] ?? null;
        if (!is_array($file)) { return array(); }
        if (!isset($file['tmp_name'], $file['name'], $file['size'], $file['error']) || !is_string($file['tmp_name']) || !is_string($file['name']) || !is_numeric($file['size']) || !is_numeric($file['error'])) { return array(); }
        $file['name'] = sanitize_file_name($file['name']);
        $file['size'] = absint($file['size']);
        $file['error'] = absint($file['error']);
        return $file;
    }

    /** Quote a value for a PHP single-quoted example snippet. */
    private static function php_single_quoted_literal($value) {
        return "'" . str_replace(array('\\', "'"), array('\\\\', "\\'"), (string)$value) . "'";
    }

    private static function sanitize_tree($value, $key = '') {
        if (is_array($value)) {
            $out = array();
            foreach ($value as $child_key => $child_value) { $out[$child_key] = self::sanitize_tree($child_value, (string)$child_key); }
            return $out;
        }
        if (is_bool($value) || is_int($value) || is_float($value) || $value === null) { return $value; }
        if (!is_string($value)) { return ''; }
        if (preg_match('/(^|_)(url|uri)$/i', $key)) { return esc_url_raw(trim($value)); }
        return sanitize_textarea_field($value);
    }

    private static function sanitize_field_schema($raw, $depth = 0) {
        if (is_string($raw)) {
            $decoded = json_decode($raw, true, 64);
        } else {
            $decoded = $raw;
        }
        if (!is_array($decoded) || $depth > 5) {
            return new WP_Error('invalid_schema', 'Field schema must be a valid JSON array and nested fields cannot exceed five levels.');
        }
        $allowed = array('text','textarea','number','boolean','url','email','date','datetime','select','multiselect','json','image','gallery','color','group','repeater');
        $out = array();
        $seen = array();
        foreach ($decoded as $field) {
            if (!is_array($field)) { return new WP_Error('invalid_schema_field', 'Each field definition must be a JSON object.'); }
            $key = sanitize_key((string)($field['key'] ?? ''));
            if ($key === '' || in_array($key, array('id','_kgdm_template','_kgdm_template_version'), true)) { return new WP_Error('invalid_schema_key', 'Every field needs a unique key. The keys id, _kgdm_template and _kgdm_template_version are reserved.'); }
            if (isset($seen[$key])) { return new WP_Error('duplicate_schema_key', 'Duplicate field key: ' . $key); }
            $seen[$key] = true;
            $type = sanitize_key((string)($field['type'] ?? 'text'));
            if (!in_array($type, $allowed, true)) { return new WP_Error('invalid_schema_type', 'Unsupported field type for ' . $key . '.'); }
            $width = (int)($field['width'] ?? 100);
            if (!in_array($width, array(25,33,50,66,75,100), true)) { $width = 100; }
            $item = array(
                'key' => $key,
                'label' => sanitize_text_field((string)($field['label'] ?? $key)),
                'type' => $type,
                'required' => !empty($field['required']),
                'section' => sanitize_text_field((string)($field['section'] ?? 'General')),
                'help' => sanitize_textarea_field((string)($field['help'] ?? '')),
                'placeholder' => sanitize_text_field((string)($field['placeholder'] ?? '')),
                'width' => $width,
            );
            if (array_key_exists('default', $field)) { $item['default'] = self::sanitize_tree($field['default']); }
            if (isset($field['show_if']) && is_array($field['show_if'])) {
                $dependency = trim((string)($field['show_if']['field'] ?? ''));
                $dependency_parts = array_filter(array_map('sanitize_key', explode('.', $dependency)), 'strlen');
                $dependency = implode('.', $dependency_parts);
                $operator = sanitize_key((string)($field['show_if']['operator'] ?? 'equals'));
                $allowed_operators = array('equals','not_equals','contains','not_contains','is_checked','is_not_empty','is_empty');
                if ($dependency !== '' && in_array($operator, $allowed_operators, true)) {
                    $condition_value = $field['show_if']['value'] ?? '';
                    if (is_array($condition_value) || is_object($condition_value)) { $condition_value = wp_json_encode($condition_value); }
                    $item['show_if'] = array(
                        'field' => $dependency,
                        'operator' => $operator,
                        'value' => is_scalar($condition_value) ? sanitize_text_field((string)$condition_value) : '',
                    );
                }
            }
            if (in_array($type, array('select','multiselect'), true)) {
                if (isset($field['options']) && !is_array($field['options'])) { return new WP_Error('invalid_schema_options', 'Select options must be an array.'); }
                $options = array_values(array_unique(array_filter(array_map('sanitize_text_field', (array)($field['options'] ?? array())), 'strlen')));
                if (empty($options)) { return new WP_Error('empty_select_options', 'Select fields need at least one option.'); }
                $item['options'] = $options;
            }
            if (in_array($type, array('group','repeater'), true)) {
                $children = $field['children'] ?? array();
                if (is_string($children)) { $children = json_decode($children, true, 64); }
                if (!is_array($children)) { return new WP_Error('invalid_nested_schema', 'Nested fields for ' . $key . ' must be an array.'); }
                $child_schema = self::sanitize_field_schema($children, $depth + 1);
                if (is_wp_error($child_schema)) { return $child_schema; }
                if (empty($child_schema)) { return new WP_Error('empty_nested_schema', 'Group and repeater fields need at least one child field: ' . $key); }
                $item['children'] = $child_schema;
            }
            if ($type === 'number') {
                if (isset($field['min']) && $field['min'] !== '') { if (!is_numeric($field['min'])) { return new WP_Error('invalid_field_min', 'Minimum must be numeric for ' . $key); } $item['min'] = (float)$field['min']; }
                if (isset($field['max']) && $field['max'] !== '') { if (!is_numeric($field['max'])) { return new WP_Error('invalid_field_max', 'Maximum must be numeric for ' . $key); } $item['max'] = (float)$field['max']; }
                if (isset($item['min'], $item['max']) && $item['min'] > $item['max']) { return new WP_Error('invalid_field_range', 'Minimum cannot exceed maximum for ' . $key); }
            }
            if ($type === 'repeater') {
                $max_items = max(1, min(500, absint($field['max_items'] ?? 100)));
                $item['max_items'] = $max_items;
            }
            $out[] = $item;
        }
        if (count($out) > 200) { return new WP_Error('too_many_schema_fields', 'A collection can have at most 200 top-level fields.'); }
        return $out;
    }

    private static function sanitize_form_templates($raw) {
        if (is_string($raw)) { $decoded = json_decode($raw, true, 64); } else { $decoded = $raw; }
        if (!is_array($decoded)) { return new WP_Error('invalid_form_templates', 'Form templates must be a valid JSON array.'); }
        $out = array(); $seen = array();
        foreach ($decoded as $template) {
            if (!is_array($template)) { return new WP_Error('invalid_form_template', 'Each form template must be an object.'); }
            $name = sanitize_text_field((string)($template['name'] ?? ''));
            $category = sanitize_title((string)($template['category'] ?? ''));
            $defaults = $template['defaults'] ?? array();
            if ($name === '' || $category === '') { return new WP_Error('invalid_form_template', 'Every template needs a name and category ID.'); }
            if (isset($seen[$category])) { return new WP_Error('duplicate_form_template', 'Duplicate form template category: ' . $category); }
            if (!is_array($defaults) || (isset($defaults[0]))) { return new WP_Error('invalid_form_template_defaults', 'Template defaults must be a JSON object.'); }
            $visible = array_values(array_unique(array_filter(array_map('sanitize_key', (array)($template['visible_fields'] ?? array())), 'strlen')));
            $required = array_values(array_unique(array_filter(array_map('sanitize_key', (array)($template['required_fields'] ?? array())), 'strlen')));
            $seen[$category] = true;
            $out[] = array(
                'name' => $name,
                'category' => $category,
                'description' => sanitize_textarea_field((string)($template['description'] ?? '')),
                'visible_fields' => $visible,
                'required_fields' => $required,
                'defaults' => self::sanitize_tree($defaults),
            );
        }
        if (count($out) > 100) { return new WP_Error('too_many_form_templates', 'A collection can have at most 100 form templates.'); }
        return $out;
    }

    private static function record_condition_matches($record, $condition) {
        if (!is_array($condition) || empty($condition['field'])) { return true; }
        $actual = self::get_record_path($record, (string)$condition['field']);
        $operator = (string)($condition['operator'] ?? 'equals');
        $expected = (string)($condition['value'] ?? '');
        $present = !($actual === null || $actual === '');
        switch ($operator) {
            case 'not_equals':
                if (!$present) { return true; }
                return is_array($actual) ? !in_array($expected, array_map('strval', $actual), true) : (string)$actual !== $expected;
            case 'contains':
                if (is_array($actual)) { return in_array($expected, array_map('strval', $actual), true); }
                return $present && stripos((string)$actual, $expected) !== false;
            case 'not_contains':
                if (is_array($actual)) { return !in_array($expected, array_map('strval', $actual), true); }
                return !$present || stripos((string)$actual, $expected) === false;
            case 'is_checked': return $actual === true || $actual === 1 || $actual === '1' || $actual === 'true';
            case 'is_not_empty': return $present && $actual !== array();
            case 'is_empty': return !$present || $actual === array();
            case 'equals':
            default:
                if (!$present) { return false; }
                return is_array($actual) ? in_array($expected, array_map('strval', $actual), true) : (string)$actual === $expected;
        }
    }

    private static function has_record_path($record, $path) {
        $value = $record;
        foreach (explode('.', (string)$path) as $segment) {
            if (!is_array($value) || !array_key_exists($segment, $value)) { return false; }
            $value = $value[$segment];
        }
        return true;
    }

    private static function field_condition_matches($root_record, $local_record, $condition) {
        if (!is_array($condition) || empty($condition['field'])) { return true; }
        $dependency = (string)$condition['field'];
        $scope = $root_record;
        if (is_array($local_record) && self::has_record_path($local_record, $dependency)) { $scope = $local_record; }
        return self::record_condition_matches(is_array($scope) ? $scope : array(), $condition);
    }

    private static function validate_record_schema($record, $schema, $template = null, $depth = 0, $root_record = null) {
        if (!is_array($record) || $depth > 5) { return new WP_Error('invalid_record_object', 'Nested record data must be an object.'); }
        if ($root_record === null) { $root_record = $record; }
        $visible = isset($template['visible_fields']) && is_array($template['visible_fields']) ? $template['visible_fields'] : array();
        $required_override = isset($template['required_fields']) && is_array($template['required_fields']) ? $template['required_fields'] : array();
        foreach ((array)$schema as $field) {
            $key = (string)($field['key'] ?? '');
            if ($key === '') { continue; }
            if ($depth === 0 && !empty($visible) && !in_array($key, $visible, true)) { continue; }
            if (!self::field_condition_matches($root_record, $record, $field['show_if'] ?? array())) { continue; }
            $value = $record[$key] ?? null;
            $label = (string)($field['label'] ?? $key);
            $type = (string)($field['type'] ?? 'text');
            $empty = !array_key_exists($key, $record) || $value === '' || $value === null || $value === array();
            if ($type === 'group' && is_array($value)) { $empty = self::is_empty_value_tree($value); }
            $is_required = !empty($field['required']) || ($depth === 0 && in_array($key, $required_override, true));
            if ($is_required && $empty) { return new WP_Error('missing_required_field', 'Required field missing: ' . $label); }
            if ($empty) { continue; }
            if ($type === 'number') {
                if (!is_numeric($value)) { return new WP_Error('invalid_field_type', $label . ' must be a number.'); }
                if (isset($field['min']) && (float)$value < (float)$field['min']) { return new WP_Error('invalid_field_range', $label . ' is below its minimum value.'); }
                if (isset($field['max']) && (float)$value > (float)$field['max']) { return new WP_Error('invalid_field_range', $label . ' exceeds its maximum value.'); }
            }
            if ($type === 'boolean' && !is_bool($value) && !in_array($value, array(0,1,'0','1','true','false'), true)) { return new WP_Error('invalid_field_type', $label . ' must be a boolean.'); }
            if (in_array($type, array('text','textarea','url','email','date','datetime','select','color'), true) && !is_string($value)) { return new WP_Error('invalid_field_type', $label . ' must be text.'); }
            if ($type === 'url' && $value !== '' && !filter_var($value, FILTER_VALIDATE_URL)) { return new WP_Error('invalid_field_type', $label . ' must be a valid URL.'); }
            if ($type === 'email' && $value !== '' && !filter_var($value, FILTER_VALIDATE_EMAIL)) { return new WP_Error('invalid_field_type', $label . ' must be a valid email address.'); }
            if ($type === 'date' && $value !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) { return new WP_Error('invalid_field_type', $label . ' must use YYYY-MM-DD.'); }
            if ($type === 'datetime' && $value !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/', $value)) { return new WP_Error('invalid_field_type', $label . ' must be a valid date and time.'); }
            if ($type === 'color' && $value !== '' && !preg_match('/^#[0-9a-fA-F]{6}$/', $value)) { return new WP_Error('invalid_field_type', $label . ' must be a six-digit hex color.'); }
            if ($type === 'select' && !empty($field['options']) && !in_array($value, (array)$field['options'], true)) { return new WP_Error('invalid_field_option', 'Invalid option for ' . $label . '.'); }
            if ($type === 'multiselect') {
                if (!is_array($value)) { return new WP_Error('invalid_field_type', $label . ' must be a list.'); }
                foreach ($value as $choice) { if (!in_array($choice, (array)($field['options'] ?? array()), true)) { return new WP_Error('invalid_field_option', 'Invalid option for ' . $label . '.'); } }
            }
            if ($type === 'image' && (!is_numeric($value) || (int)$value < 1)) { return new WP_Error('invalid_field_type', $label . ' must contain a valid media attachment ID.'); }
            if ($type === 'gallery') {
                if (!is_array($value)) { return new WP_Error('invalid_field_type', $label . ' must contain an array of WordPress media attachment IDs.'); }
                foreach ($value as $attachment_id) { if (!is_numeric($attachment_id) || (int)$attachment_id < 1) { return new WP_Error('invalid_field_type', $label . ' contains an invalid media attachment ID.'); } }
            }
            if ($type === 'json' && !is_array($value) && !is_object($value)) { return new WP_Error('invalid_field_type', $label . ' must be an array or object.'); }
            if ($type === 'group') {
                if (!is_array($value)) { return new WP_Error('invalid_field_type', $label . ' must be an object.'); }
                $nested = self::validate_record_schema($value, $field['children'] ?? array(), null, $depth + 1, $root_record);
                if (is_wp_error($nested)) { return new WP_Error($nested->get_error_code(), $label . ': ' . $nested->get_error_message()); }
            }
            if ($type === 'repeater') {
                if (!is_array($value) || (isset($value[0]) && !is_array($value[0]))) { return new WP_Error('invalid_field_type', $label . ' must be a list of objects.'); }
                if (count($value) > (int)($field['max_items'] ?? 100)) { return new WP_Error('too_many_repeater_items', $label . ' has too many entries.'); }
                foreach ($value as $index => $row) {
                    if (!is_array($row)) { return new WP_Error('invalid_repeater_item', $label . ' entry ' . ($index + 1) . ' must be an object.'); }
                    $nested = self::validate_record_schema($row, $field['children'] ?? array(), null, $depth + 1, $root_record);
                    if (is_wp_error($nested)) { return new WP_Error($nested->get_error_code(), $label . ' entry ' . ($index + 1) . ': ' . $nested->get_error_message()); }
                }
            }
        }
        return true;
    }

    public function handle_create_database() {
        self::require_admin(); check_admin_referer('kgdm_create_database');
        $name = sanitize_text_field(wp_unslash($_POST['database_name'] ?? ''));
        $raw_slug = trim(sanitize_text_field(wp_unslash($_POST['database_slug'] ?? '')));
        $slug = substr(sanitize_title($raw_slug !== '' ? $raw_slug : $name), 0, 64);
        $description = sanitize_textarea_field(wp_unslash($_POST['database_description'] ?? ''));
        $kind = sanitize_key(wp_unslash($_POST['database_kind'] ?? 'general'));
        if ($name === '' || $slug === '' || !in_array($kind, array('general','game','app','catalog','knowledge_base','research'), true)) { self::redirect(array('notice'=>'database_invalid')); }
        if (self::get_database($slug, true)) { self::redirect(array('notice'=>'database_exists')); }
        $visual = self::sanitize_visual_settings(wp_unslash($_POST['database_visual_create'] ?? array()), true, true);
        $created = self::insert_database($slug, $name, $description, $kind, 'active', $visual);
        if (!$created) { self::redirect(array('notice'=>'database_save_failed')); }
        // A new database starts empty. Collections are created explicitly by the user.
        update_option(self::ACTIVE_DB_OPTION, $slug, false);
        self::redirect(array('db'=>$slug,'notice'=>'database_created'));
    }

    public function handle_update_database() {
        self::require_admin(); check_admin_referer('kgdm_update_database');
        global $wpdb; $tables = self::table_names();
        $id = sanitize_key(wp_unslash($_POST['database_id'] ?? ''));
        $name = sanitize_text_field(wp_unslash($_POST['database_name'] ?? ''));
        $description = sanitize_textarea_field(wp_unslash($_POST['database_description'] ?? ''));
        $existing_database = self::get_database($id, true);
        if ($id === '' || $name === '' || !$existing_database) { self::redirect(array('notice'=>'database_invalid')); }
        $visual_input = wp_unslash($_POST['database_visual_edit'] ?? array());
        $visual = self::sanitize_visual_settings($visual_input, true, true);
        if (!current_user_can('upload_files')) {
            $existing_visual = self::sanitize_visual_settings($existing_database['visual'] ?? array(), true, false);
            // Image controls are not rendered for users without upload_files. Keep
            // previously selected images instead of silently clearing them on save.
            $visual['icon_attachment_id'] = (int)$existing_visual['icon_attachment_id'];
            $visual['background_attachment_id'] = (int)$existing_visual['background_attachment_id'];
        }
        $wpdb->update($tables['databases'], array('name'=>$name,'description'=>$description,'visual_json'=>wp_json_encode($visual),'updated_at'=>self::now()), array('id'=>$id));
        self::redirect(array('tab'=>'databases','db'=>$id,'edit_database'=>1,'notice'=>'database_updated'));
    }

    public function handle_archive_database() {
        self::require_admin(); check_admin_referer('kgdm_archive_database');
        global $wpdb; $tables = self::table_names();
        $id = sanitize_key(wp_unslash($_POST['database_id'] ?? ''));
        $database = self::get_database($id, true);
        $result = $database && ($database['status'] ?? '') === 'active'
            ? $wpdb->update($tables['databases'], array('status'=>'archived','updated_at'=>self::now()), array('id'=>$id))
            : false;
        if ($result !== false && $database) {
            $active = get_option(self::ACTIVE_DB_OPTION, '');
            if ($active === $id) {
                $remaining = self::get_databases(false);
                update_option(self::ACTIVE_DB_OPTION, !empty($remaining) ? $remaining[0]['id'] : '', false);
            }
            self::invalidate_all_query_cache();
        }
        self::redirect(array('tab'=>'trash','trash_type'=>'databases','notice'=>$result === false ? 'database_trash_failed' : 'database_archived'));
    }

    public function handle_restore_database() {
        self::require_admin(); check_admin_referer('kgdm_restore_database');
        global $wpdb; $tables = self::table_names();
        $id = sanitize_key(wp_unslash($_POST['database_id'] ?? ''));
        $database = self::get_database($id, true);
        $result = $database && ($database['status'] ?? '') === 'archived'
            ? $wpdb->update($tables['databases'], array('status'=>'active','updated_at'=>self::now()), array('id'=>$id))
            : false;
        if ($result !== false && $database) {
            update_option(self::ACTIVE_DB_OPTION, $id, false);
            self::invalidate_all_query_cache();
        }
        self::redirect(array('tab'=>'trash','trash_type'=>'databases','notice'=>$result === false ? 'database_restore_failed' : 'database_restored'));
    }

    public function handle_purge_database() {
        self::require_admin(); check_admin_referer('kgdm_purge_database');
        global $wpdb; $tables = self::table_names();
        $id = sanitize_key(wp_unslash($_POST['database_id'] ?? ''));
        $database = self::get_database($id, true);
        if (!$database || ($database['status'] ?? '') !== 'archived') {
            update_option('kgdm_last_trash_error', 'Only databases currently in Trash can be permanently deleted.', false);
            self::redirect(array('tab'=>'trash','trash_type'=>'databases','notice'=>'database_purge_failed'));
        }
        $transactional = self::backup_tables_are_transactional();
        if (is_wp_error($transactional)) {
            update_option('kgdm_last_trash_error', $transactional->get_error_message(), false);
            self::redirect(array('tab'=>'trash','trash_type'=>'databases','notice'=>'database_purge_failed'));
        }
        $migration_ids = $wpdb->get_col($wpdb->prepare('SELECT migration_id FROM %i WHERE database_id = %s', $tables['migrations'], $id));
        $record_ids = $wpdb->get_col($wpdb->prepare('SELECT record_id FROM %i WHERE database_id = %s', $tables['records'], $id));
        if ($wpdb->last_error !== '') {
            update_option('kgdm_last_trash_error', 'The database contents could not be inspected. No data was changed.', false);
            self::redirect(array('tab'=>'trash','trash_type'=>'databases','notice'=>'database_purge_failed'));
        }
        if ($wpdb->query('START TRANSACTION') === false) {
            update_option('kgdm_last_trash_error', 'A safe delete transaction could not be started. No data was changed.', false);
            self::redirect(array('tab'=>'trash','trash_type'=>'databases','notice'=>'database_purge_failed'));
        }
        $failed = false;
        foreach (array_chunk(array_values(array_filter(array_map('strval',(array)$migration_ids))), 250) as $batch) {
            if (self::delete_rows_in_column($tables['migration_records'], 'migration_id', $batch) === false) { $failed = true; break; }
        }
        if (!$failed) {
            foreach (array_chunk(array_values(array_filter(array_map('strval',(array)$record_ids))), 250) as $batch) {
                if (self::delete_rows_in_column($tables['migration_records'], 'record_id', $batch) === false) { $failed = true; break; }
            }
        }
        foreach (array('records','template_versions','migrations','collections') as $key) {
            if ($failed) { break; }
            if ($wpdb->delete($tables[$key], array('database_id'=>$id), array('%s')) === false) { $failed = true; }
        }
        if (!$failed && $wpdb->delete($tables['databases'], array('id'=>$id), array('%s')) === false) { $failed = true; }
        if ($failed || $wpdb->query('COMMIT') === false) {
            $wpdb->query('ROLLBACK');
            update_option('kgdm_last_trash_error', 'The database could not be permanently deleted. The transaction was rolled back and its data was retained.', false);
            self::redirect(array('tab'=>'trash','trash_type'=>'databases','notice'=>'database_purge_failed'));
        }
        delete_option('kgdm_last_trash_error');
        if (get_option(self::ACTIVE_DB_OPTION, '') === $id) {
            $remaining = self::get_databases(false);
            update_option(self::ACTIVE_DB_OPTION, !empty($remaining) ? $remaining[0]['id'] : '', false);
        }
        self::invalidate_all_query_cache();
        self::redirect(array('tab'=>'trash','trash_type'=>'databases','notice'=>'database_purged'));
    }

    public function handle_set_active_database() {
        self::require_admin(); check_admin_referer('kgdm_set_active_database');
        $id = sanitize_key(wp_unslash($_POST['database_id'] ?? ''));
        if (self::get_database($id, false)) { update_option(self::ACTIVE_DB_OPTION, $id, false); }
        self::redirect(array('db'=>$id,'notice'=>'active_database_set'));
    }

    private static function value_exists_at_path($record, $path) {
        $segments = array_values(array_filter(explode('.', (string)$path), 'strlen'));
        return self::value_exists_in_segments($record, $segments, 0);
    }

    /** Supports both nested objects and repeater arrays when auditing field coverage. */
    private static function value_exists_in_segments($value, $segments, $index) {
        if ($index >= count($segments)) {
            return !($value === null || $value === '' || $value === array());
        }
        if (!is_array($value)) { return false; }
        if (self::is_list_array($value)) {
            foreach ($value as $row) {
                if (self::value_exists_in_segments($row, $segments, $index)) { return true; }
            }
            return false;
        }
        $key = $segments[$index];
        if (!array_key_exists($key, $value)) { return false; }
        return self::value_exists_in_segments($value[$key], $segments, $index + 1);
    }

    /**
     * Audits every field in the new form, not only newly added fields. Optional
     * gaps are reported for visibility; required/new/type-changed gaps drive the
     * review count. Type-changed populated values are flagged for manual review.
     */
    private static function audit_schema_coverage($database_id, $collection_slug, $old_schema, $new_schema, $templates = array()) {
        $old = self::flatten_schema_fields($old_schema);
        $new = self::flatten_schema_fields($new_schema);
        $records = self::get_admin_records($database_id, $collection_slug, false);
        $deleted = self::get_admin_records($database_id, $collection_slug, true);
        foreach ($deleted as $id => $record) { if (!isset($records[$id])) { $records[$id] = $record; } }

        $template_map = array();
        foreach ((array)$templates as $template) {
            $category = (string)($template['category'] ?? '');
            if ($category !== '') { $template_map[$category] = $template; }
        }
        $unassigned_template_records = 0;
        if (!empty($template_map)) {
            foreach ($records as $record) {
                $assigned = (string)($record['_kgdm_template'] ?? '');
                if ($assigned === '' || !isset($template_map[$assigned])) { $unassigned_template_records++; }
            }
        }

        $check = array();
        foreach ($new as $path => $field) {
            $added = !isset($old[$path]);
            $required = !empty($field['required']);
            $was_required = !empty($old[$path]['required']);
            $type_changed = isset($old[$path]) && (string)($old[$path]['type'] ?? '') !== (string)($field['type'] ?? '');
            $change = $added ? 'New field' : ($type_changed ? 'Type changed' : (($required && !$was_required) ? 'Now required' : ($required ? 'Required' : 'Existing field')));
            $check[$path] = array(
                'path' => $path,
                'label' => (string)($field['label'] ?? $path),
                'added' => $added,
                'required' => $required,
                'reviewable_missing' => ($added || $required || $type_changed),
                'type_changed' => $type_changed,
                'old_type' => (string)($old[$path]['type'] ?? ''),
                'new_type' => (string)($field['type'] ?? ''),
                'change' => $change,
                'has_default' => array_key_exists('default', $field),
                'default_preview' => array_key_exists('default', $field) ? wp_json_encode($field['default'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : '',
                'template_category' => '',
            );
        }

        // Category-specific required fields are audited against records assigned
        // to that category only. Unassigned records are counted separately.
        foreach ($template_map as $category => $template) {
            foreach ((array)($template['required_fields'] ?? array()) as $field_key) {
                if (!isset($new[$field_key])) { continue; }
                $default_exists = array_key_exists($field_key, (array)($template['defaults'] ?? array())) || array_key_exists('default', $new[$field_key]);
                $default_value = array_key_exists($field_key, (array)($template['defaults'] ?? array()))
                    ? $template['defaults'][$field_key]
                    : ($new[$field_key]['default'] ?? null);
                $audit_key = 'template:' . $category . ':' . $field_key;
                $check[$audit_key] = array(
                    'path' => $field_key,
                    'label' => (string)($new[$field_key]['label'] ?? $field_key),
                    'added' => false,
                    'required' => true,
                    'reviewable_missing' => true,
                    'type_changed' => false,
                    'old_type' => (string)($old[$field_key]['type'] ?? ''),
                    'new_type' => (string)($new[$field_key]['type'] ?? ''),
                    'change' => 'Required for ' . (string)($template['name'] ?? $category),
                    'has_default' => $default_exists,
                    'default_preview' => $default_exists ? wp_json_encode($default_value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : '',
                    'template_category' => $category,
                    'template_name' => (string)($template['name'] ?? $category),
                );
            }
        }

        $audit = array();
        $needs_review = array();
        foreach ($check as $audit_key => $meta) {
            $missing = 0;
            $filled = 0;
            $type_review = 0;
            $examples = array();
            $path = $meta['path'];
            $root_key = explode('.', $path)[0];
            foreach ($records as $record_id => $record) {
                $template_id = (string)($record['_kgdm_template'] ?? '');
                $category = (string)($meta['template_category'] ?? '');
                if ($category !== '' && $template_id !== $category) { continue; }
                $template = $template_id !== '' ? ($template_map[$template_id] ?? null) : null;
                if ($template && count(explode('.', $path)) === 1 && !empty($template['visible_fields']) && !in_array($root_key, $template['visible_fields'], true)) { continue; }
                if ($template_id === '' && $category !== '') { continue; }
                if (self::value_exists_at_path($record, $path)) {
                    $filled++;
                    if (!empty($meta['type_changed'])) {
                        $type_review++;
                        $needs_review[$record_id] = true;
                        if (count($examples) < 8) { $examples[] = $record_id . ' (check type)'; }
                    }
                } else {
                    $missing++;
                    if (!empty($meta['reviewable_missing'])) { $needs_review[$record_id] = true; }
                    if (count($examples) < 8) { $examples[] = $record_id; }
                }
            }
            $audit[] = array_merge($meta, array(
                'filled' => $filled,
                'missing' => $missing,
                'type_review' => $type_review,
                'examples' => $examples,
            ));
        }

        return array(
            'records_checked' => count($records),
            'records_needing_review' => count($needs_review),
            'unassigned_template_records' => $unassigned_template_records,
            'template_count' => count($template_map),
            'fields' => $audit,
        );
    }

    private static function normalize_collection_submission($post) {
        $database_id = sanitize_key(wp_unslash($post['database_id'] ?? ''));
        $name = self::clean_text($post['collection_name'] ?? '');
        $raw_slug = trim((string)wp_unslash($post['collection_slug'] ?? ''));
        $existing_slug = sanitize_title(wp_unslash($post['collection_existing_slug'] ?? ''));
        $slug = sanitize_title($raw_slug !== '' ? $raw_slug : ($existing_slug !== '' ? $existing_slug : $name));
        $singular = self::clean_text($post['collection_singular'] ?? '');
        $description = sanitize_textarea_field(wp_unslash($post['collection_description'] ?? ''));
        $mode = sanitize_key(wp_unslash($post['collection_mode'] ?? 'form'));
        if (!in_array($mode, array('form','list'), true)) { $mode = 'form'; }
        $schema = self::sanitize_field_schema(wp_unslash($post['collection_schema'] ?? '[]'));
        $templates = self::sanitize_form_templates(wp_unslash($post['collection_templates'] ?? '[]'));
        $visual = self::sanitize_visual_settings(wp_unslash($post['collection_visual'] ?? array()), false);
        $sections = self::sanitize_collection_sections(wp_unslash($post['collection_sections'] ?? ''));
        if (!self::get_database($database_id, false) || $slug === '' || $name === '' || is_wp_error($schema) || is_wp_error($templates)) {
            return new WP_Error('collection_invalid', 'Collection name, ID, nested field schema or form templates are invalid.');
        }
        if ($mode === 'list') { $schema = array(); $templates = array(); }
        $template_check = self::validate_templates_against_schema($templates, $schema);
        if (is_wp_error($template_check)) { return $template_check; }
        $existing = self::get_collection($database_id, $slug, true);
        $parent_slug = sanitize_title(wp_unslash($post['collection_parent'] ?? ''));
        $parent_id = '';
        if ($parent_slug !== '') {
            $parent = self::get_collection($database_id, $parent_slug, false);
            // Keep an existing child relationship intact when its parent was archived.
            // Archived folders are not offered as new parents, but editing a child must not
            // silently detach it from the archived folder.
            if (!$parent && $existing && !empty($existing['parent_id'])) {
                $existing_parent = self::get_collection($database_id, $parent_slug, true);
                if ($existing_parent && ($existing_parent['status'] ?? 'active') === 'archived' && (string)$existing_parent['id'] === (string)$existing['parent_id']) {
                    $parent = $existing_parent;
                }
            }
            if (!$parent || ($existing && $parent['id'] === $existing['id'])) {
                return new WP_Error('collection_parent_invalid', 'Choose a valid parent folder in the same database.');
            }
            $cursor = $parent; $guard = 0;
            while ($cursor && !empty($cursor['parent_id']) && $guard++ < 25) {
                if ($existing && $cursor['parent_id'] === $existing['id']) {
                    return new WP_Error('collection_parent_cycle', 'A folder cannot be moved inside one of its own child folders.');
                }
                $cursor = self::get_collection_by_id($database_id, $cursor['parent_id'], true);
            }
            $parent_id = $parent['id'];
        }
        $old_schema = $existing ? $existing['schema'] : array();
        $old_templates = $existing ? ($existing['form_templates'] ?? array()) : array();
        $old_mode = $existing ? ($existing['collection_mode'] ?? 'form') : 'form';
        $changed = !$existing || wp_json_encode($old_schema) !== wp_json_encode($schema) || wp_json_encode($old_templates) !== wp_json_encode($templates) || $old_mode !== $mode;
        $summary = $changed ? self::schema_diff($old_schema, $schema, $old_templates, $templates) : array();
        $summary['mode_changed'] = $existing && $old_mode !== $mode;
        $summary['parent_changed'] = $existing && (string)($existing['parent_id'] ?? '') !== $parent_id;
        $summary['record_count'] = $existing ? self::count_admin_records($database_id, $slug, true) + self::count_admin_records($database_id, $slug, false) : 0;
        $old_flat = self::flatten_schema_fields($old_schema);
        $new_flat = self::flatten_schema_fields($schema);
        $summary['has_added_defaults'] = false;
        foreach ($new_flat as $field_path => $field_definition) {
            if (!isset($old_flat[$field_path]) && array_key_exists('default', $field_definition)) { $summary['has_added_defaults'] = true; break; }
        }
        if (!$summary['has_added_defaults'] && self::templates_have_added_defaults($old_schema, $schema, $templates)) { $summary['has_added_defaults'] = true; }
        $summary['data_audit'] = $existing ? self::audit_schema_coverage($database_id, $slug, $old_schema, $schema, $templates) : array('records_checked'=>0,'records_needing_review'=>0,'fields'=>array());
        return array(
            'database_id'=>$database_id, 'slug'=>$slug, 'name'=>$name,
            'singular'=>$singular !== '' ? $singular : rtrim($name, 's'),
            'description'=>$description, 'mode'=>$mode, 'schema'=>$schema, 'visual'=>$visual, 'sections'=>$sections,
            'templates'=>$templates, 'parent_id'=>$parent_id,
            'summary'=>$summary, 'changed'=>$changed,
            'existing'=>(bool)$existing,
            'sort_order'=>$existing ? (int)$existing['sort_order'] : 100,
            'status'=>$existing ? $existing['status'] : 'active',
            'old_schema'=>$old_schema, 'old_templates'=>$old_templates,
            'template_version'=>$existing ? (int)($existing['template_version'] ?? 1) : 0,
        );
    }

    private static function get_value_from_migration_path($record, $path, &$found = null) {
        $found = false;
        $parts = array_values(array_filter(explode('.', (string)$path), 'strlen'));
        if (empty($parts)) { return null; }
        $cursor = $record;
        foreach ($parts as $part) {
            if (!is_array($cursor) || self::is_list_array($cursor) || !array_key_exists($part, $cursor)) { return null; }
            $cursor = $cursor[$part];
        }
        $found = true;
        return $cursor;
    }

    private static function set_migration_path(&$record, $path, $value) {
        $parts = array_values(array_filter(explode('.', (string)$path), 'strlen'));
        if (empty($parts)) { return false; }
        $cursor =& $record;
        foreach ($parts as $index => $part) {
            if ($index === count($parts) - 1) {
                $cursor[$part] = $value;
                return true;
            }
            if (isset($cursor[$part]) && (!is_array($cursor[$part]) || (!empty($cursor[$part]) && self::is_list_array($cursor[$part])))) { return false; }
            if (!isset($cursor[$part])) { $cursor[$part] = array(); }
            $cursor =& $cursor[$part];
        }
        return false;
    }

    private static function field_definition_by_path($schema, $path) {
        $flat = self::flatten_schema_fields($schema);
        return $flat[$path] ?? null;
    }

    /** Dot-path field mapping deliberately excludes children inside repeater arrays. */
    private static function migration_path_supports_direct_copy($schema, $path) {
        $parts = array_values(array_filter(explode('.', (string)$path), 'strlen'));
        $fields = (array)$schema;
        foreach ($parts as $index => $part) {
            $match = null;
            foreach ($fields as $field) { if ((string)($field['key'] ?? '') === $part) { $match = $field; break; } }
            if (!$match) { return false; }
            if (($match['type'] ?? '') === 'repeater' && $index < count($parts) - 1) { return false; }
            $fields = (array)($match['children'] ?? array());
        }
        return true;
    }

    private static function migration_value_is_blank($value) {
        return $value === null || $value === '' || (is_array($value) && count($value) === 0);
    }

    private static function migration_value_matches_field($value, $field) {
        $type = (string)($field['type'] ?? 'text');
        if (in_array($type, array('text','textarea','url','email','date','datetime','color','select'), true)) {
            if (!is_string($value)) { return false; }
            if ($type === 'url' && $value !== '' && !filter_var($value, FILTER_VALIDATE_URL)) { return false; }
            if ($type === 'email' && $value !== '' && !filter_var($value, FILTER_VALIDATE_EMAIL)) { return false; }
            if ($type === 'date' && $value !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) { return false; }
            if ($type === 'datetime' && $value !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/', $value)) { return false; }
            if ($type === 'color' && $value !== '' && !preg_match('/^#[0-9a-fA-F]{6}$/', $value)) { return false; }
            if ($type === 'select' && !empty($field['options']) && !in_array($value, (array)$field['options'], true)) { return false; }
            return true;
        }
        if ($type === 'number') {
            return is_numeric($value)
                && (!isset($field['min']) || (float)$value >= (float)$field['min'])
                && (!isset($field['max']) || (float)$value <= (float)$field['max']);
        }
        if ($type === 'boolean') { return is_bool($value) || in_array($value, array(0,1,'0','1','true','false'), true); }
        if ($type === 'multiselect') {
            if (!is_array($value) || !self::is_list_array($value)) { return false; }
            foreach ($value as $choice) { if (!in_array($choice, (array)($field['options'] ?? array()), true)) { return false; } }
            return true;
        }
        if ($type === 'image') { return is_numeric($value) && (int)$value > 0; }
        if ($type === 'gallery') {
            if (!is_array($value) || !self::is_list_array($value)) { return false; }
            foreach ($value as $attachment_id) { if (!is_numeric($attachment_id) || (int)$attachment_id < 1) { return false; } }
            return true;
        }
        if ($type === 'json') { return is_array($value) || is_object($value); }
        if ($type === 'group') {
            if (!is_array($value) || self::is_list_array($value)) { return false; }
            return !is_wp_error(self::validate_record_schema($value, (array)($field['children'] ?? array()), null, 1, $value));
        }
        if ($type === 'repeater') {
            if (!is_array($value) || !self::is_list_array($value) || count($value) > (int)($field['max_items'] ?? 100)) { return false; }
            foreach ($value as $row) {
                if (!is_array($row) || (!empty($row) && self::is_list_array($row))) { return false; }
                if (is_wp_error(self::validate_record_schema($row, (array)($field['children'] ?? array()), null, 1, $row))) { return false; }
            }
            return true;
        }
        return false;
    }

    private static function set_template_default_paths(&$record, $defaults, $old_fields, $new_flat, $prefix = '') {
        $changed = false;
        foreach ((array)$defaults as $key => $value) {
            $key = (string)$key;
            if ($key === '') { continue; }
            $path = $prefix === '' ? $key : $prefix . '.' . $key;
            $field = $new_flat[$path] ?? null;
            if (!$field) { continue; }
            if (($field['type'] ?? '') === 'group' && is_array($value) && !self::is_list_array($value)) {
                if (!isset($record[$key]) || !is_array($record[$key]) || self::is_list_array($record[$key])) {
                    if (!isset($old_fields[$path])) { $record[$key] = array(); $changed = true; }
                    else { continue; }
                }
                $changed = self::set_template_default_paths($record[$key], $value, $old_fields, $new_flat, $path) || $changed;
            } elseif (!isset($old_fields[$path]) && !array_key_exists($key, $record)) {
                $record[$key] = $value;
                $changed = true;
            }
        }
        return $changed;
    }

    private static function templates_have_added_defaults($old_schema, $new_schema, $templates) {
        $old_flat = self::flatten_schema_fields($old_schema);
        $new_flat = self::flatten_schema_fields($new_schema);
        foreach ((array)$templates as $template) {
            foreach (self::template_default_paths((array)($template['defaults'] ?? array())) as $path) {
                if (isset($new_flat[$path]) && !isset($old_flat[$path])) { return true; }
            }
        }
        return false;
    }

    /**
     * Applies only explicit, non-destructive transformations. Each changed record is
     * snapshotted before write and linked to a hash of its post-migration state.
     */
    private static function apply_template_data_migration($database_id, $collection_slug, $from_version, $to_version, $old_schema, $new_schema, $migration_map = array(), $backfill_defaults = true) {
        global $wpdb;
        $tables = self::table_names();
        $collection = self::get_collection($database_id, $collection_slug, true);
        if (!$collection) { return new WP_Error('migration_collection_missing', 'The collection for this migration no longer exists.'); }
        $rows = $wpdb->get_results($wpdb->prepare(
            'SELECT record_id, item_key, payload, payload_hash, payload_version, payload_format, status FROM %i WHERE database_id = %s AND collection_id = %s ORDER BY record_id ASC FOR UPDATE',
            $tables['records'], $database_id, $collection['id']
        ), ARRAY_A);
        if (!is_array($rows)) { return new WP_Error('migration_read_failed', 'Could not read collection records for migration.'); }
        $migration_id = wp_generate_uuid4();
        $old_flat = self::flatten_schema_fields($old_schema);
        $new_flat = self::flatten_schema_fields($new_schema);
        $valid_map = array();
        foreach ((array)$migration_map as $target => $source) {
            $target = (string)$target; $source = (string)$source;
            if ($target === '' || $source === '' || isset($old_flat[$target]) || !isset($new_flat[$target]) || !isset($old_flat[$source]) || isset($new_flat[$source]) || !self::migration_path_supports_direct_copy($new_schema, $target) || !self::migration_path_supports_direct_copy($old_schema, $source)) {
                return new WP_Error('migration_mapping_invalid', 'A field mapping does not match a removed source field and a newly added destination field.');
            }
            $valid_map[$target] = $source;
        }
        $counts = array('records_examined'=>count($rows),'records_changed'=>0,'defaults_added'=>0,'values_copied'=>0,'incompatible_mappings'=>0,'version_tags_advanced'=>0,'stale_version_records'=>0,'unversioned_records'=>0,'unchanged_records'=>0,'mapping'=>array());
        foreach ($valid_map as $target => $source) { $counts['mapping'][] = array('from'=>$source,'to'=>$target); }
        $summary = array('counts'=>$counts,'from_version'=>(int)$from_version,'to_version'=>(int)$to_version,'started_at'=>self::now());
        foreach ($rows as $row) {
            $decoded = self::decode_record_payload((string)$row['payload'], (string)($row['payload_hash'] ?? ''));
            if (is_wp_error($decoded)) { return new WP_Error('migration_record_corrupt', 'Record "' . (string)$row['item_key'] . '" failed JSON integrity validation. No migration was committed.'); }
            $record = $decoded;
            $record['id'] = (string)$row['item_key'];
            $changed = false;
            foreach ($valid_map as $target => $source) {
                $source_found = false; $target_found = false;
                $source_value = self::get_value_from_migration_path($record, $source, $source_found);
                $target_value = self::get_value_from_migration_path($record, $target, $target_found);
                if (!$source_found || self::migration_value_is_blank($source_value) || ($target_found && !self::migration_value_is_blank($target_value))) { continue; }
                $target_field = $new_flat[$target];
                if (!self::migration_value_matches_field($source_value, $target_field)) {
                    $counts['incompatible_mappings']++;
                    continue;
                }
                if (self::set_migration_path($record, $target, $source_value)) { $changed = true; $counts['values_copied']++; }
            }
            if ($backfill_defaults) {
                $before_json = wp_json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                $defaults_changed = self::set_default_paths($record, $old_flat, $new_schema);
                $template_id = (string)($record['_kgdm_template'] ?? '');
                if ($template_id !== '') {
                    foreach ((array)$collection['form_templates'] as $template_definition) {
                        if ((string)($template_definition['category'] ?? '') === $template_id) {
                            $defaults_changed = self::set_template_default_paths($record, (array)($template_definition['defaults'] ?? array()), $old_flat, $new_flat) || $defaults_changed;
                            break;
                        }
                    }
                }
                if ($defaults_changed) {
                    $changed = true;
                    $after_defaults = wp_json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                    if ($before_json !== $after_defaults) { $counts['defaults_added']++; }
                }
            }
            if (array_key_exists('_kgdm_template_version', $record) && is_numeric($record['_kgdm_template_version'])) {
                $record_version = (int)$record['_kgdm_template_version'];
                if ($record_version === (int)$from_version) {
                    $record['_kgdm_template_version'] = (int)$to_version;
                    $changed = true;
                    $counts['version_tags_advanced']++;
                } elseif ($record_version > 0 && $record_version < (int)$from_version) {
                    $counts['stale_version_records']++;
                }
            } else {
                $counts['unversioned_records']++;
            }
            if (!$changed) { $counts['unchanged_records']++; continue; }
            $encoded = self::encode_record_payload($record);
            if (is_wp_error($encoded)) { return new WP_Error('migration_encode_failed', 'Could not encode record "' . (string)$row['item_key'] . '" during migration.'); }
            $snapshot_ok = $wpdb->insert($tables['migration_records'], array(
                'migration_id'=>$migration_id,
                'record_id'=>(int)$row['record_id'],
                'item_key'=>(string)$row['item_key'],
                'payload_before'=>(string)$row['payload'],
                'payload_hash_before'=>(string)($row['payload_hash'] ?? ''),
                'payload_version_before'=>(int)($row['payload_version'] ?? self::JSON_STORAGE_VERSION),
                'payload_format_before'=>(string)($row['payload_format'] ?? 'json'),
                'payload_hash_after'=>$encoded['hash'],
                'status_before'=>(string)$row['status'],
                'status_after'=>(string)$row['status'],
                'created_at'=>self::now(),
            ));
            if ($snapshot_ok === false) { return new WP_Error('migration_snapshot_failed', 'Could not create a recovery snapshot. The migration was not committed.'); }
            $updated = $wpdb->update($tables['records'], array(
                'payload'=>$encoded['json'],'payload_hash'=>$encoded['hash'],'payload_version'=>$encoded['version'],'payload_format'=>$encoded['format'],
                'updated_at'=>self::now(),'updated_by'=>get_current_user_id(),
            ), array('record_id'=>(int)$row['record_id']));
            if ($updated === false) { return new WP_Error('migration_record_update_failed', 'A record update failed. The migration was not committed.'); }
            $counts['records_changed']++;
        }
        $summary['counts'] = $counts;
        $summary['completed_at'] = self::now();
        $log_ok = $wpdb->insert($tables['migrations'], array(
            'migration_id'=>$migration_id,'database_id'=>$database_id,'collection_id'=>$collection['id'],'collection_slug'=>$collection_slug,
            'from_version'=>max(1,(int)$from_version),'to_version'=>max(1,(int)$to_version),'status'=>'completed',
            'summary_json'=>wp_json_encode($summary, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'record_count'=>count($rows),'changed_count'=>$counts['records_changed'],'conflict_count'=>0,
            'error_message'=>'','created_at'=>self::now(),'created_by'=>get_current_user_id(),
        ));
        if ($log_ok === false) { return new WP_Error('migration_log_failed', 'Could not save the migration log. The migration was not committed.'); }
        return array('migration_id'=>$migration_id,'summary'=>$summary);
    }

    private static function get_collection_migrations($database_id, $collection_slug, $limit = 20) {
        global $wpdb;
        $tables = self::table_names();
        $collection = self::get_collection($database_id, $collection_slug, true);
        if (!$collection) { return array(); }
        $rows = $wpdb->get_results($wpdb->prepare(
            'SELECT * FROM %i WHERE database_id = %s AND collection_id = %s ORDER BY created_at DESC LIMIT %d',
            $tables['migrations'], $database_id, $collection['id'], max(1,(int)$limit)
        ), ARRAY_A);
        foreach ((array)$rows as &$row) {
            $row['summary'] = json_decode((string)($row['summary_json'] ?? '{}'), true);
            if (!is_array($row['summary'])) { $row['summary'] = array(); }
        }
        unset($row);
        return is_array($rows) ? $rows : array();
    }

    private static function rollback_template_data_migration($migration_id, $database_id, $collection_slug) {
        global $wpdb;
        $tables = self::table_names();
        $migration = $wpdb->get_row($wpdb->prepare(
            'SELECT * FROM %i WHERE migration_id = %s AND database_id = %s AND collection_slug = %s LIMIT 1 FOR UPDATE',
            $tables['migrations'], $migration_id, $database_id, $collection_slug
        ), ARRAY_A);
        if (!$migration || (string)$migration['status'] !== 'completed') {
            return new WP_Error('migration_not_rollbackable', 'This migration is missing or is not eligible for rollback.');
        }
        $snapshots = $wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE migration_id = %s ORDER BY snapshot_id ASC FOR UPDATE', $tables['migration_records'], $migration_id), ARRAY_A);
        if (!is_array($snapshots) || count($snapshots) !== (int)$migration['changed_count']) {
            return new WP_Error('migration_snapshots_incomplete', 'The recovery snapshot set is incomplete. No records were changed. Restore a site database backup or inspect the migration tables before retrying.');
        }
        $restored = 0; $conflicts = 0;
        foreach ($snapshots as $snapshot) {
            $current = $wpdb->get_row($wpdb->prepare('SELECT payload_hash, status FROM %i WHERE record_id = %d LIMIT 1 FOR UPDATE', $tables['records'], (int)$snapshot['record_id']), ARRAY_A);
            if (!$current || !hash_equals((string)$snapshot['payload_hash_after'], (string)$current['payload_hash']) || (string)$current['status'] !== (string)$snapshot['status_after']) { $conflicts++; continue; }
            $updated = $wpdb->update($tables['records'], array(
                'payload'=>(string)$snapshot['payload_before'],'payload_hash'=>(string)$snapshot['payload_hash_before'],
                'payload_version'=>(int)$snapshot['payload_version_before'],'payload_format'=>(string)$snapshot['payload_format_before'],
                'status'=>(string)$snapshot['status_before'],'updated_at'=>self::now(),'updated_by'=>get_current_user_id(),
            ), array('record_id'=>(int)$snapshot['record_id']));
            if ($updated === false) { return new WP_Error('migration_rollback_failed', 'A recovery write failed. Please retry after checking the database.'); }
            $restored++;
        }
        $status = $conflicts > 0 ? 'rolled_back_with_conflicts' : 'rolled_back';
        $migration_summary = json_decode((string)($migration['summary_json'] ?? '{}'), true);
        if (!is_array($migration_summary)) { $migration_summary = array(); }
        $migration_summary['rollback'] = array('restored_records'=>$restored,'conflicts'=>$conflicts,'rolled_back_at'=>self::now());
        $log_updated = $wpdb->update($tables['migrations'], array('status'=>$status,'conflict_count'=>$conflicts,'rolled_back_at'=>self::now(),'summary_json'=>wp_json_encode($migration_summary, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)), array('migration_id'=>$migration_id));
        if ($log_updated === false) { return new WP_Error('migration_log_update_failed', 'The records were restored, but the migration log could not be updated. The transaction will be rolled back.'); }
        return array('restored'=>$restored,'conflicts'=>$conflicts,'status'=>$status);
    }

    private static function persist_collection_submission($payload, $backfill_defaults = true, $migration_map = array()) {
        global $wpdb;
        $tables = self::table_names();
        $database_id = $payload['database_id']; $slug = $payload['slug'];
        $next_version = $payload['existing'] ? $payload['template_version'] + (!empty($payload['changed']) ? 1 : 0) : 1;
        $summary = $payload['summary'];
        $wpdb->query('START TRANSACTION');
        if (!empty($payload['existing'])) {
            $locked_version = $wpdb->get_var($wpdb->prepare(
                'SELECT template_version FROM %i WHERE database_id = %s AND slug = %s LIMIT 1 FOR UPDATE',
                $tables['collections'], $database_id, $slug
            ));
            if ($locked_version === null || (int)$locked_version !== (int)$payload['template_version']) {
                $wpdb->query('ROLLBACK');
                return new WP_Error('collection_template_stale', 'This template changed after the preview was created. Reopen the collection and generate a fresh migration preview before applying.');
            }
        } else {
            $existing_id = $wpdb->get_var($wpdb->prepare(
                'SELECT id FROM %i WHERE database_id = %s AND slug = %s LIMIT 1 FOR UPDATE',
                $tables['collections'], $database_id, $slug
            ));
            if ($existing_id) {
                $wpdb->query('ROLLBACK');
                return new WP_Error('collection_created_after_preview', 'A collection with this ID was created after the preview. Reopen the Collections screen and try again.');
            }
        }
        $saved = self::insert_collection(
            $database_id, $slug, $payload['name'], $payload['singular'],
            $payload['description'], $payload['schema'], $payload['sort_order'],
            $payload['status'], $payload['mode'], $payload['templates'],
            $payload['parent_id'], $next_version, null, $payload['visual'] ?? null, $payload['sections'] ?? null
        );
        if (!$saved) {
            $wpdb->query('ROLLBACK');
            return new WP_Error('collection_save_failed', 'The collection could not be saved. No changes were applied.');
        }
        if (!empty($payload['changed'])) {
            if (!empty($payload['existing'])) {
                $migration = self::apply_template_data_migration(
                    $database_id, $slug, (int)$payload['template_version'], (int)$next_version,
                    $payload['old_schema'], $payload['schema'], $migration_map, (bool)$backfill_defaults
                );
                if (is_wp_error($migration)) {
                    $wpdb->query('ROLLBACK');
                    update_option('kgdm_last_migration_error', sanitize_text_field($migration->get_error_message()), false);
                    return $migration;
                }
                $summary['migration_id'] = $migration['migration_id'];
                $summary['migration_counts'] = $migration['summary']['counts'];
            }
            $summary['records_backfilled_with_defaults'] = !empty($summary['migration_counts']) ? (int)$summary['migration_counts']['defaults_added'] : 0;
            $summary['defaults_backfill_enabled'] = (bool)$backfill_defaults;
            $revision = self::add_template_revision($database_id, $slug, $next_version, $payload['schema'], $payload['templates'], $summary);
            if ($revision === false) {
                $wpdb->query('ROLLBACK');
                return new WP_Error('revision_save_failed', 'The collection was not applied because its template revision could not be saved.');
            }
        } elseif (!$payload['existing']) {
            $revision = self::add_template_revision($database_id, $slug, $next_version, $payload['schema'], $payload['templates'], array('initial'=>true));
            if ($revision === false) { $wpdb->query('ROLLBACK'); return new WP_Error('revision_save_failed', 'The initial template revision could not be saved.'); }
        }
        $commit = $wpdb->query('COMMIT');
        if ($commit === false) {
            $wpdb->query('ROLLBACK');
            return new WP_Error('collection_commit_failed', 'The collection update could not be committed. The transaction was rolled back.');
        }
        self::invalidate_collection_query_cache($database_id, $slug);
        delete_option('kgdm_last_migration_error');
        return $saved;
    }

    public function handle_preview_collection() {
        self::require_admin();
        check_admin_referer('kgdm_save_collection');
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- This allowlisted normalizer unslashes, sanitizes and validates each submitted field before persistence.
        $payload = self::normalize_collection_submission($_POST);
        if (is_wp_error($payload)) {
            update_option('kgdm_last_collection_error', sanitize_text_field($payload->get_error_message()), false);
            self::redirect(array('tab'=>'collections','db'=>sanitize_key(wp_unslash($_POST['database_id'] ?? '')),'collection'=>sanitize_title(wp_unslash($_POST['collection_slug'] ?? '')),'notice'=>'collection_invalid'));
        }
        $token = wp_generate_password(28, false, false);
        $transient_key = 'kgdm_collection_draft_' . get_current_user_id() . '_' . $token;
        set_transient($transient_key, array('user_id'=>get_current_user_id(),'payload'=>$payload,'created_at'=>self::now()), 30 * MINUTE_IN_SECONDS);
        self::redirect(array('tab'=>'collections','db'=>$payload['database_id'],'collection'=>$payload['slug'],'preview'=>$token));
    }

    // Retain the old admin-post action as an alias for cached forms from V2.1.2.
    public function handle_save_collection() { $this->handle_preview_collection(); }

    public function handle_apply_collection() {
        self::require_admin();
        $token = sanitize_text_field(wp_unslash($_POST['preview_token'] ?? ''));
        check_admin_referer('kgdm_apply_collection_' . $token);
        $key = 'kgdm_collection_draft_' . get_current_user_id() . '_' . $token;
        $draft = get_transient($key);
        if (!is_array($draft) || (int)($draft['user_id'] ?? 0) !== get_current_user_id() || empty($draft['payload'])) {
            self::redirect(array('tab'=>'collections','notice'=>'collection_preview_expired'));
        }
        $payload = $draft['payload'];
        $migration_map = array();
        $submitted_map = map_deep(wp_unslash($_POST['migration_map'] ?? array()), 'sanitize_text_field');
        if (is_array($submitted_map)) {
            $allowed_sources = array_fill_keys((array)($payload['summary']['removed_fields_retained'] ?? array()), true);
            $allowed_targets = array_fill_keys((array)($payload['summary']['added_fields'] ?? array()), true);
            foreach ($submitted_map as $target => $source) {
                $target = sanitize_text_field((string)$target); $source = sanitize_text_field((string)$source);
                if ($source !== '' && isset($allowed_targets[$target]) && isset($allowed_sources[$source])) { $migration_map[$target] = $source; }
            }
        }
        $result = self::persist_collection_submission($payload, !empty($_POST['backfill_defaults']), $migration_map);
        delete_transient($key);
        if (is_wp_error($result)) {
            update_option('kgdm_last_collection_error', sanitize_text_field($result->get_error_message()), false);
            self::redirect(array('tab'=>'collections','db'=>$payload['database_id'],'collection'=>$payload['slug'],'notice'=>'collection_save_failed'));
        }
        delete_option('kgdm_last_collection_error');
        self::redirect(array('tab'=>'collections','db'=>$payload['database_id'],'collection'=>$payload['slug'],'notice'=>'collection_saved'));
    }

    public function handle_cancel_collection_preview() {
        self::require_admin();
        $token = sanitize_text_field(wp_unslash($_POST['preview_token'] ?? ''));
        check_admin_referer('kgdm_cancel_collection_preview_' . $token);
        delete_transient('kgdm_collection_draft_' . get_current_user_id() . '_' . $token);
        $database_id = sanitize_key(wp_unslash($_POST['database_id'] ?? ''));
        $slug = sanitize_title(wp_unslash($_POST['collection_slug'] ?? ''));
        self::redirect(array('tab'=>'collections','db'=>$database_id,'collection'=>$slug));
    }

    private static function render_collection_migration_preview($database_id, $slug, $token) {
        $key = 'kgdm_collection_draft_' . get_current_user_id() . '_' . sanitize_text_field($token);
        $draft = get_transient($key);
        if (!is_array($draft) || (int)($draft['user_id'] ?? 0) !== get_current_user_id() || empty($draft['payload'])) {
            echo '<section class="kgdm-panel"><h2>Form preview expired</h2><p>The unsaved preview is no longer available. Reopen the collection and review the changes again.</p><a class="button" href="'.esc_url(self::tab_url('collections',array('db'=>$database_id,'collection'=>$slug))).'">Return to collection</a></section>';
            return;
        }
        $payload = $draft['payload']; $summary = (array)$payload['summary'];
        $new_flat = self::flatten_schema_fields((array)($payload['schema'] ?? array()));
        echo '<section class="kgdm-panel kgdm-migration-preview"><div class="kgdm-section-head"><div><h2>Review form and data changes</h2><p>Nothing has been changed yet. Review this preview before applying the new template.</p></div><span class="kgdm-status">'.(int)($summary['record_count'] ?? 0).' existing records</span></div>';
        echo '<div class="kgdm-preview-summary"><div><strong>'.count((array)($summary['added_fields'] ?? array())).'</strong><span>New fields</span></div><div><strong>'.count((array)($summary['removed_fields_retained'] ?? array())).'</strong><span>Removed from form, values retained</span></div><div><strong>'.count((array)($summary['changed_fields'] ?? array())).'</strong><span>Changed fields</span></div><div><strong>'.count((array)($summary['added_templates'] ?? array())).'</strong><span>New category forms</span></div></div>';
        if (!empty($summary['added_fields'])) { echo '<h3>New fields</h3><ul>'; foreach ($summary['added_fields'] as $field) { echo '<li><code>'.esc_html($field).'</code></li>'; } echo '</ul>'; }
        if (!empty($summary['removed_fields_retained'])) { echo '<h3>Removed from the new form — existing values will be preserved</h3><ul>'; foreach ($summary['removed_fields_retained'] as $field) { echo '<li><code>'.esc_html($field).'</code> — kept in the record JSON as legacy data.</li>'; } echo '</ul>'; }
        if (!empty($summary['changed_fields'])) {
            echo '<h3>Changed fields</h3><ul>';
            foreach ($summary['changed_fields'] as $field) {
                echo '<li><code>' . esc_html($field['key']) . '</code>';
                if (!empty($field['type_changed'])) {
                    echo ' (' . esc_html($field['old_type']) . ' → ' . esc_html($field['new_type']) . ')';
                }
                echo ' — existing values will not be overwritten.</li>';
            }
            echo '</ul>';
        }
        if (!empty($summary['added_templates'])) { echo '<h3>New category forms</h3><p>'.esc_html(implode(', ', $summary['added_templates'])).'</p>'; }
        $audit = (array)($summary['data_audit'] ?? array());
        if (!empty($audit['fields'])) {
            echo '<h3>Full existing-record data audit</h3><p>All '.count($audit['fields']).' fields in the new form are checked across '.(int)($audit['records_checked'] ?? 0).' saved records, including deleted records. <strong>'.(int)($audit['records_needing_review'] ?? 0).' records need review</strong> because a required/new value is missing or a populated value uses a changed field type. Optional empty values are shown for information and do not block the update.</p>';
            if (!empty($audit['unassigned_template_records'])) {
                echo '<p class="description"><strong>'.(int)$audit['unassigned_template_records'].' existing records are not assigned to a category form.</strong> They are not automatically assigned; choose a category while editing those records.</p>';
            }
            echo '<div class="kgdm-table-wrap"><table class="widefat striped"><thead><tr><th>Field / category</th><th>Filled</th><th>Missing</th><th>Type review</th><th>Change</th><th>Default</th><th>Example records</th></tr></thead><tbody>';
            foreach ($audit['fields'] as $entry) {
                $change_label = !empty($entry['type_changed']) ? (($entry['old_type'] ?: '—').' → '.($entry['new_type'] ?: '—')) : (string)($entry['change'] ?? (!empty($entry['added']) ? 'New field' : 'Existing field'));
                $default_value = !empty($entry['has_default']) ? (string)($entry['default_preview'] ?? 'Yes') : '—';
                echo '<tr><td><strong>'.esc_html($entry['label'] ?? $entry['path']).'</strong><br><code>'.esc_html($entry['path']).'</code>'.(!empty($entry['template_name'])?'<br><small>'.esc_html($entry['template_name']).'</small>':'').'</td><td>'.(int)$entry['filled'].'</td><td>'.(int)$entry['missing'].'</td><td>'.(int)($entry['type_review'] ?? 0).'</td><td>'.esc_html($change_label).'</td><td><code>'.esc_html($default_value).'</code></td><td>'.esc_html(implode(', ',(array)($entry['examples'] ?? array()))).'</td></tr>';
            }
            echo '</tbody></table></div><p class="description">“Type review” counts records with existing values that need manual checking after a field type change. No automatic type conversion is performed.</p>';
        } else {
            echo '<h3>Full existing-record data audit</h3>';
            if (empty($summary['record_count']) && !empty($new_flat)) {
                echo '<p>No existing records need auditing yet. The form fields above will be used for new records.</p>';
            } else {
                echo '<p>No form fields are defined. This collection uses a flexible JSON record structure.</p>';
            }
        }

        if (!empty($summary['removed_templates'])) { echo '<h3>Removed category forms</h3><p>'.esc_html(implode(', ', $summary['removed_templates'])).' — template metadata already saved on records will remain.</p>'; }
        if (empty($summary['added_fields']) && empty($summary['removed_fields_retained']) && empty($summary['changed_fields']) && empty($summary['templates_changed']) && empty($summary['parent_changed'])) {
            echo '<p>No structural form changes were detected. Only the collection name, description or folder location may change.</p>';
        }
        $removed_fields = (array)($summary['removed_fields_retained'] ?? array());
        $added_fields = (array)($summary['added_fields'] ?? array());
        $old_flat = self::flatten_schema_fields((array)($payload['old_schema'] ?? array()));
        $mapping_targets = array_values(array_filter($added_fields, function($path) use ($new_flat, $payload) {
            return isset($new_flat[$path]) && self::migration_path_supports_direct_copy((array)$payload['schema'], $path);
        }));
        $mapping_sources = array_values(array_filter($removed_fields, function($path) use ($old_flat, $payload) {
            return isset($old_flat[$path]) && self::migration_path_supports_direct_copy((array)$payload['old_schema'], $path);
        }));
        if (!empty($mapping_sources) && !empty($mapping_targets)) {
            echo '<h3>Optional field mapping</h3><p>Copy values from retired fields into new fields when a field key has changed. The original source field stays in the record as legacy data. Nested group fields are supported; repeater child fields are excluded because they require row-by-row mapping. Incompatible values are skipped and reported.</p><div class="kgdm-table-wrap"><table class="widefat striped"><thead><tr><th>New field</th><th>Copy values from old field</th></tr></thead><tbody>';
            foreach ($mapping_targets as $target_path) {
                $target_label = (string)($new_flat[$target_path]['label'] ?? $target_path);
                echo '<tr><td><strong>'.esc_html($target_label).'</strong><br><code>'.esc_html($target_path).'</code></td><td><select form="kgdm-apply-collection-form" name="migration_map['.esc_attr($target_path).']"><option value="">Do not copy</option>';
                foreach ($mapping_sources as $source_path) { echo '<option value="'.esc_attr($source_path).'">'.esc_html($source_path).'</option>'; }
                echo '</select></td></tr>';
            }
            echo '</tbody></table></div>';
        }
        echo '<div class="kgdm-preview-protection"><strong>Data protection</strong><p>Every changed record is snapshotted before migration. Mapped values are copied only when the destination is empty; the source is retained. Type changes are not converted automatically. A migration log and guarded rollback are available after applying. Only records stored in KGDM tables are migrated; external/master source datasets are left untouched.</p></div>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" id="kgdm-apply-collection-form" class="kgdm-preview-actions"><input type="hidden" name="action" value="kgdm_apply_collection"><input type="hidden" name="preview_token" value="'.esc_attr($token).'">'; wp_nonce_field('kgdm_apply_collection_' . $token);
        if (!empty($summary['has_added_defaults']) && (int)($summary['record_count'] ?? 0) > 0) {
            echo '<label class="kgdm-radio"><input type="checkbox" name="backfill_defaults" value="1" checked> Add schema and category-template defaults to missing new fields in existing records (existing values stay untouched).</label>';
        } else { echo '<input type="hidden" name="backfill_defaults" value="0">'; }
        echo '<button class="button button-primary"><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span> Apply reviewed changes</button></form>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="kgdm-preview-cancel"><input type="hidden" name="action" value="kgdm_cancel_collection_preview"><input type="hidden" name="preview_token" value="'.esc_attr($token).'"><input type="hidden" name="database_id" value="'.esc_attr($database_id).'"><input type="hidden" name="collection_slug" value="'.esc_attr($slug).'">'; wp_nonce_field('kgdm_cancel_collection_preview_' . $token); echo '<button class="button">Cancel and discard preview</button></form></section>';
    }

    public function handle_restore_template_revision() {
        self::require_admin(); check_admin_referer('kgdm_restore_template_revision');
        global $wpdb; $tables = self::table_names();
        $database_id = sanitize_key(wp_unslash($_POST['database_id'] ?? ''));
        $slug = sanitize_title(wp_unslash($_POST['collection_slug'] ?? ''));
        $revision_id = absint($_POST['revision_id'] ?? 0);
        $collection = self::get_collection($database_id, $slug, true);
        $revision = $wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE revision_id = %d AND database_id = %s AND collection_slug = %s LIMIT 1', $tables['template_versions'], $revision_id, $database_id, $slug), ARRAY_A);
        if (!$collection || !$revision) { self::redirect(array('tab'=>'collections','db'=>$database_id,'collection'=>$slug,'notice'=>'revision_missing')); }
        $schema = self::sanitize_field_schema((string)$revision['schema_json']);
        $templates = self::sanitize_form_templates((string)$revision['form_templates_json']);
        if (is_wp_error($schema) || is_wp_error($templates)) { self::redirect(array('tab'=>'collections','db'=>$database_id,'collection'=>$slug,'notice'=>'revision_invalid')); }
        $template_check = self::validate_templates_against_schema($templates, $schema);
        if (is_wp_error($template_check)) { self::redirect(array('tab'=>'collections','db'=>$database_id,'collection'=>$slug,'notice'=>'revision_invalid')); }
        $summary = self::schema_diff($collection['schema'], $schema, $collection['form_templates'], $templates);
        $summary['restored_from_version'] = (int)$revision['version'];
        $summary['record_count'] = self::count_admin_records($database_id, $slug, true) + self::count_admin_records($database_id, $slug, false);
        $old_flat = self::flatten_schema_fields($collection['schema']); $new_flat = self::flatten_schema_fields($schema);
        $summary['has_added_defaults'] = false;
        foreach ($new_flat as $path => $field) { if (!isset($old_flat[$path]) && array_key_exists('default',$field)) { $summary['has_added_defaults']=true; break; } }
        if (!$summary['has_added_defaults'] && self::templates_have_added_defaults($collection['schema'], $schema, $templates)) { $summary['has_added_defaults'] = true; }
        $summary['data_audit'] = self::audit_schema_coverage($database_id, $slug, $collection['schema'], $schema, $templates);
        $payload = array(
            'database_id'=>$database_id, 'slug'=>$slug, 'name'=>$collection['name'], 'singular'=>$collection['singular_name'],
            'description'=>$collection['description'], 'mode'=>$collection['collection_mode'], 'schema'=>$schema, 'templates'=>$templates,
            'parent_id'=>(string)($collection['parent_id'] ?? ''), 'summary'=>$summary, 'changed'=>true, 'existing'=>true,
            'sort_order'=>(int)$collection['sort_order'], 'status'=>$collection['status'], 'old_schema'=>$collection['schema'],
            'old_templates'=>$collection['form_templates'], 'template_version'=>(int)($collection['template_version'] ?? 1),
        );
        $token = wp_generate_password(28, false, false);
        set_transient('kgdm_collection_draft_' . get_current_user_id() . '_' . $token, array('user_id'=>get_current_user_id(),'payload'=>$payload,'created_at'=>self::now()), 30 * MINUTE_IN_SECONDS);
        self::redirect(array('tab'=>'collections','db'=>$database_id,'collection'=>$slug,'preview'=>$token));
    }

    public function handle_rollback_migration() {
        self::require_admin();
        check_admin_referer('kgdm_rollback_migration');
        $database_id = sanitize_key(wp_unslash($_POST['database_id'] ?? ''));
        $slug = sanitize_title(wp_unslash($_POST['collection_slug'] ?? ''));
        $migration_id = sanitize_text_field(wp_unslash($_POST['migration_id'] ?? ''));
        if (!preg_match('/^[a-f0-9-]{36}$/i', $migration_id)) { self::redirect(array('tab'=>'collections','db'=>$database_id,'collection'=>$slug,'notice'=>'migration_missing')); }
        global $wpdb;
        $tables = self::table_names();
        $wpdb->query('START TRANSACTION');
        $result = self::rollback_template_data_migration($migration_id, $database_id, $slug);
        if (is_wp_error($result)) {
            $wpdb->query('ROLLBACK');
            update_option('kgdm_last_migration_error', sanitize_text_field($result->get_error_message()), false);
            self::redirect(array('tab'=>'collections','db'=>$database_id,'collection'=>$slug,'notice'=>'migration_rollback_failed'));
        }
        $commit = $wpdb->query('COMMIT');
        if ($commit === false) {
            $wpdb->query('ROLLBACK');
            update_option('kgdm_last_migration_error', 'The rollback transaction could not be committed.', false);
            self::redirect(array('tab'=>'collections','db'=>$database_id,'collection'=>$slug,'notice'=>'migration_rollback_failed'));
        }
        self::invalidate_collection_query_cache($database_id, $slug);
        update_option('kgdm_last_migration_result', $result, false);
        self::redirect(array('tab'=>'collections','db'=>$database_id,'collection'=>$slug,'notice'=>$result['conflicts'] > 0 ? 'migration_rollback_partial' : 'migration_rolled_back'));
    }

    public function handle_archive_collection() {
        self::require_admin(); check_admin_referer('kgdm_archive_collection');
        $db = sanitize_key(wp_unslash($_POST['database_id'] ?? ''));
        $slug = sanitize_title(wp_unslash($_POST['collection_slug'] ?? ''));
        $collection = self::get_collection($db, $slug, true);
        $ok = self::get_database($db, false) && self::archive_collection_subtree($db, $collection);
        self::redirect(array('tab'=>'trash','trash_type'=>'folders','db'=>$db,'notice'=>$ok ? 'collection_archived' : 'collection_trash_failed'));
    }

    public function handle_restore_collection() {
        self::require_admin(); check_admin_referer('kgdm_restore_collection');
        $db = sanitize_key(wp_unslash($_POST['database_id'] ?? ''));
        $slug = sanitize_title(wp_unslash($_POST['collection_slug'] ?? ''));
        $collection = self::get_collection($db, $slug, true);
        $result = self::get_database($db, false) ? self::restore_collection_subtree($db, $collection) : false;
        if (is_wp_error($result)) {
            update_option('kgdm_last_collection_error', $result->get_error_message(), false);
            self::redirect(array('tab'=>'trash','trash_type'=>'folders','db'=>$db,'notice'=>'collection_restore_parent_first'));
        }
        self::redirect(array('tab'=>'trash','trash_type'=>'folders','db'=>$db,'notice'=>$result ? 'collection_restored' : 'collection_restore_failed'));
    }

    public function handle_delete_collection() {
        self::require_admin(); check_admin_referer('kgdm_delete_collection');
        global $wpdb; $tables = self::table_names();
        $db = sanitize_key(wp_unslash($_POST['database_id'] ?? ''));
        $slug = sanitize_title(wp_unslash($_POST['collection_slug'] ?? ''));
        $collection = self::get_collection($db, $slug, true);
        if (!$collection || ($collection['status'] ?? '') !== 'archived') {
            update_option('kgdm_last_collection_error', 'Only folders currently in Trash can be permanently deleted.', false);
            self::redirect(array('tab'=>'trash','trash_type'=>'folders','db'=>$db,'notice'=>'collection_purge_failed'));
        }
        if (!self::get_database($db, false)) {
            update_option('kgdm_last_collection_error', 'Restore the archived database first. Folder recovery and deletion are managed after the database is restored.', false);
            self::redirect(array('tab'=>'trash','trash_type'=>'folders','db'=>$db,'notice'=>'collection_purge_database_first'));
        }
        $transactional = self::backup_tables_are_transactional();
        if (is_wp_error($transactional)) {
            update_option('kgdm_last_collection_error', $transactional->get_error_message(), false);
            self::redirect(array('tab'=>'trash','trash_type'=>'folders','db'=>$db,'notice'=>'collection_purge_failed'));
        }
        $all_collections = self::get_collections($db, true);
        $all_by_id = array();
        foreach ($all_collections as $item) { $all_by_id[(string)$item['id']] = $item; }
        if (!self::collection_is_trash_root($collection, $all_by_id)) {
            update_option('kgdm_last_collection_error', 'Restore the trashed parent folder first. The child folder will appear in Trash after its parent is restored.', false);
            self::redirect(array('tab'=>'trash','trash_type'=>'folders','db'=>$db,'notice'=>'collection_purge_parent_first'));
        }
        $subtree = self::collection_subtree($all_collections, $collection['id']);
        if (empty($subtree)) {
            update_option('kgdm_last_collection_error', 'The selected folder subtree could not be loaded. No data was changed.', false);
            self::redirect(array('tab'=>'trash','trash_type'=>'folders','db'=>$db,'notice'=>'collection_purge_failed'));
        }
        $collection_ids = array_values(array_unique(array_map(function($item) { return (string)$item['id']; }, $subtree)));
        $slugs = array_values(array_unique(array_map(function($item) { return (string)$item['slug']; }, $subtree)));
        if ($wpdb->query('START TRANSACTION') === false) {
            update_option('kgdm_last_collection_error', 'The database could not start a safe delete transaction. No data was changed.', false);
            self::redirect(array('tab'=>'trash','trash_type'=>'folders','db'=>$db,'notice'=>'collection_purge_failed'));
        }
        $failed = false;
        foreach (array_chunk($collection_ids, 250) as $id_batch) {
            $placeholders = implode(',', array_fill(0, count($id_batch), '%s'));
            $migration_query = $wpdb->prepare(
                'SELECT migration_id FROM %i WHERE database_id = %s AND collection_id IN (' . $placeholders . ')',
                array_merge(array($tables['migrations'], $db), $id_batch)
            );
            $migration_ids = $wpdb->get_col($migration_query);
            if ($wpdb->last_error !== '') { $failed = true; break; }
            foreach (array_chunk(array_values(array_filter(array_map('strval', (array)$migration_ids))), 250) as $migration_batch) {
                if (self::delete_rows_in_column($tables['migration_records'], 'migration_id', $migration_batch) === false) { $failed = true; break; }
            }
            if ($failed) { break; }
            // Remove snapshots by record ID as well, including any legacy/orphaned
            // snapshot rows whose migration log entry is no longer present.
            $record_query = $wpdb->prepare(
                'SELECT record_id FROM %i WHERE database_id = %s AND collection_id IN (' . $placeholders . ')',
                array_merge(array($tables['records'], $db), $id_batch)
            );
            $record_ids = $wpdb->get_col($record_query);
            if ($wpdb->last_error !== '') { $failed = true; break; }
            foreach (array_chunk(array_values(array_filter(array_map('strval', (array)$record_ids))), 250) as $record_batch) {
                if (self::delete_rows_in_column($tables['migration_records'], 'record_id', $record_batch) === false) { $failed = true; break; }
            }
            if ($failed) { break; }
            if (self::delete_rows_in_column($tables['records'], 'collection_id', $id_batch, 'database_id', $db) === false
                || self::delete_rows_in_column($tables['template_versions'], 'collection_id', $id_batch, 'database_id', $db) === false
                || self::delete_rows_in_column($tables['migrations'], 'collection_id', $id_batch, 'database_id', $db) === false
                || self::delete_rows_in_column($tables['collections'], 'id', $id_batch, 'database_id', $db) === false) {
                $failed = true;
                break;
            }
        }
        if ($failed || $wpdb->query('COMMIT') === false) {
            $wpdb->query('ROLLBACK');
            update_option('kgdm_last_collection_error', 'The folder subtree could not be deleted. The transaction was rolled back and stored data was retained.', false);
            self::redirect(array('tab'=>'trash','trash_type'=>'folders','db'=>$db,'notice'=>'collection_purge_failed'));
        }
        delete_option('kgdm_last_collection_error');
        foreach ($slugs as $deleted_slug) { self::invalidate_collection_query_cache($db, $deleted_slug); }
        self::redirect(array('tab'=>'trash','trash_type'=>'folders','db'=>$db,'notice'=>'collection_purged'));
    }

    public function handle_save_record() {
        self::require_admin(); check_admin_referer('kgdm_save_record');
        $db = sanitize_key(wp_unslash($_POST['database_id'] ?? ''));
        $collection_slug = sanitize_title(wp_unslash($_POST['collection_slug'] ?? ''));
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON must be decoded before recursive sanitization; sanitize_tree() and schema validation run before saving.
        $raw = wp_unslash($_POST['record_json'] ?? '');
        $original_id = sanitize_title(wp_unslash($_POST['original_record_id'] ?? ''));
        $collection = self::get_collection($db, $collection_slug, false);
        if (!$collection || !is_string($raw) || strlen($raw) > self::MAX_IMPORT_BYTES) { self::redirect(array('tab'=>'records','db'=>$db,'collection'=>$collection_slug,'notice'=>'record_invalid')); }
        $record = json_decode($raw, true, 64);
        if (!is_array($record) || json_last_error() !== JSON_ERROR_NONE || isset($record[0])) { self::redirect(array('tab'=>'records','db'=>$db,'collection'=>$collection_slug,'notice'=>'record_invalid_json')); }
        $record = self::sanitize_tree($record);
        $template_id = sanitize_title((string)($record['_kgdm_template'] ?? ''));
        $template_definition = null;
        if (!empty($collection['form_templates'])) {
            foreach ($collection['form_templates'] as $candidate) { if (($candidate['category'] ?? '') === $template_id) { $template_definition = $candidate; break; } }
            if (!$template_definition) { self::redirect(array('tab'=>'records','db'=>$db,'collection'=>$collection_slug,'notice'=>'record_template_required')); }
        }
        $name = sanitize_text_field((string)($record['name'] ?? $record['title'] ?? $record['label'] ?? ''));
        $id = sanitize_title((string)($record['id'] ?? $name));
        if ($id === '') { self::redirect(array('tab'=>'records','db'=>$db,'collection'=>$collection_slug,'notice'=>'record_required')); }
        $record['id'] = $id;
        $record['_kgdm_template_version'] = (int)($collection['template_version'] ?? 1);
        $publication_check = self::validate_record_publication_dates($record);
        if (is_wp_error($publication_check)) { self::redirect(array('tab'=>'records','db'=>$db,'collection'=>$collection_slug,'notice'=>'record_publication_dates_invalid')); }
        $record = self::sanitize_record_metadata($record, $collection);
        $valid = self::validate_record_schema($record, $collection['schema'], $template_definition);
        if (is_wp_error($valid)) { self::redirect(array('tab'=>'records','db'=>$db,'collection'=>$collection_slug,'notice'=>'record_schema_error')); }
        if ($original_id === '') {
            if (self::db_record_entry($db, $collection_slug, $id) !== null || self::get_admin_record($db, $collection_slug, $id, false) !== null) {
                self::redirect(array('tab'=>'records','db'=>$db,'collection'=>$collection_slug,'notice'=>'record_id_exists'));
            }
        } elseif ($original_id !== $id) {
            $old_records = self::get_admin_records($db, $collection_slug, false);
            if (!isset($old_records[$original_id])) {
                self::redirect(array('tab'=>'records','db'=>$db,'collection'=>$collection_slug,'notice'=>'record_missing'));
            }
            if (self::db_record_entry($db, $collection_slug, $id) !== null || self::get_admin_record($db, $collection_slug, $id, false) !== null) {
                self::redirect(array('tab'=>'records','db'=>$db,'collection'=>$collection_slug,'notice'=>'record_id_exists'));
            }
            if (!self::rename_record($db, $collection_slug, $original_id, $id, $old_records[$original_id], $record)) {
                self::redirect(array('tab'=>'records','db'=>$db,'collection'=>$collection_slug,'notice'=>'record_save_failed'));
            }
            self::redirect(array('tab'=>'records','db'=>$db,'collection'=>$collection_slug,'notice'=>'record_saved'));
        }
        if (!self::upsert_record($db, $collection_slug, $id, $record, 'active')) {
            self::redirect(array('tab'=>'records','db'=>$db,'collection'=>$collection_slug,'notice'=>'record_save_failed'));
        }
        self::redirect(array('tab'=>'records','db'=>$db,'collection'=>$collection_slug,'notice'=>'record_saved'));
    }

    public function handle_delete_record() {
        self::require_admin(); check_admin_referer('kgdm_delete_record');
        $db = sanitize_key(wp_unslash($_POST['database_id'] ?? ''));
        $collection = sanitize_title(wp_unslash($_POST['collection_slug'] ?? ''));
        $id = sanitize_title(wp_unslash($_POST['record_id'] ?? ''));
        $records = self::get_admin_records($db, $collection, false);
        if (!isset($records[$id])) { self::redirect(array('tab'=>'records','db'=>$db,'collection'=>$collection,'notice'=>'record_missing')); }
        if (!self::upsert_record($db, $collection, $id, $records[$id], 'deleted')) {
            self::redirect(array('tab'=>'records','db'=>$db,'collection'=>$collection,'notice'=>'record_delete_failed'));
        }
        self::redirect(array('tab'=>'records','db'=>$db,'collection'=>$collection,'notice'=>'record_deleted'));
    }

    public function handle_restore_record() {
        self::require_admin(); check_admin_referer('kgdm_restore_record');
        $db = sanitize_key(wp_unslash($_POST['database_id'] ?? ''));
        $collection = sanitize_title(wp_unslash($_POST['collection_slug'] ?? ''));
        $id = sanitize_title(wp_unslash($_POST['record_id'] ?? ''));
        if (!self::get_database($db, false) || !self::get_collection($db, $collection, false)) {
            self::redirect(array('tab'=>'trash','trash_type'=>'records','db'=>$db,'notice'=>'record_restore_parent_first'));
        }
        $entry = self::db_record_entry($db, $collection, $id);
        if (!$entry || $entry['status'] !== 'deleted') { self::redirect(array('tab'=>'trash','trash_type'=>'records','db'=>$db,'notice'=>'record_missing')); }
        if (!empty($entry['record']['__kgdm_restore_base'])) {
            global $wpdb; $tables = self::table_names(); $coll = self::get_collection($db, $collection, true);
            $deleted = $coll ? $wpdb->delete($tables['records'], array('collection_id'=>$coll['id'],'item_key'=>$id)) : false;
            if ($deleted === false || $deleted < 1) { self::redirect(array('tab'=>'trash','trash_type'=>'records','db'=>$db,'notice'=>'record_restore_failed')); }
            self::flush_record_cache($db, $collection, $id);
        } elseif (!self::upsert_record($db, $collection, $id, $entry['record'], 'active')) {
            self::redirect(array('tab'=>'trash','trash_type'=>'records','db'=>$db,'notice'=>'record_restore_failed'));
        }
        self::redirect(array('tab'=>'trash','trash_type'=>'records','db'=>$db,'notice'=>'record_restored'));
    }


    public function handle_purge_record() {
        self::require_admin(); check_admin_referer('kgdm_purge_record');
        global $wpdb; $tables = self::table_names();
        $db = sanitize_key(wp_unslash($_POST['database_id'] ?? ''));
        $collection_slug = sanitize_title(wp_unslash($_POST['collection_slug'] ?? ''));
        $id = sanitize_title(wp_unslash($_POST['record_id'] ?? ''));
        $database = self::get_database($db, false);
        $collection = self::get_collection($db, $collection_slug, false);
        if (!$database || !$collection || $id === '') {
            self::redirect(array('tab'=>'trash','trash_type'=>'records','db'=>$db,'notice'=>'record_purge_failed'));
        }
        $row = $wpdb->get_row($wpdb->prepare('SELECT record_id FROM %i WHERE database_id = %s AND collection_id = %s AND item_key = %s AND status = %s LIMIT 1', $tables['records'], $db, $collection['id'], $id, 'deleted'), ARRAY_A);
        if (!$row) { self::redirect(array('tab'=>'trash','trash_type'=>'records','db'=>$db,'notice'=>'record_missing')); }
        // Detect bundled source-backed rows before opening the SQL transaction;
        // the provider may construct a large master dataset, so do not hold DB locks while it runs.
        $is_master_record = self::is_legacy_master_record($db, $collection_slug, $id);
        $transactional = self::backup_tables_are_transactional();
        if (is_wp_error($transactional) || $wpdb->query('START TRANSACTION') === false) {
            update_option('kgdm_last_trash_error', is_wp_error($transactional) ? $transactional->get_error_message() : 'A safe delete transaction could not be started.', false);
            self::redirect(array('tab'=>'trash','trash_type'=>'records','db'=>$db,'notice'=>'record_purge_failed'));
        }
        $record_db_id = (int)$row['record_id'];
        $snapshot_delete = $wpdb->delete($tables['migration_records'], array('record_id'=>$record_db_id), array('%d'));
        if ($is_master_record) {
            // The source dataset is bundled outside KGDM's tables. Retain only a
            // minimal, non-restorable marker so the source item cannot reappear.
            $tombstone = array('id'=>$id,'_kgdm_permanent_tombstone'=>true);
            $encoded = self::encode_record_payload($tombstone);
            $record_change = is_wp_error($encoded) ? false : $wpdb->update($tables['records'], array(
                'item_name'=>$id,
                'payload'=>$encoded['json'],
                'payload_hash'=>$encoded['hash'],
                'payload_version'=>$encoded['version'],
                'payload_format'=>$encoded['format'],
                'status'=>'purged',
                'updated_at'=>self::now(),
                'updated_by'=>get_current_user_id(),
            ), array('record_id'=>$record_db_id,'status'=>'deleted'));
        } else {
            $record_change = $wpdb->delete($tables['records'], array('record_id'=>$record_db_id,'status'=>'deleted'));
        }
        if ($snapshot_delete === false || $record_change === false || $record_change < 1 || $wpdb->query('COMMIT') === false) {
            $wpdb->query('ROLLBACK');
            update_option('kgdm_last_trash_error', 'The record and its recovery snapshots could not be permanently deleted. The transaction was rolled back.', false);
            self::redirect(array('tab'=>'trash','trash_type'=>'records','db'=>$db,'notice'=>'record_purge_failed'));
        }
        delete_option('kgdm_last_trash_error');
        self::flush_record_cache($db, $collection_slug, $id);
        self::redirect(array('tab'=>'trash','trash_type'=>'records','db'=>$db,'notice'=>$is_master_record ? 'record_purged_source' : 'record_purged'));
    }

    /**
     * Backups are stored outside the public uploads tree in a site-local directory.
     * An optional filter can move this directory to a path outside the web root.
     */
    private static function backup_directory($create = true) {
        if (!function_exists('WP_Filesystem') || !function_exists('wp_handle_upload')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        $base = defined('WP_CONTENT_DIR') ? WP_CONTENT_DIR : (rtrim(ABSPATH, '/\\') . '/wp-content');
        $site_id = function_exists('get_current_blog_id') ? (int)get_current_blog_id() : 1;
        $directory = trailingslashit($base) . 'kgdm-private-backups-site-' . max(1, $site_id);
        $directory = apply_filters('kgdm_backup_directory', $directory, $site_id);
        if (!is_string($directory) || trim($directory) === '') { return new WP_Error('kgdm_backup_path_invalid', 'The configured backup directory is invalid.'); }
        $directory = untrailingslashit($directory);
        if ($create && !is_dir($directory) && !wp_mkdir_p($directory)) {
            return new WP_Error('kgdm_backup_directory_unavailable', 'The private backup directory could not be created. Check filesystem permissions.');
        }
        if (!is_dir($directory) || ($create && !wp_is_writable($directory)) || (!$create && !is_readable($directory))) {
            return new WP_Error('kgdm_backup_directory_unavailable', 'The private backup directory is missing or does not have the required filesystem permissions.');
        }
        // Deny direct HTTP access on Apache/IIS and prevent directory listing.
        $htaccess = "# KG Database Management private backups\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n";
        if (!file_exists($directory . '/.htaccess') && @file_put_contents($directory . '/.htaccess', $htaccess, LOCK_EX) === false) {
            return new WP_Error('kgdm_backup_protection_failed', 'The private backup directory could not be protected with an Apache access rule. No backup was created.');
        }
        if (!file_exists($directory . '/web.config')) {
            $web_config = '<?xml version="1.0" encoding="UTF-8"?><configuration><system.webServer><security><authorization><remove users="*" roles="" verbs="" /><add accessType="Deny" users="*" /></authorization></security></system.webServer></configuration>';
            @file_put_contents($directory . '/web.config', $web_config, LOCK_EX);
        }
        if (!file_exists($directory . '/index.php') && @file_put_contents($directory . '/index.php', "<?php\n// Silence is golden.\n", LOCK_EX) === false) {
            return new WP_Error('kgdm_backup_protection_failed', 'The private backup directory could not be protected against directory listing. No backup was created.');
        }
        return $directory;
    }

    /** Apply restrictive permissions through WordPress's filesystem abstraction when available. */
    private static function set_backup_file_permissions($path) {
        if (!function_exists('WP_Filesystem')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        if (!WP_Filesystem(false, dirname($path))) { return false; }
        global $wp_filesystem;
        return is_object($wp_filesystem) && $wp_filesystem->chmod($path, 0600);
    }

    private static function backup_table_order() {
        return array('databases','collections','records','template_versions','migrations','migration_records');
    }

    private static function backup_index() {
        $index = get_option(self::BACKUP_INDEX_OPTION, array());
        return is_array($index) ? $index : array();
    }

    private static function save_backup_index($index) {
        if (!is_array($index)) { return false; }
        uasort($index, function($a, $b) {
            return strcmp((string)($b['created_at'] ?? ''), (string)($a['created_at'] ?? ''));
        });
        return update_option(self::BACKUP_INDEX_OPTION, $index, false);
    }

    private static function add_backup_index_entry($entry) {
        $index = self::backup_index();
        $index[(string)$entry['id']] = $entry;
        return self::save_backup_index($index);
    }

    /** Capture all six KGDM tables from one InnoDB consistent-read snapshot. */
    private static function build_full_backup_payload($purpose = 'manual') {
        global $wpdb;
        $transactional = self::backup_tables_are_transactional();
        if (is_wp_error($transactional)) { return $transactional; }
        if ($wpdb->query('START TRANSACTION WITH CONSISTENT SNAPSHOT') === false) {
            return new WP_Error('kgdm_backup_transaction_failed', 'A consistent database snapshot could not be started. No backup was created.');
        }
        $tables = self::table_names();
        $table_data = array();
        $row_counts = array();
        foreach (self::backup_table_order() as $key) {
            $table = $tables[$key] ?? '';
            if ($table === '') {
                $wpdb->query('ROLLBACK');
                return new WP_Error('kgdm_backup_table_missing', 'A required KGDM table mapping is missing.');
            }
            $wpdb->last_error = '';
            $rows = $wpdb->get_results($wpdb->prepare('SELECT * FROM %i ORDER BY 1 ASC', $table), ARRAY_A);
            if (!is_array($rows) || $wpdb->last_error !== '') {
                $wpdb->query('ROLLBACK');
                return new WP_Error('kgdm_backup_read_failed', 'Could not read the KGDM ' . $key . ' table: ' . (string)$wpdb->last_error);
            }
            $table_data[$key] = $rows;
            $row_counts[$key] = count($rows);
        }
        $integrity_warnings = array();
        $database_ids = array();
        foreach ((array)$table_data['databases'] as $database_row) {
            if (!empty($database_row['id'])) { $database_ids[] = (string)$database_row['id']; }
        }
        foreach ($database_ids as $database_id) {
            $integrity = self::validate_database_json_storage($database_id);
            if (!is_wp_error($integrity) && !empty($integrity['invalid'])) {
                foreach ($integrity['invalid'] as $invalid) {
                    $integrity_warnings[] = array(
                        'database_id'=>$database_id,
                        'record_id'=>(string)($invalid['record_id'] ?? ''),
                        'reason'=>(string)($invalid['reason'] ?? 'Invalid record payload.'),
                    );
                }
            }
        }
        if ($wpdb->query('COMMIT') === false) {
            $wpdb->query('ROLLBACK');
            return new WP_Error('kgdm_backup_commit_failed', 'The consistent backup snapshot could not be completed.');
        }
        return array(
            'format'=>'kgdm-full-backup',
            'format_version'=>1,
            'created_at'=>self::now(),
            'purpose'=>sanitize_key($purpose) ?: 'manual',
            'plugin_version'=>self::VERSION,
            'database_schema_version'=>(string)get_option(self::SCHEMA_OPTION, self::SCHEMA_VERSION),
            'json_storage_version'=>self::JSON_STORAGE_VERSION,
            'active_database'=>(string)get_option(self::ACTIVE_DB_OPTION, ''),
            'plugin_settings'=>self::get_settings(),
            'row_counts'=>$row_counts,
            'integrity_warnings'=>$integrity_warnings,
            'tables'=>$table_data,
        );
    }

    private static function encode_full_backup($payload) {
        $json = wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        if (!is_string($json)) { return new WP_Error('kgdm_backup_encode_failed', 'The full backup could not be encoded as JSON.'); }
        if (strlen($json) > self::MAX_BACKUP_CONTENT_BYTES) { return new WP_Error('kgdm_backup_too_large', 'The backup exceeds the 512 MB uncompressed safety limit.'); }
        $checksum = hash('sha256', $json);
        $envelope = array('payload'=>$payload, 'checksum'=>$checksum);
        $envelope_json = wp_json_encode($envelope, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        if (!is_string($envelope_json)) { return new WP_Error('kgdm_backup_encode_failed', 'The backup checksum envelope could not be encoded.'); }
        if (!function_exists('gzencode')) { return new WP_Error('kgdm_gzip_unavailable', 'PHP zlib is required to create compressed KGDM backups.'); }
        $compressed = gzencode($envelope_json, 6);
        if (!is_string($compressed)) { return new WP_Error('kgdm_backup_compress_failed', 'The backup could not be compressed.'); }
        return array('binary'=>$compressed, 'checksum'=>$checksum, 'json_bytes'=>strlen($envelope_json));
    }

    private static function create_full_backup($purpose = 'manual') {
        $directory = self::backup_directory(true);
        if (is_wp_error($directory)) { return $directory; }
        $payload = self::build_full_backup_payload($purpose);
        if (is_wp_error($payload)) { return $payload; }
        $encoded = self::encode_full_backup($payload);
        if (is_wp_error($encoded)) { return $encoded; }
        if (strlen($encoded['binary']) > self::MAX_BACKUP_FILE_BYTES) { return new WP_Error('kgdm_backup_too_large', 'The compressed backup exceeds the 256 MB file limit.'); }
        $id = str_replace('-', '', wp_generate_uuid4());
        $filename = 'kgdm-backup-' . gmdate('Ymd-His') . '-' . $id . '.json.gz';
        $path = trailingslashit($directory) . $filename;
        $written = @file_put_contents($path, $encoded['binary'], LOCK_EX);
        if ($written === false || $written !== strlen($encoded['binary'])) {
            wp_delete_file($path);
            return new WP_Error('kgdm_backup_write_failed', 'The backup file could not be written completely.');
        }
        self::set_backup_file_permissions($path);
        $entry = array(
            'id'=>$id,
            'filename'=>$filename,
            'created_at'=>$payload['created_at'],
            'purpose'=>$payload['purpose'],
            'size'=>$written,
            'checksum'=>$encoded['checksum'],
            'row_counts'=>$payload['row_counts'],
            'warning_count'=>count($payload['integrity_warnings']),
            'plugin_version'=>self::VERSION,
            'status'=>'verified',
        );
        if (!self::add_backup_index_entry($entry)) {
            wp_delete_file($path);
            return new WP_Error('kgdm_backup_index_failed', 'The backup file was created but its recovery index could not be saved. The incomplete backup file was removed.');
        }
        return $entry;
    }

    /** Validate archive path, compression, format, checksum and exact current table columns. */
    private static function read_full_backup($filename) {
        global $wpdb;
        $filename = basename((string)$filename);
        if ($filename === '' || !preg_match('/^kgdm-backup-[a-zA-Z0-9._-]+\.json\.gz$/', $filename)) {
            return new WP_Error('kgdm_backup_filename_invalid', 'The selected backup filename is invalid.');
        }
        $directory = self::backup_directory(false);
        if (is_wp_error($directory)) { return $directory; }
        $path = trailingslashit($directory) . $filename;
        $real_directory = realpath($directory);
        $real_path = realpath($path);
        if (!$real_directory || !$real_path || strpos($real_path, trailingslashit($real_directory)) !== 0 || !is_file($real_path)) {
            return new WP_Error('kgdm_backup_not_found', 'The selected backup file was not found in the private backup directory.');
        }
        $size = filesize($real_path);
        if ($size === false || $size <= 0 || $size > self::MAX_BACKUP_FILE_BYTES) {
            return new WP_Error('kgdm_backup_size_invalid', 'The backup file is empty or exceeds the 256 MB safety limit.');
        }
        $binary = file_get_contents($real_path);
        if (!is_string($binary) || !function_exists('gzdecode')) { return new WP_Error('kgdm_backup_read_failed', 'The backup file could not be read or PHP zlib is unavailable.'); }
        $json = @gzdecode($binary, self::MAX_BACKUP_CONTENT_BYTES);
        if (!is_string($json) || strlen($json) > self::MAX_BACKUP_CONTENT_BYTES) { return new WP_Error('kgdm_backup_decompress_failed', 'The backup archive is damaged or exceeds the decompressed size limit.'); }
        $envelope = json_decode($json, true, 128);
        if (!is_array($envelope) || json_last_error() !== JSON_ERROR_NONE || !isset($envelope['payload'], $envelope['checksum']) || !is_array($envelope['payload'])) {
            return new WP_Error('kgdm_backup_json_invalid', 'The backup JSON envelope is invalid.');
        }
        $payload_json = wp_json_encode($envelope['payload'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        if (!is_string($payload_json) || !hash_equals((string)$envelope['checksum'], hash('sha256', $payload_json))) {
            return new WP_Error('kgdm_backup_checksum_invalid', 'The backup checksum does not match. The archive may be damaged or modified.');
        }
        $payload = $envelope['payload'];
        if (($payload['format'] ?? '') !== 'kgdm-full-backup' || (int)($payload['format_version'] ?? 0) !== 1 || !isset($payload['tables']) || !is_array($payload['tables'])) {
            return new WP_Error('kgdm_backup_format_unsupported', 'This is not a supported KGDM full backup (format version 1).');
        }
        if ((int)($payload['json_storage_version'] ?? 0) !== self::JSON_STORAGE_VERSION) {
            return new WP_Error('kgdm_backup_json_storage_unsupported', 'The backup uses an unsupported JSON storage format version.');
        }
        $tables = self::table_names();
        $expected_keys = self::backup_table_order();
        $actual_keys = array_keys($payload['tables']);
        sort($expected_keys); sort($actual_keys);
        if ($expected_keys !== $actual_keys) { return new WP_Error('kgdm_backup_tables_invalid', 'The backup does not contain the complete set of six KGDM tables.'); }
        $declared_counts = (array)($payload['row_counts'] ?? array());
        foreach (self::backup_table_order() as $key) {
            if (!isset($declared_counts[$key]) || (int)$declared_counts[$key] !== count($payload['tables'][$key])) {
                return new WP_Error('kgdm_backup_row_counts_invalid', 'The backup row-count manifest does not match the archived ' . $key . ' table.');
            }
        }
        foreach (self::backup_table_order() as $key) {
            if (!is_array($payload['tables'][$key])) { return new WP_Error('kgdm_backup_rows_invalid', 'The backup table data for ' . $key . ' is invalid.'); }
            $columns = $wpdb->get_col($wpdb->prepare('SHOW COLUMNS FROM %i', $tables[$key]), 0);
            if (!is_array($columns) || empty($columns)) { return new WP_Error('kgdm_backup_schema_unavailable', 'The current KGDM table schema could not be inspected.'); }
            $expected_columns = $columns; sort($expected_columns);
            $legacy_column_sets = array();
            if ($key === 'databases') { $legacy_column_sets[] = array_values(array_diff($expected_columns, array('visual_json'))); }
            if ($key === 'collections') {
                $legacy_column_sets[] = array_values(array_diff($expected_columns, array('visual_json','sections_json')));
                $legacy_column_sets[] = array_values(array_diff($expected_columns, array('visual_json','sections_json','trash_batch_id')));
                $legacy_column_sets[] = array_values(array_diff($expected_columns, array('sections_json')));
                $legacy_column_sets[] = array_values(array_diff($expected_columns, array('visual_json')));
            }
            foreach ($legacy_column_sets as &$legacy_set) { sort($legacy_set); } unset($legacy_set);
            foreach ($payload['tables'][$key] as $row_index => $row) {
                if (!is_array($row)) { return new WP_Error('kgdm_backup_row_invalid', 'A backup table row is not a valid object.'); }
                $row_columns = array_keys($row); sort($row_columns);
                if (in_array($row_columns, $legacy_column_sets, true)) {
                    // Older archives predate appearance/section metadata and grouped folder Trash.
                    if ($key === 'databases' && !array_key_exists('visual_json', $row)) { $payload['tables'][$key][$row_index]['visual_json'] = wp_json_encode(self::default_visual_settings(true)); }
                    if ($key === 'collections') {
                        if (!array_key_exists('visual_json', $row)) { $payload['tables'][$key][$row_index]['visual_json'] = wp_json_encode(self::default_visual_settings(false)); }
                        if (!array_key_exists('sections_json', $row)) { $payload['tables'][$key][$row_index]['sections_json'] = '[]'; }
                        if (!array_key_exists('trash_batch_id', $row)) { $payload['tables'][$key][$row_index]['trash_batch_id'] = ''; }
                    }
                    $row_columns = array_keys($payload['tables'][$key][$row_index]); sort($row_columns);
                }
                if ($row_columns !== $expected_columns) { return new WP_Error('kgdm_backup_columns_mismatch', 'The backup columns for ' . $key . ' do not match the installed storage schema. Update the plugin or use a compatible backup.'); }
                foreach ($row as $value) { if (is_array($value) || is_object($value)) { return new WP_Error('kgdm_backup_row_value_invalid', 'A backup row contains a nested value where a database scalar is required.'); } }
            }
        }
        // Check primary identifiers and internal references before any restore writes.
        $database_ids = array();
        foreach ($payload['tables']['databases'] as $row) {
            $id = (string)($row['id'] ?? '');
            if ($id === '' || isset($database_ids[$id])) { return new WP_Error('kgdm_backup_database_ids_invalid', 'The backup contains a missing or duplicate database ID.'); }
            $database_ids[$id] = true;
        }
        $collection_ids = array(); $collection_pairs = array();
        foreach ($payload['tables']['collections'] as $row) {
            $id = (string)($row['id'] ?? ''); $database_id = (string)($row['database_id'] ?? ''); $slug = (string)($row['slug'] ?? '');
            $pair = $database_id . "\0" . $slug;
            if ($id === '' || $slug === '' || !isset($database_ids[$database_id]) || isset($collection_ids[$id]) || isset($collection_pairs[$pair])) {
                return new WP_Error('kgdm_backup_collection_references_invalid', 'The backup contains a duplicate collection ID/slug or a collection with a missing database reference.');
            }
            $collection_ids[$id] = $database_id; $collection_pairs[$pair] = true;
        }
        $record_ids = array(); $record_pairs = array();
        foreach ($payload['tables']['records'] as $row) {
            $record_id = (string)($row['record_id'] ?? ''); $collection_id = (string)($row['collection_id'] ?? ''); $database_id = (string)($row['database_id'] ?? '');
            $pair = $collection_id . "\0" . (string)($row['item_key'] ?? '');
            if ($record_id === '' || !isset($collection_ids[$collection_id]) || $collection_ids[$collection_id] !== $database_id || isset($record_ids[$record_id]) || isset($record_pairs[$pair])) {
                return new WP_Error('kgdm_backup_record_references_invalid', 'The backup contains a duplicate record ID/key or a record with a missing collection/database reference.');
            }
            $record_ids[$record_id] = true; $record_pairs[$pair] = true;
        }
        $revision_ids = array();
        foreach ($payload['tables']['template_versions'] as $row) {
            $revision_id = (string)($row['revision_id'] ?? ''); $collection_id = (string)($row['collection_id'] ?? ''); $database_id = (string)($row['database_id'] ?? '');
            if ($revision_id === '' || !isset($collection_ids[$collection_id]) || $collection_ids[$collection_id] !== $database_id || isset($revision_ids[$revision_id])) {
                return new WP_Error('kgdm_backup_revision_references_invalid', 'The backup contains an invalid or duplicate template revision reference.');
            }
            $revision_ids[$revision_id] = true;
        }
        $migration_ids = array();
        foreach ($payload['tables']['migrations'] as $row) {
            $migration_id = (string)($row['migration_id'] ?? ''); $collection_id = (string)($row['collection_id'] ?? ''); $database_id = (string)($row['database_id'] ?? '');
            if ($migration_id === '' || !isset($collection_ids[$collection_id]) || $collection_ids[$collection_id] !== $database_id || isset($migration_ids[$migration_id])) {
                return new WP_Error('kgdm_backup_migration_references_invalid', 'The backup contains an invalid or duplicate data migration reference.');
            }
            $migration_ids[$migration_id] = true;
        }
        $snapshot_ids = array();
        foreach ($payload['tables']['migration_records'] as $row) {
            $snapshot_id = (string)($row['snapshot_id'] ?? ''); $migration_id = (string)($row['migration_id'] ?? '');
            if ($snapshot_id === '' || !isset($migration_ids[$migration_id]) || isset($snapshot_ids[$snapshot_id])) {
                return new WP_Error('kgdm_backup_snapshot_references_invalid', 'The backup contains an invalid or duplicate migration recovery snapshot.');
            }
            $snapshot_ids[$snapshot_id] = true;
        }
        // Recalculate record integrity rather than relying only on the manifest metadata.
        $detected_warnings = array();
        foreach ($payload['tables']['records'] as $row) {
            $decoded_record = self::decode_record_payload((string)($row['payload'] ?? ''), (string)($row['payload_hash'] ?? ''));
            if (is_wp_error($decoded_record) || (int)($row['payload_version'] ?? 0) !== self::JSON_STORAGE_VERSION || (string)($row['payload_format'] ?? '') !== 'json') {
                $detected_warnings[] = array(
                    'record_id'=>(string)($row['item_key'] ?? ''),
                    'reason'=>is_wp_error($decoded_record) ? $decoded_record->get_error_message() : 'Unsupported JSON storage metadata.',
                );
            }
        }
        $payload['integrity_warnings'] = $detected_warnings;
        return array('payload'=>$payload,'path'=>$real_path,'checksum'=>(string)$envelope['checksum'],'size'=>$size);
    }

    private static function backup_tables_are_transactional() {
        global $wpdb;
        $tables = self::table_names();
        foreach (self::backup_table_order() as $key) {
            $status = $wpdb->get_row($wpdb->prepare('SHOW TABLE STATUS WHERE Name = %s', $tables[$key]), ARRAY_A);
            $engine = is_array($status) ? strtolower((string)($status['Engine'] ?? '')) : '';
            if ($engine !== 'innodb') {
                return new WP_Error('kgdm_backup_nontransactional_table', 'Safe full restore requires InnoDB tables. The ' . $key . ' table currently reports engine ' . ($engine !== '' ? $engine : 'unknown') . '. No data was changed.');
            }
        }
        return true;
    }

    private static function restore_full_backup($filename) {
        global $wpdb;
        $backup = self::read_full_backup($filename);
        if (is_wp_error($backup)) { return $backup; }
        $transactional = self::backup_tables_are_transactional();
        if (is_wp_error($transactional)) { return $transactional; }
        // Automatic safety point before any table is cleared.
        $safety = self::create_full_backup('pre-restore');
        if (is_wp_error($safety)) { return new WP_Error('kgdm_pre_restore_backup_failed', 'Restore was cancelled because a pre-restore safety backup could not be created: ' . $safety->get_error_message()); }
        $tables = self::table_names();
        if ($wpdb->query('START TRANSACTION') === false) { return new WP_Error('kgdm_restore_transaction_failed', 'The database could not start a transaction.'); }
        $failed = false;
        // Delete child/snapshot tables before their parent tables; reinsert parents first.
        $delete_order = array('migration_records','migrations','records','template_versions','collections','databases');
        foreach ($delete_order as $key) {
            if ($wpdb->query($wpdb->prepare('DELETE FROM %i', $tables[$key])) === false) { $failed = true; break; }
        }
        if (!$failed) {
            foreach (self::backup_table_order() as $key) {
                foreach ($backup['payload']['tables'][$key] as $row) {
                    if ($wpdb->insert($tables[$key], $row) === false) { $failed = true; break 2; }
                }
            }
        }
        if (!$failed) {
            foreach (self::backup_table_order() as $key) {
                $count = (int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i', $tables[$key]));
                if ($count !== count($backup['payload']['tables'][$key])) { $failed = true; break; }
            }
        }
        if ($failed) {
            $wpdb->query('ROLLBACK');
            return new WP_Error('kgdm_restore_rolled_back', 'Restore failed during table replacement or verification. The transaction was rolled back. Safety backup: ' . $safety['filename']);
        }
        if ($wpdb->query('COMMIT') === false) {
            $wpdb->query('ROLLBACK');
            return new WP_Error('kgdm_restore_commit_failed', 'The restore transaction could not be committed. The database driver was asked to roll it back. Safety backup: ' . $safety['filename']);
        }
        $active = (string)($backup['payload']['active_database'] ?? '');
        if ($active !== '') {
            $exists = $wpdb->get_var($wpdb->prepare('SELECT id FROM %i WHERE id = %s', $tables['databases'], $active));
            if (!$exists) { $active = ''; }
        }
        update_option(self::ACTIVE_DB_OPTION, $active, false);
        self::invalidate_all_query_cache();
        if (isset($backup['payload']['plugin_settings']) && is_array($backup['payload']['plugin_settings'])) {
            $restored_settings = self::get_settings();
            $saved_preferences = (array)$backup['payload']['plugin_settings'];
            if (in_array(($saved_preferences['navigation_layout'] ?? ''), array('tabs','sidebar'), true)) {
                $restored_settings['navigation_layout'] = $saved_preferences['navigation_layout'];
            }
            foreach (array('compact_ui','show_help') as $setting_key) {
                if (array_key_exists($setting_key, $saved_preferences)) { $restored_settings[$setting_key] = !empty($saved_preferences[$setting_key]) ? 1 : 0; }
            }
            if (in_array(($saved_preferences['appearance_mode'] ?? ''), array('system','light','dark'), true)) {
                $restored_settings['appearance_mode'] = $saved_preferences['appearance_mode'];
            }
            // The uninstall deletion policy is intentionally not restored from a backup.
            $restored_settings['delete_data_on_uninstall'] = self::get_settings()['delete_data_on_uninstall'];
            update_option('kgdm_settings', $restored_settings, false);
        }
        return array('restored'=>true,'safety_backup'=>$safety,'row_counts'=>$backup['payload']['row_counts'] ?? array());
    }

    private static function delete_backup_file($backup_id) {
        $index = self::backup_index();
        if (empty($index[$backup_id]['filename'])) { return false; }
        $directory = self::backup_directory(false);
        if (is_wp_error($directory)) { return false; }
        $filename = basename((string)$index[$backup_id]['filename']);
        $path = trailingslashit($directory) . $filename;
        $real_directory = realpath($directory); $real_path = realpath($path);
        if ($real_directory && $real_path && strpos($real_path, trailingslashit($real_directory)) === 0 && is_file($real_path)) { wp_delete_file($real_path); }
        unset($index[$backup_id]);
        self::save_backup_index($index);
        return true;
    }

    private static function require_backup_id($value) {
        return preg_replace('/[^a-fA-F0-9]/', '', (string)$value);
    }

    public function handle_create_backup() {
        self::require_admin(); check_admin_referer('kgdm_create_backup');
        $entry = self::create_full_backup('manual');
        if (is_wp_error($entry)) {
            update_option('kgdm_last_backup_error', sanitize_text_field($entry->get_error_message()), false);
            self::redirect(array('tab'=>'import-export','notice'=>'backup_failed'));
        }
        delete_option('kgdm_last_backup_error');
        self::redirect(array('tab'=>'import-export','notice'=>!empty($entry['warning_count']) ? 'backup_created_warnings' : 'backup_created'));
    }

    public function handle_download_backup() {
        self::require_admin(); check_admin_referer('kgdm_download_backup');
        $id = self::require_backup_id(self::admin_query_param('backup_id')); $index = self::backup_index();
        if ($id === '' || empty($index[$id]['filename'])) { wp_die('Backup not found.'); }
        $backup = self::read_full_backup($index[$id]['filename']);
        if (is_wp_error($backup)) { wp_die(esc_html($backup->get_error_message())); }
        nocache_headers();
        header('Content-Type: application/gzip');
        header('Content-Length: ' . (string)filesize($backup['path']));
        header('Content-Disposition: attachment; filename="' . sanitize_file_name($index[$id]['filename']) . '"');
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile -- Streams a validated, size-limited archive without loading up to 256 MB into PHP memory.
        readfile($backup['path']); exit;
    }

    public function handle_restore_backup() {
        self::require_admin(); check_admin_referer('kgdm_restore_backup');
        $id = self::require_backup_id(self::admin_post_param('backup_id')); $index = self::backup_index();
        $confirmation = strtoupper(trim(sanitize_text_field(wp_unslash($_POST['restore_confirmation'] ?? ''))));
        if ($confirmation !== 'RESTORE KGDM BACKUP') { self::redirect(array('tab'=>'import-export','notice'=>'restore_confirmation_required')); }
        if ($id === '' || empty($index[$id]['filename'])) { self::redirect(array('tab'=>'import-export','notice'=>'backup_missing')); }
        $result = self::restore_full_backup($index[$id]['filename']);
        if (is_wp_error($result)) {
            update_option('kgdm_last_backup_error', sanitize_text_field($result->get_error_message()), false);
            self::redirect(array('tab'=>'import-export','notice'=>'restore_failed'));
        }
        delete_option('kgdm_last_backup_error');
        self::redirect(array('tab'=>'import-export','notice'=>'backup_restored'));
    }

    public function handle_delete_backup() {
        self::require_admin(); check_admin_referer('kgdm_delete_backup');
        $id = self::require_backup_id(self::admin_post_param('backup_id'));
        if ($id === '' || !self::delete_backup_file($id)) { self::redirect(array('tab'=>'import-export','notice'=>'backup_missing')); }
        self::redirect(array('tab'=>'import-export','notice'=>'backup_deleted'));
    }

    public function handle_upload_backup() {
        self::require_admin(); check_admin_referer('kgdm_upload_backup');
        $file = self::uploaded_file('backup_file');
        if (empty($file['tmp_name']) || $file['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'])) { self::redirect(array('tab'=>'import-export','notice'=>'backup_upload_missing')); }
        if (!empty($file['size']) && (int)$file['size'] > self::MAX_BACKUP_FILE_BYTES) { self::redirect(array('tab'=>'import-export','notice'=>'backup_upload_too_large')); }
        $directory = self::backup_directory(true);
        if (is_wp_error($directory)) {
            update_option('kgdm_last_backup_error', sanitize_text_field($directory->get_error_message()), false);
            self::redirect(array('tab'=>'import-export','notice'=>'backup_failed'));
        }
        $original = basename(sanitize_file_name((string)($file['name'] ?? '')));
        if (!preg_match('/\.json\.gz$/i', $original)) { self::redirect(array('tab'=>'import-export','notice'=>'backup_upload_invalid')); }
        // Validate uploaded archive from a temporary copy before it enters the recovery list.
        $id = str_replace('-', '', wp_generate_uuid4());
        $filename = 'kgdm-backup-upload-' . gmdate('Ymd-His') . '-' . $id . '.json.gz';
        $file['name'] = $filename;
        $upload_dir_filter = static function($uploads) use ($directory) {
            $uploads['path'] = $directory;
            $uploads['url'] = '';
            $uploads['subdir'] = '';
            $uploads['basedir'] = $directory;
            $uploads['baseurl'] = '';
            $uploads['error'] = false;
            return $uploads;
        };
        add_filter('upload_dir', $upload_dir_filter, 1000);
        $uploaded = wp_handle_upload($file, array('test_form'=>false,'test_type'=>false));
        remove_filter('upload_dir', $upload_dir_filter, 1000);
        if (!is_array($uploaded) || !empty($uploaded['error']) || empty($uploaded['file'])) { self::redirect(array('tab'=>'import-export','notice'=>'backup_upload_failed')); }
        $destination = $uploaded['file'];
        $filename = basename($destination);
        self::set_backup_file_permissions($destination);
        $validated = self::read_full_backup($filename);
        if (is_wp_error($validated)) {
            wp_delete_file($destination);
            update_option('kgdm_last_backup_error', sanitize_text_field($validated->get_error_message()), false);
            self::redirect(array('tab'=>'import-export','notice'=>'backup_upload_invalid'));
        }
        $payload = $validated['payload'];
        $index_saved = self::add_backup_index_entry(array(
            'id'=>$id,'filename'=>$filename,'created_at'=>(string)($payload['created_at'] ?? self::now()),
            'purpose'=>'uploaded','size'=>(int)filesize($destination),'checksum'=>$validated['checksum'],
            'row_counts'=>(array)($payload['row_counts'] ?? array()),
            'warning_count'=>count((array)($payload['integrity_warnings'] ?? array())),
            'plugin_version'=>(string)($payload['plugin_version'] ?? 'unknown'),'status'=>'verified',
        ));
        if (!$index_saved) { wp_delete_file($destination); self::redirect(array('tab'=>'import-export','notice'=>'backup_failed')); }
        self::redirect(array('tab'=>'import-export','notice'=>'backup_uploaded'));
    }

    private static function export_database($database_id) {
        global $wpdb; $tables = self::table_names();
        $database = self::get_database($database_id, true);
        if (!$database) { return new WP_Error('database_missing','Database not found.'); }
        $collections = self::get_collections($database_id, true);
        $payload_collections = array();
        foreach ($collections as $collection) {
            $payload_collections[$collection['slug']] = array(
                'name'=>$collection['name'],
                'singular_name'=>$collection['singular_name'],
                'description'=>$collection['description'],
                'visual'=>$collection['visual'] ?? self::default_visual_settings(false),
                'sections'=>$collection['sections'] ?? array(),
                'schema'=>$collection['schema'],
                'mode'=>$collection['collection_mode'] ?? 'form',
                'form_templates'=>$collection['form_templates'] ?? array(),
                'parent'=>self::collection_parent_slug($collection),
                'trash_batch_id'=>(string)($collection['trash_batch_id'] ?? ''),
                'template_version'=>(int)($collection['template_version'] ?? 1),
                'sort_order'=>(int)$collection['sort_order'],
                'status'=>$collection['status'],
                'template_history'=>array_map(function($revision){ return array('version'=>(int)$revision['version'],'schema'=>$revision['schema'],'form_templates'=>$revision['form_templates'],'change_summary'=>$revision['change_summary_data'],'created_at'=>$revision['created_at']); }, self::get_template_revisions($database_id, $collection['slug'], 50)),
                'records'=>array(),
            );
            $rows = self::db_records($database_id, $collection['slug'], 'all');
            foreach ($rows as $id => $record) {
                $payload_collections[$collection['slug']]['records'][$id] = array(
                    'status'=>self::record_status($database_id, $collection['slug'], $id),
                    'record'=>$record,
                    'storage'=>array('format'=>'json','version'=>self::JSON_STORAGE_VERSION,'sha256'=>hash('sha256', (string)wp_json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE))),
                );
            }
        }
        return array(
            'format'=>'kgdm-database',
            'format_version'=>1,
            'exported_at'=>self::now(),
            'database'=>array('id'=>$database['id'],'name'=>$database['name'],'description'=>$database['description'],'kind'=>$database['kind'],'visual'=>$database['visual'] ?? self::default_visual_settings(true),'status'=>$database['status'],'api_access'=>$database['api_access'] ?? 'private'),
            'collections'=>$payload_collections,
        );
    }

    private static function validate_database_json_storage($database_id) {
        global $wpdb;
        $tables = self::table_names();
        $database = self::get_database($database_id, true);
        if (!$database) { return new WP_Error('database_missing', 'Database not found.'); }
        $rows = $wpdb->get_results($wpdb->prepare('SELECT record_id, collection_id, item_key, payload, payload_hash, payload_version, payload_format FROM %i WHERE database_id = %s', $tables['records'], $database_id), ARRAY_A);
        $checked = 0; $invalid = array();
        foreach ((array)$rows as $row) {
            $checked++;
            $decoded = self::decode_record_payload($row['payload'], (string)($row['payload_hash'] ?? ''));
            if (is_wp_error($decoded)) {
                $invalid[] = array('record_id'=>(string)$row['item_key'],'reason'=>$decoded->get_error_message());
                continue;
            }
            if ((int)($row['payload_version'] ?? 0) !== self::JSON_STORAGE_VERSION || (string)($row['payload_format'] ?? '') !== 'json') {
                $invalid[] = array('record_id'=>(string)$row['item_key'],'reason'=>'Unsupported JSON storage metadata.');
            }
        }
        return array('database_id'=>$database_id,'checked'=>$checked,'invalid_count'=>count($invalid),'invalid'=>$invalid,'valid'=>count($invalid)===0);
    }

    public function handle_validate_json_storage() {
        self::require_admin();
        check_admin_referer('kgdm_validate_json_storage');
        $db = sanitize_key(self::admin_query_param('database_id'));
        $result = self::validate_database_json_storage($db);
        if (is_wp_error($result)) { wp_die(esc_html($result->get_error_message())); }
        update_option('kgdm_last_json_validation', array_merge($result, array('validated_at'=>self::now())), false);
        self::redirect(array('tab'=>'import-export','db'=>$db,'notice'=>$result['valid'] ? 'json_valid' : 'json_invalid'));
    }

    public function handle_export() {
        self::require_admin(); check_admin_referer('kgdm_export_database');
        $db = sanitize_key(self::admin_query_param('database_id'));
        $payload = self::export_database($db);
        if (is_wp_error($payload)) { wp_die(esc_html($payload->get_error_message())); }
        $json = wp_json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
        if (!is_string($json)) { wp_die('Could not encode database export.'); }
        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . sanitize_file_name($db . '-database-backup-' . gmdate('Y-m-d') . '.json') . '"');
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The attachment is application/json; wp_json_encode with JSON_HEX flags preserves valid JSON while neutralizing HTML delimiters.
        echo $json; exit;
    }

    private static function normalize_import_payload($payload) {
        if (!is_array($payload) || json_last_error() !== JSON_ERROR_NONE) {
            return new WP_Error('invalid_json', 'The uploaded content is not valid JSON.');
        }
        $format = (string)($payload['format'] ?? '');
        $version = (int)($payload['format_version'] ?? 0);
        if (!(($format === 'kgdm-database' && $version === 1) || ($format === 'kumar-database-manager' && $version === 2))) {
            return new WP_Error('unsupported_format', 'Expected kgdm-database format version 1 or a compatible manager V2 backup.');
        }
        $database = $payload['database'] ?? null;
        $collections_in = $payload['collections'] ?? null;
        if (!is_array($database) || !is_array($collections_in)) {
            return new WP_Error('missing_root', 'The JSON needs database and collections objects.');
        }
        $db_id_raw = trim((string)($database['id'] ?? ''));
        $db_name = sanitize_text_field((string)($database['name'] ?? ''));
        $db_id = $db_id_raw === '' ? sanitize_title($db_name) : sanitize_key($db_id_raw);
        $kind = sanitize_key((string)($database['kind'] ?? $database['type'] ?? 'general'));
        if ($db_id === '' || strlen($db_id) > 64 || ($db_id_raw !== '' && $db_id !== strtolower($db_id_raw)) || !preg_match('/^[a-z0-9_-]+$/', $db_id) || $db_name === '') {
            return new WP_Error('invalid_database', 'The database needs a valid name and an optional URL-safe ID. Leave the ID empty to generate it from the name.');
        }
        if (!in_array($kind, array('general','game','app','catalog','knowledge_base','research'), true)) {
            return new WP_Error('invalid_database_type', 'The database kind is not supported.');
        }
        $normalized = array(
            'database'=>array('id'=>$db_id,'name'=>$db_name,'description'=>sanitize_textarea_field((string)($database['description'] ?? '')),'kind'=>$kind,'visual'=>self::sanitize_visual_settings($database['visual'] ?? array(), true)),
            'collections'=>array(),
        );
        $total_records = 0;
        foreach ($collections_in as $key => $definition) {
            if (!is_array($definition)) { return new WP_Error('invalid_collection', 'Every collection must be a JSON object.'); }
            $slug_raw = trim((string)($definition['slug'] ?? $definition['id'] ?? (is_string($key) ? $key : '')));
            if ($slug_raw === '') { $slug_raw = (string)($definition['name'] ?? ''); }
            $slug = sanitize_title($slug_raw);
            if ($slug === '' || strlen($slug) > 191 || isset($normalized['collections'][$slug])) {
                return new WP_Error('invalid_collection_id', 'A collection has an invalid or duplicate slug.');
            }
            $schema_input = $definition['schema'] ?? $definition['fields'] ?? array();
            if (!is_array($schema_input)) { return new WP_Error('invalid_schema', 'Collection fields must be a JSON array.'); }
            $schema = self::sanitize_field_schema(wp_json_encode($schema_input));
            if (is_wp_error($schema)) { return $schema; }
            $mode = sanitize_key((string)($definition['mode'] ?? 'form'));
            if (!in_array($mode, array('form','list'), true)) { return new WP_Error('invalid_collection_mode', 'Collection mode must be form or list.'); }
            $templates_raw = $definition['form_templates'] ?? array();
            if (!is_array($templates_raw)) { return new WP_Error('invalid_form_templates', 'Form templates must be a JSON array.'); }
            $templates = self::sanitize_form_templates(wp_json_encode($templates_raw));
            if (is_wp_error($templates)) { return $templates; }
            if ($mode === 'list') { $schema = array(); $templates = array(); }
            $template_check = self::validate_templates_against_schema($templates, $schema);
            if (is_wp_error($template_check)) { return $template_check; }
            $records_input = $definition['records'] ?? array();
            if (!is_array($records_input)) { return new WP_Error('invalid_records', 'Collection records must be a JSON array or object.'); }
            $records = array();
            foreach ($records_input as $record_key => $record_entry) {
                if (!is_array($record_entry)) { return new WP_Error('invalid_record', 'Every record must be a JSON object.'); }
                $status = 'active';
                if (isset($record_entry['record']) && is_array($record_entry['record'])) {
                    $record = $record_entry['record'];
                    $status = (string)($record_entry['status'] ?? 'active');
                } else {
                    $record = $record_entry;
                    if (isset($record_entry['status']) && in_array($record_entry['status'], array('active','deleted'), true) && isset($record_entry['record'])) {
                        $status = (string)$record_entry['status'];
                    }
                }
                if (!in_array($status, array('active','deleted','purged'), true)) { return new WP_Error('invalid_record_status', 'Record status must be active, deleted or a supported Genshin source tombstone.'); }
                $raw_id = (string)($record['id'] ?? (is_string($record_key) ? $record_key : ''));
                $record_id = sanitize_title($raw_id);
                if ($record_id === '' || strlen($record_id) > 191 || ($raw_id !== '' && $record_id !== strtolower($raw_id))) {
                    return new WP_Error('invalid_record_id', 'Every record needs a valid unique ID.');
                }
                if (isset($records[$record_id])) { return new WP_Error('duplicate_record_id', 'Duplicate record ID in collection '.$slug.': '.$record_id); }
                $record = self::sanitize_tree($record);
                $record['id'] = $record_id;
                if (isset($record_entry['storage']) && is_array($record_entry['storage'])) {
                    $storage_format = (string)($record_entry['storage']['format'] ?? 'json');
                    $storage_version = absint($record_entry['storage']['version'] ?? self::JSON_STORAGE_VERSION);
                    $storage_hash = strtolower(trim((string)($record_entry['storage']['sha256'] ?? '')));
                    if ($storage_format !== 'json' || $storage_version !== self::JSON_STORAGE_VERSION || ($storage_hash !== '' && !preg_match('/^[a-f0-9]{64}$/', $storage_hash))) {
                        return new WP_Error('invalid_record_storage', 'Collection '.$slug.', record '.$record_id.' contains invalid JSON storage metadata.');
                    }
                    if ($storage_hash !== '') {
                        $check_json = wp_json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
                        if (!is_string($check_json) || !hash_equals($storage_hash, hash('sha256', $check_json))) {
                            return new WP_Error('invalid_record_storage_hash', 'Collection '.$slug.', record '.$record_id.' failed JSON integrity validation.');
                        }
                    }
                }
                // Validate the checksum against the original imported payload before normalizing new KGDM metadata.
                if (array_key_exists('_kgdm_publication', $record)) {
                    $publication_check = self::validate_record_publication_dates($record);
                    if (is_wp_error($publication_check)) {
                        return new WP_Error('invalid_record_publication', 'Collection '.$slug.', record '.$record_id.': '.$publication_check->get_error_message());
                    }
                }
                if (array_key_exists('_kgdm_sections', $record) || array_key_exists('_kgdm_publication', $record)) {
                    $record_collection_context = array('sections'=>self::sanitize_collection_sections($definition['sections'] ?? array()));
                    $record = self::sanitize_record_metadata($record, $record_collection_context);
                }
                $is_source_tombstone = $status === 'purged'
                    && $db_id === 'genshin-impact'
                    && !empty($record['_kgdm_permanent_tombstone'])
                    && count(array_diff(array_keys($record), array('id','_kgdm_permanent_tombstone'))) === 0;
                if ($status === 'purged' && !$is_source_tombstone) {
                    return new WP_Error('invalid_record_status', 'Purged records are accepted only as the minimal Genshin master-source suppression marker.');
                }
                if (!$is_source_tombstone) {
                    $template_definition = null;
                    $record_template_id = sanitize_title((string)($record['_kgdm_template'] ?? ''));
                    if ($record_template_id !== '') { foreach ($templates as $candidate_template) { if (($candidate_template['category'] ?? '') === $record_template_id) { $template_definition = $candidate_template; break; } } if (!$template_definition) { return new WP_Error('invalid_record_template', 'Collection '.$slug.', record '.$record_id.' references an unknown category template.'); } }
                    $valid = self::validate_record_schema($record, $schema, $template_definition);
                    if (is_wp_error($valid)) { return new WP_Error('invalid_record_schema', 'Collection '.$slug.', record '.$record_id.': '.$valid->get_error_message()); }
                }
                $records[$record_id] = array('status'=>$status,'record'=>$record);
                $total_records++;
                if ($total_records > 20000) { return new WP_Error('too_many_records', 'A single import can contain at most 20,000 records.'); }
            }
            $collection_status = (string)($definition['status'] ?? 'active');
            if (!in_array($collection_status, array('active','archived'), true)) { return new WP_Error('invalid_collection_status', 'Collection status must be active or archived.'); }
            $trash_batch_id = strtolower(trim((string)($definition['trash_batch_id'] ?? '')));
            if ($trash_batch_id !== '' && !preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-[1-5][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/', $trash_batch_id)) {
                return new WP_Error('invalid_collection_trash_batch', 'Collection Trash group metadata is invalid.');
            }
            if ($collection_status === 'active' && $trash_batch_id !== '') {
                return new WP_Error('invalid_collection_trash_batch', 'An active collection cannot belong to a Trash group.');
            }
            $normalized['collections'][$slug] = array(
                'name'=>sanitize_text_field((string)($definition['name'] ?? ucwords(str_replace('-', ' ', $slug)))),
                'singular_name'=>sanitize_text_field((string)($definition['singular_name'] ?? rtrim((string)($definition['name'] ?? $slug), 's'))),
                'description'=>sanitize_textarea_field((string)($definition['description'] ?? '')),
                'visual'=>self::sanitize_visual_settings($definition['visual'] ?? array(), false),
                'sections'=>self::sanitize_collection_sections($definition['sections'] ?? array()),
                'schema'=>$schema,
                'mode'=>$mode,
                'form_templates'=>$templates,
                'parent'=>sanitize_title((string)($definition['parent'] ?? '')),
                'trash_batch_id'=>$trash_batch_id,
                'template_version'=>max(1, absint($definition['template_version'] ?? 1)),
                'template_history'=>array(),
                'sort_order'=>(int)($definition['sort_order'] ?? 0),
                'status'=>$collection_status,
                'records'=>$records,
            );
            $history_input = $definition['template_history'] ?? array();
            if (!is_array($history_input)) { return new WP_Error('invalid_template_history', 'Template history must be a list of valid template revisions.'); }
            $history_versions = array();
            foreach ($history_input as $history_entry) {
                if (!is_array($history_entry) || !isset($history_entry['version']) || !array_key_exists('schema', $history_entry)) {
                    return new WP_Error('invalid_template_history', 'Every template history entry must include a version and schema.');
                }
                $history_version = absint($history_entry['version']);
                if ($history_version < 1 || isset($history_versions[$history_version])) {
                    return new WP_Error('invalid_template_history', 'Template history versions must be positive and unique.');
                }
                $history_schema = self::sanitize_field_schema(wp_json_encode($history_entry['schema']));
                $history_templates = self::sanitize_form_templates(wp_json_encode($history_entry['form_templates'] ?? array()));
                if (is_wp_error($history_schema) || is_wp_error($history_templates)) {
                    return new WP_Error('invalid_template_history', 'A saved template revision contains an invalid schema or category form.');
                }
                if ($mode === 'list' && (!empty($history_schema) || !empty($history_templates))) {
                    return new WP_Error('invalid_template_history', 'List-only collections cannot import structured form revisions.');
                }
                $history_check = self::validate_templates_against_schema($history_templates, $history_schema);
                if (is_wp_error($history_check)) { return new WP_Error('invalid_template_history', $history_check->get_error_message()); }
                $normalized['collections'][$slug]['template_history'][] = array(
                    'version'=>$history_version,
                    'schema'=>$history_schema,
                    'form_templates'=>$history_templates,
                    'change_summary'=>is_array($history_entry['change_summary'] ?? null) ? $history_entry['change_summary'] : array(),
                );
                $history_versions[$history_version] = true;
            }
            if (!empty($history_versions)) {
                $normalized['collections'][$slug]['template_version'] = max(
                    (int)$normalized['collections'][$slug]['template_version'],
                    max(array_keys($history_versions))
                );
            }
            if (count($normalized['collections']) > 100) { return new WP_Error('too_many_collections', 'A database can contain at most 100 collections.'); }
        }
        foreach ($normalized['collections'] as $slug => $definition) {
            $parent = (string)($definition['parent'] ?? '');
            if ($parent !== '' && (!isset($normalized['collections'][$parent]) || $parent === $slug)) {
                return new WP_Error('invalid_collection_parent', 'Collection ' . $slug . ' references a missing or invalid parent folder.');
            }
        }
        foreach ($normalized['collections'] as $slug => $definition) {
            $cursor = (string)($definition['parent'] ?? ''); $visited = array($slug => true); $depth = 0;
            while ($cursor !== '' && isset($normalized['collections'][$cursor]) && $depth++ < 25) {
                if (isset($visited[$cursor])) { return new WP_Error('collection_parent_cycle', 'Collection folders cannot contain a parent-child cycle.'); }
                $visited[$cursor] = true; $cursor = (string)($normalized['collections'][$cursor]['parent'] ?? '');
            }
        }
        return $normalized;
    }

    public function handle_import() {
        self::require_admin();
        check_admin_referer('kgdm_import_database');
        $raw = '';
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Preserve JSON until decode; normalize_import_payload() validates structure and sanitizes every stored value.
        $pasted = trim((string)wp_unslash($_POST['import_json'] ?? ''));
        if ($pasted !== '') {
            $raw = $pasted;
        } else {
            $import_file = self::uploaded_file('import_file');
            if (!empty($import_file['tmp_name']) && $import_file['error'] === UPLOAD_ERR_OK && is_uploaded_file($import_file['tmp_name'])) {
                if ($import_file['size'] > self::MAX_IMPORT_BYTES) { self::redirect(array('notice'=>'import_too_large')); }
                $raw = file_get_contents($import_file['tmp_name']);
            }
        }
        if (!is_string($raw) || trim($raw) === '') { self::redirect(array('notice'=>'import_missing')); }
        if (strlen($raw) > self::MAX_IMPORT_BYTES) { self::redirect(array('notice'=>'import_too_large')); }
        $decoded = json_decode($raw, true, 128);
        if (json_last_error() !== JSON_ERROR_NONE) { self::redirect(array('notice'=>'import_invalid')); }
        $normalized = self::normalize_import_payload($decoded);
        if (is_wp_error($normalized)) {
            update_option('kgdm_last_import_error', sanitize_text_field($normalized->get_error_message()), false);
            self::redirect(array('notice'=>'import_invalid'));
        }
        $db = $normalized['database']['id'];
        $name = $normalized['database']['name'];
        $description = $normalized['database']['description'];
        $kind = $normalized['database']['kind'];
        $replace = sanitize_key(wp_unslash($_POST['import_mode'] ?? 'merge')) === 'replace';
        global $wpdb;
        $tables = self::table_names();
        if ($wpdb->query('START TRANSACTION') === false) {
            update_option('kgdm_last_import_error', 'The database could not start an import transaction. No data was written.', false);
            self::redirect(array('notice'=>'import_invalid'));
        }
        $failed = false;
        if (!self::get_database($db, true)) {
            $failed = !self::insert_database($db, $name, $description, $kind, 'active', $normalized['database']['visual'] ?? null);
        } else {
            $result = $wpdb->update($tables['databases'], array('status'=>'active','name'=>$name,'description'=>$description,'kind'=>$kind,'visual_json'=>wp_json_encode($normalized['database']['visual'] ?? self::default_visual_settings(true)),'updated_at'=>self::now(),'api_access'=>'private'), array('id'=>$db));
            $failed = ($result === false);
        }
        if (!$failed && $replace) {
            $migration_ids = $wpdb->get_col($wpdb->prepare('SELECT migration_id FROM %i WHERE database_id = %s', $tables['migrations'], $db));
            foreach ((array)$migration_ids as $old_migration_id) { if ($wpdb->delete($tables['migration_records'], array('migration_id'=>$old_migration_id)) === false) { $failed = true; break; } }
            if (!$failed) { $failed = ($wpdb->delete($tables['migrations'], array('database_id'=>$db)) === false); }
            if (!$failed) { $failed = ($wpdb->delete($tables['records'], array('database_id'=>$db)) === false); }
            if (!$failed) { $failed = ($wpdb->delete($tables['template_versions'], array('database_id'=>$db)) === false); }
            if (!$failed) { $failed = ($wpdb->delete($tables['collections'], array('database_id'=>$db)) === false); }
        }
        foreach ($normalized['collections'] as $slug => $definition) {
            if ($failed) { break; }
            $parent_slug = (string)($definition['parent'] ?? '');
            $parent_id = $parent_slug !== '' ? self::collection_id($db, $parent_slug) : '';
            $saved_collection = self::insert_collection($db, $slug, $definition['name'], $definition['singular_name'], $definition['description'], $definition['schema'], $definition['sort_order'], $definition['status'], $definition['mode'] ?? 'form', $definition['form_templates'] ?? array(), $parent_id, (int)($definition['template_version'] ?? 1), (string)($definition['trash_batch_id'] ?? ''), $definition['visual'] ?? null, $definition['sections'] ?? null);
            if (!$saved_collection) { $failed = true; break; }
            foreach ($definition['records'] as $record_id => $entry) {
                if (!self::upsert_record($db, $slug, $record_id, $entry['record'], $entry['status'], false)) { $failed = true; break; }
            }
            if (!$failed) {
                $history = (array)($definition['template_history'] ?? array());
                if (empty($history)) {
                    if (self::add_template_revision($db, $slug, (int)($definition['template_version'] ?? 1), $definition['schema'], $definition['form_templates'] ?? array(), array('imported'=>true)) === false) {
                        $failed = true;
                    }
                } else {
                    foreach ($history as $revision) {
                        if (self::add_template_revision($db, $slug, absint($revision['version']), $revision['schema'], $revision['form_templates'] ?? array(), (array)($revision['change_summary'] ?? array())) === false) {
                            $failed = true;
                            break;
                        }
                    }
                }
            }
        }
        if ($failed) {
            $wpdb->query('ROLLBACK');
            update_option('kgdm_last_import_error', 'Database write failed. The import was rolled back.', false);
            self::redirect(array('notice'=>'import_invalid'));
        }
        if ($wpdb->query('COMMIT') === false) {
            $wpdb->query('ROLLBACK');
            update_option('kgdm_last_import_error', 'The database could not commit the import transaction. The import was rolled back.', false);
            self::redirect(array('notice'=>'import_invalid'));
        }
        // Replace imports can remove collections as well as records, so invalidate the
        // entire KGDM query namespace. Merge imports only affect the imported collections.
        if ($replace) {
            self::invalidate_all_query_cache();
        } else {
            foreach (array_keys($normalized['collections']) as $imported_slug) {
                self::invalidate_collection_query_cache($db, sanitize_title((string)$imported_slug));
            }
        }
        delete_option('kgdm_last_import_error');
        update_option(self::ACTIVE_DB_OPTION, $db, false);
        self::redirect(array('tab'=>'import-export','db'=>$db,'notice'=>'database_imported'));
    }

    private static function count_admin_records($database_id, $collection_slug, $include_deleted = false) {
        global $wpdb;
        $tables = self::table_names();
        $collection = self::get_collection($database_id, $collection_slug, true);
        if (!$collection) { return 0; }
        if ($database_id === 'genshin-impact' && function_exists('kg_genshin_master_data')) {
            return count(self::get_admin_records($database_id, $collection_slug, $include_deleted));
        }
        $status = $include_deleted ? 'deleted' : 'active';
        return (int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE database_id = %s AND collection_id = %s AND status = %s', $tables['records'], $database_id, $collection['id'], $status));
    }

    private static function get_admin_records_page($database_id, $collection_slug, $include_deleted, $limit, $offset) {
        if ($database_id === 'genshin-impact' && function_exists('kg_genshin_master_data')) {
            $records = self::get_admin_records($database_id, $collection_slug, $include_deleted);
            uasort($records, function($a,$b) { return strcasecmp((string)($a['name']??$a['title']??$a['label']??''),(string)($b['name']??$b['title']??$b['label']??'')); });
            return array_slice($records, $offset, $limit, true);
        }
        $entries = self::db_record_entries($database_id, $collection_slug, $include_deleted ? 'deleted' : 'active', $limit, $offset);
        $records = array();
        foreach ($entries as $id => $entry) { $records[$id] = $entry['record']; }
        return $records;
    }

    private static function get_admin_records($database_id, $collection_slug, $include_deleted = false) {
        $managed = self::db_record_entries($database_id, $collection_slug, 'all');
        if ($include_deleted) {
            $deleted_rows = array();
            foreach ($managed as $id => $entry) { if ($entry['status'] === 'deleted') { $deleted_rows[$id] = $entry['record']; } }
            return $deleted_rows;
        }
        $rows = array();
        if ($database_id === 'genshin-impact' && function_exists('kg_genshin_master_data')) {
            $master = kg_genshin_master_data();
            $rows = self::extract_legacy_collection($master, $collection_slug);
        }
        foreach ($managed as $id => $entry) {
            if (in_array($entry['status'], array('deleted','purged'), true)) { unset($rows[$id]); }
            else { $rows[$id] = $entry['record']; }
        }
        return $rows;
    }

    private static function notice_text($notice) {
        $map = array(
            'database_created'=>'Database created.', 'database_updated'=>'Database settings updated.', 'database_archived'=>'Database moved to Trash. Its folders, records and history remain recoverable.', 'database_restored'=>'Database restored from Trash.', 'database_trash_failed'=>'The database could not be moved to Trash.', 'database_restore_failed'=>'The database could not be restored.', 'database_purged'=>'Database and all KGDM-owned contents permanently deleted.', 'database_purge_failed'=>get_option('kgdm_last_trash_error','The database could not be permanently deleted. Existing data was retained.'), 'active_database_set'=>'Active database changed.',
            'database_invalid'=>'Enter a valid database name and ID.', 'database_exists'=>'A database with this ID already exists.', 'database_save_failed'=>'The database could not be saved. Check the WordPress database and try again.', 'api_access_invalid'=>'Select a valid database and API access mode.', 'settings_saved'=>'Settings saved.', 'uninstall_confirmation_required'=>'Other settings were saved, but permanent uninstall deletion was not enabled. Enter DELETE KGDM DATA and save again to confirm.', 'update_retry_complete'=>'The plugin update check completed successfully.', 'update_retry_failed'=>'The plugin update could not be completed. See the Update Log for the failed step and message.', 'api_access_public'=>'Read-only public API access enabled for this database.', 'api_access_private'=>'Public API access disabled. WordPress snippets can still read this database.',
            'collection_saved'=>'Collection saved. Template revision recorded; retired field data is retained.', 'collection_invalid'=>get_option('kgdm_last_collection_error', 'Collection name, ID, nested field schema or form template is invalid.'), 'collection_parent_invalid'=>'Select a valid parent collection in this database.', 'collection_parent_cycle'=>'A folder cannot be placed inside itself or one of its descendants.', 'collection_save_failed'=>get_option('kgdm_last_collection_error', get_option('kgdm_last_migration_error', 'The collection could not be saved. Existing data was retained.')), 'collection_preview_expired'=>'The form preview expired. Reopen the collection and review the changes again.', 'revision_missing'=>'The selected template revision was not found.', 'revision_invalid'=>'The saved template revision could not be restored because its schema is invalid.', 'revision_restored'=>'Template revision restored as a new version. Existing record data was retained.', 'migration_missing'=>'The selected data migration was not found.', 'migration_rollback_failed'=>get_option('kgdm_last_migration_error', 'The data migration could not be rolled back.'), 'migration_rolled_back'=>'Migration data restored from its recovery snapshots.', 'migration_rollback_partial'=>'Rollback completed where records were unchanged. Records edited after migration were left untouched.', 'collection_archived'=>'Folder and its active subfolders moved to Trash as one group. Their records and form history remain stored.', 'collection_trash_failed'=>'The folder could not be moved to Trash.', 'collection_restored'=>'Folder group restored from Trash.', 'collection_restore_failed'=>'The folder could not be restored.', 'collection_restore_parent_first'=>get_option('kgdm_last_collection_error','Restore the parent folder before restoring this child.'), 'collection_purged'=>'Folder, nested folders, records and related history permanently deleted.', 'collection_purge_failed'=>get_option('kgdm_last_collection_error', 'The folder could not be permanently deleted. Existing data was retained.'), 'collection_purge_parent_first'=>'Restore the trashed parent folder first. Its child folders will then appear in Trash.', 'collection_purge_database_first'=>get_option('kgdm_last_collection_error','Restore the archived database before managing folders inside it.'),
            'record_saved'=>'Record saved.', 'record_save_failed'=>'The record could not be saved. Existing data was retained.', 'record_id_exists'=>'That record ID already exists. Choose a different ID or edit the existing record.', 'record_deleted'=>'Record moved to Trash. It can be restored.', 'record_delete_failed'=>'The record could not be moved to Trash.', 'record_restored'=>'Record restored from Trash.', 'record_restore_failed'=>'The record could not be restored. Existing data was retained.', 'record_restore_parent_first'=>'Restore the database and folder first. The deleted record will then be available to restore.', 'record_purged'=>'Record permanently removed from KGDM and its migration recovery snapshots deleted.', 'bulk_records_updated'=>'Bulk update complete: '.absint(self::admin_query_param('bulk_updated',0)).' updated, '.absint(self::admin_query_param('bulk_failed',0)).' skipped.', 'bulk_records_invalid'=>'Select between 1 and 500 active records before applying a bulk update.', 'bulk_date_invalid'=>'Enter valid publication dates. The hide date must be later than the show date.', 'record_purged_source'=>'Genshin source entry permanently removed from KGDM. A hidden suppression marker remains so the bundled entry does not reappear while this KGDM database and collection remain.', 'record_purge_failed'=>get_option('kgdm_last_trash_error','The record could not be permanently deleted. Existing data was retained.'), 'record_missing'=>'The selected record was not found or is already in the requested state.', 'trash_bulk_done'=>'Bulk Trash action complete: '.absint(self::admin_query_param('bulk_done',0)).' completed, '.absint(self::admin_query_param('bulk_failed',0)).' skipped.', 'trash_bulk_empty'=>'Select at least one item on this page before applying a bulk action.', 'trash_bulk_invalid'=>'The selected Trash action is invalid. Refresh the page and try again.', 'record_invalid'=>'The selected database or collection is invalid.', 'record_invalid_json'=>'Record JSON is invalid. Check the syntax.', 'record_required'=>'A record requires a unique ID.', 'record_publication_dates_invalid'=>'Enter valid site-local show/hide dates. The hide date must be later than the show date.', 'record_schema_error'=>'A required field defined by this collection is missing.', 'record_template_required'=>'Select a valid category template before saving this record.',
            'import_missing'=>'Select a JSON database backup.', 'import_too_large'=>'The import file exceeds the 25 MB limit.', 'import_invalid'=>get_option('kgdm_last_import_error', 'The JSON is invalid or does not match the supported KGDM database format.'), 'database_imported'=>'Validated JSON imported successfully.',
            'backup_created'=>'Full KGDM backup created and checksum verified.', 'backup_created_warnings'=>'Full backup created. It includes the current data; one or more saved record payloads failed integrity checks. Review the backup warning count.', 'backup_failed'=>get_option('kgdm_last_backup_error', 'The full backup could not be created.'), 'backup_restored'=>'Full KGDM recovery completed. A pre-restore safety backup was also created.', 'backup_deleted'=>'Backup file deleted.', 'backup_missing'=>'The selected recovery point was not found.', 'backup_uploaded'=>'Uploaded full backup validated and added to recovery points.', 'backup_upload_missing'=>'Select a full .json.gz backup file.', 'backup_upload_too_large'=>'The uploaded backup exceeds the 256 MB file limit.', 'backup_upload_invalid'=>get_option('kgdm_last_backup_error', 'The uploaded archive is invalid or incompatible with this storage schema.'), 'backup_upload_failed'=>'The uploaded backup could not be copied into private storage.', 'restore_confirmation_required'=>'Restore was not started. Type exactly RESTORE KGDM BACKUP to confirm.', 'restore_failed'=>get_option('kgdm_last_backup_error', 'The backup could not be restored. Existing data was retained.'),
        );
        return isset($map[$notice]) ? $map[$notice] : '';
    }

    private static function new_record_template($collection) {
        $record = array('id'=>'new-record');
        foreach ((array)$collection['schema'] as $field) {
            $key = (string)($field['key'] ?? '');
            if ($key === '' || in_array($key, array('id','_kgdm_template','_kgdm_template_version'), true)) { continue; }
            if (array_key_exists('default', $field)) { $record[$key] = $field['default']; continue; }
            switch ($field['type'] ?? 'text') {
                case 'number': $record[$key] = 0; break;
                case 'boolean': $record[$key] = false; break;
                case 'json': case 'multiselect': case 'gallery': case 'repeater': case 'group': $record[$key] = array(); break;
                default: $record[$key] = '';
            }
        }
        self::set_default_paths($record, array(), (array)($collection['schema'] ?? array()));
        return $record;
    }

    private static function database_type_label($kind) {
        $labels = array('game'=>'Game','app'=>'Application','catalog'=>'Catalogue','knowledge_base'=>'Knowledge Base','research'=>'Research','general'=>'General');
        return $labels[$kind] ?? 'General';
    }

    private static function tab_url($tab, $args = array()) {
        // Keep old update-log links working while presenting one Help & updates destination.
        if (in_array($tab, array('update-log','updates'), true)) {
            $tab = 'help';
            $args['help_section'] = 'updates';
        }
        return self::page_url(array_merge(array('tab'=>$tab), $args));
    }

    private static function database_settings_url($database_id) {
        return self::tab_url('databases', array('db'=>$database_id, 'edit_database'=>1));
    }

    private static function render_database_picker($databases, $selected_db, $tab) {
        $active = array_values(array_filter($databases, function($db) { return $db['status'] === 'active'; }));
        if (empty($active)) {
            echo '<div class="kgdm-picker"><span class="kgdm-muted">No database selected</span><a class="button button-primary" href="'.esc_url(self::tab_url('databases')).'">Create database</a></div>';
            return;
        }
        echo '<form class="kgdm-picker" method="get"><input type="hidden" name="page" value="'.esc_attr(self::page_slug_for_tab($tab)).'"><input type="hidden" name="tab" value="'.esc_attr($tab).'">';
        foreach (array('folder','collection','view','trash_type') as $context_key) {
            $context_value = self::admin_query_param($context_key, '');
            if ($context_value !== '') { echo '<input type="hidden" name="'.esc_attr($context_key).'" value="'.esc_attr($context_value).'">'; }
        }
        echo '<label for="kgdm-database-picker">Current database</label><select id="kgdm-database-picker" name="db" class="kgdm-select">';
        foreach ($active as $db) {
            echo '<option value="'.esc_attr($db['id']).'" '.selected($selected_db,$db['id'],false).'>'.esc_html($db['name']).'</option>';
        }
        echo '</select><button class="button">Open</button></form>';
    }

    /** Render a contextual four-step workspace guide that complements native WP navigation. */
    private static function render_workspace_workflow($tab, $database, $selected_db) {
        $steps = array(
            'databases' => array('label'=>'Databases','description'=>'Choose your workspace','icon'=>'dashicons-database'),
            'collections' => array('label'=>'Folders & forms','description'=>'Organize folders and templates','icon'=>'dashicons-open-folder'),
            'records' => array('label'=>'Records','description'=>'Add and manage data','icon'=>'dashicons-list-view'),
            'completeness' => array('label'=>'Completeness','description'=>'Review required information','icon'=>'dashicons-yes-alt'),
        );
        if (!isset($steps[$tab])) { return; }

        $keys = array_keys($steps);
        $active_index = array_search($tab, $keys, true);
        if ($active_index === false) { return; }
        $is_database_active = $database && (($database['status'] ?? '') === 'active');

        $context_slug = '';
        if ($tab === 'collections') {
            $context_slug = sanitize_title(self::admin_query_param('folder', ''));
            if ($context_slug === '') { $context_slug = sanitize_title(self::admin_query_param('edit', '')); }
        } elseif (in_array($tab, array('records','completeness'), true)) {
            $context_slug = sanitize_title(self::admin_query_param('collection', ''));
        }
        $context_collection = ($context_slug !== '' && $selected_db !== '') ? self::get_collection($selected_db, $context_slug, true) : null;
        $context_name = $context_collection && !empty($context_collection['name']) ? $context_collection['name'] : ($context_slug !== '' ? $context_slug : 'All folders');
        $database_name = $database && !empty($database['name']) ? $database['name'] : 'No database selected';

        $urls = array(
            'databases' => self::tab_url('databases', array('db'=>$selected_db)),
            'collections' => self::tab_url('collections', array_merge(array('db'=>$selected_db), $context_slug !== '' ? array('folder'=>$context_slug) : array())),
            'records' => self::tab_url('records', array_merge(array('db'=>$selected_db), $context_slug !== '' ? array('collection'=>$context_slug) : array())),
            'completeness' => self::tab_url('completeness', array_merge(array('db'=>$selected_db), $context_slug !== '' ? array('collection'=>$context_slug) : array())),
        );

        echo '<section class="kgdm-workflow" aria-label="Workspace workflow">';
        echo '<div class="kgdm-workflow-heading"><div class="kgdm-workflow-heading-copy"><span class="kgdm-workflow-eyebrow">WORKSPACE FLOW</span><h3>Build and manage your data</h3><p>Follow the steps in order, or open any stage directly. Your database context stays with you.</p></div>';
        echo '<div class="kgdm-workflow-context"><span class="dashicons dashicons-database" aria-hidden="true"></span><span><small>WORKING IN</small><strong>'.esc_html($database_name).'</strong><em>'.esc_html($context_name).'</em></span></div></div>';
        echo '<nav class="kgdm-workflow-steps" aria-label="Workspace steps">';
        foreach ($steps as $key => $step_data) {
            $index = array_search($key, $keys, true);
            $is_current = $key === $tab;
            $is_next = $index === ($active_index + 1);
            $disabled = $index > 0 && !$is_database_active;
            $classes = array('kgdm-workflow-step');
            if ($is_current) { $classes[] = 'is-current'; }
            if ($is_next) { $classes[] = 'is-next'; }
            if ($disabled) { $classes[] = 'is-disabled'; }
            $state = $is_current ? 'Current' : ($is_next ? 'Next' : 'Earlier');
            $number = (string)($index + 1);
            $aria_current = $is_current ? ' aria-current="step"' : '';
            $aria_disabled = $disabled ? ' aria-disabled="true" tabindex="-1"' : '';
            echo '<a class="'.esc_attr(implode(' ', $classes)).'" href="'.esc_url($disabled ? '#' : $urls[$key]).'"'.$aria_current.$aria_disabled.'>';
            echo '<span class="kgdm-workflow-step-number">'.$number.'</span><span class="kgdm-workflow-step-copy"><strong>'.esc_html($step_data['label']).'</strong><small>'.esc_html($step_data['description']).'</small></span><span class="kgdm-workflow-step-state">'.esc_html($disabled ? 'Locked' : $state).'</span></a>';
        }
        echo '</nav>';

        $next_key = $active_index < (count($keys) - 1) ? $keys[$active_index + 1] : 'databases';
        $next_label = $active_index < (count($keys) - 1) ? $steps[$next_key]['label'] : 'Database overview';
        if (!$is_database_active && $tab === 'databases') {
            if ($database && (($database['status'] ?? '') !== 'active')) {
                echo '<div class="kgdm-workflow-footer"><span class="kgdm-workflow-footer-note"><strong>This database is in Trash.</strong> Restore it or choose another active database before continuing.</span><a class="button" href="'.esc_url(self::tab_url('trash',array('trash_type'=>'databases','db'=>$selected_db))).'">Restore database</a></div>';
            } else {
                echo '<div class="kgdm-workflow-footer"><span class="kgdm-workflow-footer-note"><strong>Start by choosing or creating a database.</strong> Folder, record and completeness steps unlock when an active database is selected.</span><span class="kgdm-workflow-current">Step 1 of 4</span></div>';
            }
        } elseif (!$is_database_active) {
            echo '<div class="kgdm-workflow-footer"><span class="kgdm-workflow-footer-note"><strong>This workspace is not active.</strong> Restore or select an active database to continue.</span><a class="button" href="'.esc_url($urls['databases']).'">Choose database</a></div>';
        } else {
            $footer_note = $active_index < 3 ? 'Next: ' . $next_label : 'You have reached the final review step.';
            $button_label = $active_index < 3 ? 'Continue to ' . $next_label : 'Back to database overview';
            echo '<div class="kgdm-workflow-footer"><span class="kgdm-workflow-footer-note">'.esc_html($footer_note).'</span><a class="button button-primary kgdm-workflow-continue" href="'.esc_url($urls[$next_key]).'">'.esc_html($button_label).' <span class="dashicons dashicons-arrow-right-alt2" aria-hidden="true"></span></a></div>';
        }
        echo '</section>';
    }

    private static function render_tab_databases($databases, $database, $selected_db) {
        $database_summaries = self::database_overview_summaries($databases);
        $active_database_count = 0; $total_collections = 0; $total_records = 0;
        foreach ($database_summaries as $summary) { $active_database_count++; $total_collections += (int)$summary['folders']; $total_records += (int)$summary['records']; }
        $storage_label = self::format_storage_usage(self::get_storage_usage_bytes());
        echo '<div class="kgdm-overview-stats" aria-label="Database overview">';
        echo self::overview_metric_html('Active databases', $active_database_count, 'Available workspaces', 'dashicons-database', 'database');
        echo self::overview_metric_html('Folders', $total_collections, 'Across active databases', 'dashicons-open-folder', 'folders');
        echo self::overview_metric_html('Active records', $total_records, 'Saved records', 'dashicons-list-view', 'records');
        echo self::overview_metric_html('Storage', $storage_label, 'KGDM tables · data and indexes', 'dashicons-database-view', 'storage');
        echo '</div>';
        echo '<div class="kgdm-database-toolbar"><button type="button" class="button button-primary kgdm-open-modal" data-modal-target="#kgdm-create-database-modal" aria-haspopup="dialog" aria-controls="kgdm-create-database-modal" aria-expanded="false"><span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span> Create database</button>';
        self::render_workspace_trash_link('databases');
        echo '</div>';
        echo '<div class="kgdm-modal" id="kgdm-create-database-modal" aria-hidden="true"><div class="kgdm-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="kgdm-create-database-title"><button type="button" class="kgdm-modal-close" aria-label="Close"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></button><section class="kgdm-panel kgdm-create-db-panel" id="kgdm-create-database-panel"><div class="kgdm-panel-icon-heading"><span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span><div><h2 id="kgdm-create-database-title">Create a database</h2><p>Create an independent workspace for a game, application, catalogue or research project.</p></div></div><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="kgdm_create_database">'; wp_nonce_field('kgdm_create_database');
        echo '<label>Database name<input type="text" name="database_name" required placeholder="Example: Genshin Impact"></label><label>Database ID <span class="kgdm-muted">(optional, URL-safe)</span><input type="text" id="kgdm-database-slug" name="database_slug" placeholder="Leave blank to generate it from the name"><small class="kgdm-id-preview">Generated ID: <code id="kgdm-database-id-preview">your-database-name</code></small></label><label>Database type<select name="database_kind"><option value="game">Game</option><option value="app">Application</option><option value="catalog">Catalogue</option><option value="knowledge_base">Knowledge base</option><option value="research">Research</option><option value="general" selected>General</option></select></label><label>Description<textarea name="database_description" rows="3" placeholder="What will this database contain?"></textarea></label>'; self::render_visual_settings_fields('database_visual_create', self::default_visual_settings(true), true, true); echo '<button class="button button-primary"><span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span> Create database</button></form></section></div></div>';
        echo '<section class="kgdm-panel kgdm-db-library-panel" id="kgdm-database-library"><div class="kgdm-section-head"><div><h2>Database library</h2><p>Open a database to browse its folders, or manage its settings.</p></div></div>';
        $active_databases = array_values(array_filter($databases,function($d){return $d['status']==='active';}));
        if (empty($active_databases)) {
            $has_archived = !empty(array_filter($databases,function($d){return $d['status']==='archived';}));
            echo self::empty_state_html('dashicons-database', 'No active databases', $has_archived ? 'Restore an archived database or create a new one.' : 'Create your first database to begin organising folders and records.', array(), 'kgdm-folder-empty');
        } else {
            echo '<div class="kgdm-database-grid kgdm-database-grid-manager">';
            foreach ($active_databases as $db) {
                $summary = $database_summaries[$db['id']] ?? array('folders'=>0,'records'=>0);
                $folder_count = (int)$summary['folders'];
                $count = (int)$summary['records'];
                $is_active = get_option(self::ACTIVE_DB_OPTION) === $db['id'];
                $db_visual = self::sanitize_visual_settings($db['visual'] ?? array(), true);
                $db_bg_url = !empty($db_visual['background_attachment_id']) ? wp_get_attachment_image_url((int)$db_visual['background_attachment_id'], 'large') : false;
                $db_card_style = '--kgdm-card-bg:'.esc_attr($db_visual['background_color']).';--kgdm-card-accent:'.esc_attr($db_visual['accent_color']).';';
                if ($db_bg_url) { $db_card_style .= '--kgdm-card-image:url("'.esc_url($db_bg_url).'");'; }
                echo '<article class="kgdm-ui-card kgdm-database-card kgdm-database-tile kgdm-clickable-card" style="'.esc_attr($db_card_style).'" data-open-url="'.esc_url(self::tab_url('collections',array('db'=>$db['id']))).'" tabindex="0" role="link" aria-label="Open '.esc_attr($db['name']).' database"'.($is_active?' data-active="1"':'').'>';
                echo '<div class="kgdm-database-tile-heading"><span class="kgdm-database-icon" style="--kgdm-card-bg:'.esc_attr($db['visual']['background_color'] ?? '#f5f8ff').';--kgdm-card-accent:'.esc_attr($db['visual']['accent_color'] ?? '#2271b1').'">'.self::visual_icon_html($db['visual'] ?? array(), true).'</span><div><h3>'.esc_html($db['name']).'</h3><span class="kgdm-type">'.esc_html(self::database_type_label($db['kind'])).'</span></div>'.($is_active?'<span class="kgdm-status kgdm-status-active">Active</span>':'').'</div>';
                echo '<p>'.esc_html($db['description'] !== '' ? $db['description'] : 'No description added.').'</p><div class="kgdm-card-meta"><span><span class="dashicons dashicons-open-folder" aria-hidden="true"></span> '.(int)$folder_count.' folders</span><span><span class="dashicons dashicons-media-document" aria-hidden="true"></span> '.(int)$count.' records</span></div>';
                echo '<div class="kgdm-card-actions"><a class="button kgdm-card-action" href="'.esc_url(self::database_settings_url($db['id'])).'"><span class="dashicons dashicons-admin-settings" aria-hidden="true"></span> Settings</a></div></article>';
            }
            echo '</div>';
        }
        // Archived databases are managed only in the shared Trash workspace.
        echo '</section>';
        if ($database) {
            echo '<div class="kgdm-modal kgdm-database-settings-modal" id="kgdm-database-settings-modal" data-auto-open="'.(self::admin_query_param('edit_database') === '1' ? '1' : '0').'" aria-hidden="true"><div class="kgdm-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="kgdm-database-settings-title"><button type="button" class="kgdm-modal-close" aria-label="Close"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></button><section class="kgdm-panel kgdm-database-settings"><div class="kgdm-section-head"><div><h2 id="kgdm-database-settings-title">Database settings</h2><p>Change the selected database name, description and availability.</p></div><code>'.esc_html($database['id']).'</code></div><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="kgdm_update_database"><input type="hidden" name="database_id" value="'.esc_attr($selected_db).'">'; wp_nonce_field('kgdm_update_database');
            echo '<table class="form-table" role="presentation"><tbody><tr><th scope="row"><label for="kgdm-database-name">Name</label></th><td><input class="regular-text" id="kgdm-database-name" type="text" name="database_name" value="'.esc_attr($database['name']).'" required></td></tr><tr><th scope="row">Type</th><td><span class="kgdm-type">'.esc_html(self::database_type_label($database['kind'])).'</span><p class="description">The database type is set when this workspace is created.</p></td></tr><tr><th scope="row"><label for="kgdm-database-description">Description</label></th><td><textarea class="large-text" id="kgdm-database-description" name="database_description" rows="3">'.esc_textarea($database['description']).'</textarea></td></tr></tbody></table>'; self::render_visual_settings_fields('database_visual_edit', $database['visual'] ?? self::default_visual_settings(true), true, true); echo '<p><button class="button button-primary"><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span> Save settings</button></p></form><div class="kgdm-danger-zone">';
            if ($database['status'] === 'archived') {
                echo '<a class="button" href="'.esc_url(self::tab_url('trash',array('trash_type'=>'databases','db'=>$selected_db))).'"><span class="dashicons dashicons-trash" aria-hidden="true"></span> Manage in Trash</a>';
            } else {
                echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" onsubmit="return confirm(\'Move this database to Trash? Its folders, records and history will be retained.\')"><input type="hidden" name="action" value="kgdm_archive_database"><input type="hidden" name="database_id" value="'.esc_attr($selected_db).'">'; wp_nonce_field('kgdm_archive_database'); echo '<button class="button button-link-delete"><span class="dashicons dashicons-archive" aria-hidden="true"></span> Move to Trash</button></form>';
            }
            echo '</div></section></div></div>';
        }
    }

    /** Load and validate the bundled Faction / Organization form preset. */
    private static function faction_form_preset() {
        static $preset = null;
        if ($preset !== null) { return $preset; }
        $path = __DIR__ . '/templates/faction-form-preset.json';
        if (!is_readable($path)) { $preset = array(); return $preset; }
        $raw = file_get_contents($path);
        $decoded = is_string($raw) ? json_decode($raw, true, 64) : null;
        if (!is_array($decoded) || (string)($decoded['format'] ?? '') !== 'kgdm-collection-form-preset' || (int)($decoded['format_version'] ?? 0) !== 1) {
            $preset = array();
            return $preset;
        }
        $schema = self::sanitize_field_schema($decoded['schema'] ?? array());
        $templates = self::sanitize_form_templates($decoded['form_templates'] ?? array());
        if (is_wp_error($schema) || is_wp_error($templates) || empty($schema) || empty($templates)) {
            $preset = array();
            return $preset;
        }
        $template_check = self::validate_templates_against_schema($templates, $schema);
        if (is_wp_error($template_check)) {
            $preset = array();
            return $preset;
        }
        $preset = array(
            'name' => sanitize_text_field((string)($decoded['name'] ?? 'Factions / Organizations')),
            'slug' => sanitize_title((string)($decoded['slug'] ?? 'factions')),
            'singular_name' => sanitize_text_field((string)($decoded['singular_name'] ?? 'Faction')),
            'description' => sanitize_textarea_field((string)($decoded['description'] ?? '')),
            'schema' => $schema,
            'form_templates' => $templates,
        );
        return $preset;
    }

    private static function render_field_builder($schema, $faction_preset = array()) {
        if (!empty($faction_preset)) {
            echo '<div class="kgdm-faction-preset-card"><div class="kgdm-faction-preset-copy"><span class="dashicons dashicons-groups" aria-hidden="true"></span><div><strong>Faction / Organization form preset</strong><p>Load a structured form for leadership, members, ranks, objectives, history, relationships, quests, media and source verification. It replaces only the current unsaved builder fields and templates; existing records are not changed until you review and apply the template update.</p></div></div><button type="button" class="button" id="kgdm-load-faction-form-preset"><span class="dashicons dashicons-download" aria-hidden="true"></span> Load Faction form</button></div>';
            $preset_json = wp_json_encode($faction_preset, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
            if (is_string($preset_json)) { echo '<script type="application/json" id="kgdm-faction-form-preset-data">'.$preset_json.'</script>'; }
        }
        echo '<div class="kgdm-builder-toolbar"><p>Build the form once. Fields can be grouped into sections, nested inside objects, or repeated as lists. Values from removed fields remain stored in existing records.</p><button type="button" class="button" id="kgdm-add-field"><span class="dashicons dashicons-plus-alt2"></span> Add field</button></div>';
        echo '<div class="kgdm-builder-status" id="kgdm-builder-status" aria-live="polite"><span><strong>0</strong> fields</span><span><strong>0</strong> templates</span><span>Checking…</span></div>';
        echo '<div class="kgdm-field-builder" id="kgdm-field-builder">';
        foreach ((array)$schema as $index => $field) {
            $key = (string)($field['key'] ?? ''); if ($key === '' || $key === 'id') { continue; }
            $type = (string)($field['type'] ?? 'text');
            $options = implode(', ', (array)($field['options'] ?? array()));
            $children = wp_json_encode($field['children'] ?? array(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $default = array_key_exists('default', $field) ? wp_json_encode($field['default'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : '""';
            echo '<article class="kgdm-field-row" data-field-row draggable="true"><div class="kgdm-field-main"><span class="dashicons dashicons-menu kgdm-drag-handle" aria-hidden="true"></span><label>Field key<input class="kgdm-f-key" type="text" value="'.esc_attr($key).'" placeholder="field_key" required></label><label>Display label<input class="kgdm-f-label" type="text" value="'.esc_attr($field['label'] ?? $key).'" placeholder="Character Name"></label><label>Field type<select class="kgdm-f-type">';
            $types = array('text'=>'Text','textarea'=>'Long text','number'=>'Number','boolean'=>'Toggle','url'=>'URL','email'=>'Email','date'=>'Date','datetime'=>'Date and time','select'=>'Select','multiselect'=>'Multi-select','json'=>'JSON','image'=>'Image','gallery'=>'Image gallery','color'=>'Color','group'=>'Object / field group','repeater'=>'Repeater / list');
            foreach ($types as $value=>$label) { echo '<option value="'.esc_attr($value).'" '.selected($type,$value,false).'>'.esc_html($label).'</option>'; }
            echo '</select></label><label class="kgdm-f-required"><input type="checkbox" '.checked(!empty($field['required']),true,false).'> Required</label></div>';
            echo '<details class="kgdm-field-advanced"><summary>Field settings</summary><div class="kgdm-form-grid"><label>Section<input class="kgdm-f-section" type="text" value="'.esc_attr($field['section'] ?? 'General').'" placeholder="Identity"></label><label>Width<select class="kgdm-f-width">';
            foreach (array(25=>'25%',33=>'33%',50=>'50%',66=>'66%',75=>'75%',100=>'Full width') as $width=>$label) { echo '<option value="'.esc_attr((string)(int)$width).'" '.selected((int)($field['width'] ?? 100),$width,false).'>'.esc_html($label).'</option>'; }
            echo '</select></label><label>Placeholder<input class="kgdm-f-placeholder" type="text" value="'.esc_attr($field['placeholder'] ?? '').'"></label><label>Help text<input class="kgdm-f-help" type="text" value="'.esc_attr($field['help'] ?? '').'"></label><div class="kgdm-f-condition-wrap"><label>Show when field key<input class="kgdm-f-condition-field" type="text" value="'.esc_attr($field['show_if']['field'] ?? '').'" placeholder="has_signature"></label><label>Condition<select class="kgdm-f-condition-operator">';
            $condition_operators = array('equals'=>'Equals','not_equals'=>'Does not equal','contains'=>'Contains','not_contains'=>'Does not contain','is_checked'=>'Is checked','is_not_empty'=>'Is not empty','is_empty'=>'Is empty');
            foreach ($condition_operators as $operator=>$operator_label) { echo '<option value="'.esc_attr($operator).'" '.selected($field['show_if']['operator'] ?? 'equals',$operator,false).'>'.esc_html($operator_label).'</option>'; }
            echo '</select></label><label>Value<input class="kgdm-f-condition-value" type="text" value="'.esc_attr($field['show_if']['value'] ?? '').'" placeholder="true"></label></div><label class="kgdm-f-options-wrap">Options <small>(comma separated; for select fields)</small><input class="kgdm-f-options" type="text" value="'.esc_attr($options).'" placeholder="Anemo, Geo, Electro"></label><label class="kgdm-f-default-wrap">Default value <small>(valid JSON value)</small><textarea class="kgdm-f-default" rows="2">'.esc_textarea($default).'</textarea></label><label class="kgdm-f-children-wrap">Nested child fields <small>(JSON field definitions for Object / Repeater)</small><textarea class="kgdm-f-children" rows="5">'.esc_textarea($children ?: '[]').'</textarea></label><div class="kgdm-f-number-range"><label>Minimum<input class="kgdm-f-min" type="number" step="any" value="'.esc_attr($field['min'] ?? '').'"></label><label>Maximum<input class="kgdm-f-max" type="number" step="any" value="'.esc_attr($field['max'] ?? '').'"></label><label>Maximum repeater entries<input class="kgdm-f-max-items" type="number" min="1" max="500" value="'.esc_attr($field['max_items'] ?? 100).'"></label></div></div></details><div class="kgdm-field-actions"><button type="button" class="button kgdm-move-field-up" aria-label="Move field up">↑</button><button type="button" class="button kgdm-move-field-down" aria-label="Move field down">↓</button><button type="button" class="button-link-delete kgdm-remove-field">Remove field</button></div></article>';
        }
        echo '</div><input type="hidden" id="kgdm-collection-schema" name="collection_schema" value="'.esc_attr(wp_json_encode($schema)).'">';
        echo '<details class="kgdm-schema-raw"><summary>Advanced: edit the complete JSON schema</summary><p class="description">Use this for complex forms or bulk field definitions. Apply the JSON to load it into the visual builder before saving. The server validates the schema again.</p><textarea id="kgdm-schema-json-editor" class="large-text code" rows="14">'.esc_textarea(wp_json_encode($schema, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)).'</textarea><p><button type="button" class="button" id="kgdm-apply-schema-json">Apply JSON to visual builder</button> <span id="kgdm-schema-json-message" role="status"></span></p></details>';
    }

    private static function render_form_template_builder($templates, $schema = array()) {
        $field_labels = array(); foreach ((array)$schema as $field) { if (!empty($field['key'])) { $field_labels[$field['key']] = $field['label'] ?? $field['key']; } }
        echo '<div class="kgdm-builder-toolbar"><p>Each category can use a different view of the same collection schema. Keep shared fields in all templates, or choose exactly which fields are visible and required for each entry type.</p><button type="button" class="button" id="kgdm-add-template"><span class="dashicons dashicons-plus-alt2"></span> Add category template</button></div>';
        echo '<div class="kgdm-template-builder" id="kgdm-template-builder">';
        foreach ((array)$templates as $template) {
            $template_defaults = $template['defaults'] ?? array();
            if (is_array($template_defaults) && empty($template_defaults)) { $template_defaults = (object)array(); }
            $defaults = wp_json_encode($template_defaults, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            echo '<article class="kgdm-template-row"><div class="kgdm-template-main"><label>Template name<input class="kgdm-tpl-name" type="text" value="'.esc_attr($template['name'] ?? '').'" placeholder="Playable character"></label><label>Category ID<input class="kgdm-tpl-category" type="text" value="'.esc_attr($template['category'] ?? '').'" placeholder="playable-character"></label><label>Description<input class="kgdm-tpl-description" type="text" value="'.esc_attr($template['description'] ?? '').'" placeholder="Fields used for playable character records"></label></div><div class="kgdm-form-grid"><label>Visible fields <small>(comma separated keys; blank = all)</small><input class="kgdm-tpl-visible" type="text" value="'.esc_attr(implode(', ', (array)($template['visible_fields'] ?? array()))).'" placeholder="name, element, weapon"></label><label>Required fields <small>(additional required fields for this category)</small><input class="kgdm-tpl-required" type="text" value="'.esc_attr(implode(', ', (array)($template['required_fields'] ?? array()))).'" placeholder="name, rarity"></label></div><label>Default values (JSON object)<textarea class="kgdm-tpl-defaults" rows="4">'.esc_textarea($defaults ?: '{}').'</textarea></label><div class="kgdm-field-actions"><button type="button" class="button kgdm-duplicate-template">Duplicate</button><button type="button" class="button-link-delete kgdm-remove-template">Remove template</button></div></article>';
        }
        echo '</div><input type="hidden" id="kgdm-collection-templates" name="collection_templates" value="'.esc_attr(wp_json_encode($templates)).'">';
    }

    private static function render_collection_tree_nodes($collections_by_parent, $parent_id, $selected_db, $selected_slug, $depth = 0, &$visited = array(), $editing_slug = '', $record_counts = null) {
        if ($depth > 20) { return; }
        foreach ((array)($collections_by_parent[(string)$parent_id] ?? array()) as $collection) {
            if (isset($visited[$collection['id']])) { continue; }
            $visited[$collection['id']] = true;
            $selected = $collection['slug'] === $selected_slug;
            $editing = $collection['slug'] === $editing_slug;
            $url = self::tab_url('collections', array('db'=>$selected_db,'folder'=>$collection['slug']));
            $record_count = is_array($record_counts) ? (int)($record_counts[(string)$collection['id']] ?? 0) : self::count_admin_records($selected_db,$collection['slug'],false);
            $archived = ($collection['status'] ?? 'active') === 'archived';
            $tree_visual = self::sanitize_visual_settings($collection['visual'] ?? array(), false);
            $tree_style = ' style="--kgdm-folder-accent:'.esc_attr($tree_visual['accent_color']).';--kgdm-folder-bg:'.esc_attr($tree_visual['background_color']).'"';
            $tree_icon = $archived ? '<span class="dashicons dashicons-trash" aria-hidden="true"></span>' : self::visual_icon_html($tree_visual, false);
            echo '<li class="kgdm-tree-item'.($archived?' is-archived':'').'" data-depth="'.(int)$depth.'"><div class="kgdm-tree-row'.(($selected || $editing)?' is-selected':'').'"><a class="kgdm-tree-link '.($selected?'is-selected':'').($editing?' is-editing':'').'" href="'.esc_url($url).'" aria-label="Open folder '.esc_attr($collection['name']).'"'.$tree_style.($selected?' aria-current="page"':'').'>'.$tree_icon.'<span class="kgdm-tree-text"><strong>'.esc_html($collection['name']).'</strong><small>'.esc_html($collection['slug']).($archived?' · In Trash':'').'</small></span><span class="kgdm-tree-meta">'.(int)$record_count.' records</span><span class="kgdm-tree-open" aria-hidden="true"><span class="dashicons dashicons-arrow-right-alt2"></span></span></a>';
            echo '</div>';
            if (!empty($collections_by_parent[(string)$collection['id']])) { echo '<ul class="kgdm-folder-tree">'; self::render_collection_tree_nodes($collections_by_parent, $collection['id'], $selected_db, $selected_slug, $depth + 1, $visited, $editing_slug, $record_counts); echo '</ul>'; }
            echo '</li>';
        }
    }

    private static function render_collection_trash_button($database_id, $collection_slug) {
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" onsubmit="return confirm(\'Move this folder to Trash? Its records and history will be retained.\')"><input type="hidden" name="action" value="kgdm_archive_collection"><input type="hidden" name="database_id" value="'.esc_attr($database_id).'"><input type="hidden" name="collection_slug" value="'.esc_attr($collection_slug).'">';
        wp_nonce_field('kgdm_archive_collection');
        echo '<button type="submit" class="button button-link-delete"><span class="dashicons dashicons-trash" aria-hidden="true"></span> Move to Trash</button></form>';
    }

    private static function render_collection_history($database_id, $collection) {
        $revisions = self::get_template_revisions($database_id, $collection['slug'], 20);
        echo '<section class="kgdm-panel kgdm-history-panel"><div class="kgdm-section-head"><div><h3>Template revision history</h3><p>Current template version: <strong>'.(int)($collection['template_version'] ?? 1).'</strong>. Earlier revisions can be restored as a new version.</p></div></div>';
        if (empty($revisions)) { echo '<p>No saved revisions yet. Save this collection to create the first revision.</p></section>'; return; }
        echo '<div class="kgdm-table-wrap"><table class="widefat striped"><thead><tr><th>Version</th><th>Change summary</th><th>Saved</th><th>Action</th></tr></thead><tbody>';
        foreach ($revisions as $revision) {
            $summary = $revision['change_summary_data'];
            $bits = array();
            if (!empty($summary['added_fields'])) { $bits[] = 'Added: '.implode(', ', $summary['added_fields']); }
            if (!empty($summary['removed_fields_retained'])) { $bits[] = 'Removed from form, retained in data: '.implode(', ', $summary['removed_fields_retained']); }
            if (!empty($summary['changed_fields'])) { $bits[] = 'Changed: '.implode(', ', $summary['changed_fields']); }
            if (!empty($summary['templates_changed'])) { $bits[] = 'Category templates updated'; }
            if (isset($summary['records_backfilled_with_defaults'])) { $bits[] = 'Defaults applied to '.(int)$summary['records_backfilled_with_defaults'].' existing records'; }
            if (!empty($summary['migration_counts']['values_copied'])) { $bits[] = 'Copied '.(int)$summary['migration_counts']['values_copied'].' legacy field values'; }
            if (!empty($summary['restored_from_version'])) { $bits[] = 'Restored from V'.(int)$summary['restored_from_version']; }
            if (empty($bits)) { $bits[] = 'Initial template saved'; }
            echo '<tr><td><strong>V'.(int)$revision['version'].'</strong>'.((int)$revision['version']===(int)($collection['template_version']??1)?' <span class="kgdm-status kgdm-status-active">Current</span>':'').'</td><td>'.esc_html(implode(' · ', $bits)).'</td><td>'.esc_html($revision['created_at']).'</td><td>';
            if ((int)$revision['version'] !== (int)($collection['template_version'] ?? 1)) {
                echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" onsubmit="return confirm(&quot;Restore this form revision? It will create a new version and will not delete record values.&quot;)"><input type="hidden" name="action" value="kgdm_restore_template_revision"><input type="hidden" name="database_id" value="'.esc_attr($database_id).'"><input type="hidden" name="collection_slug" value="'.esc_attr($collection['slug']).'"><input type="hidden" name="revision_id" value="'.(int)$revision['revision_id'].'">'; wp_nonce_field('kgdm_restore_template_revision'); echo '<button class="button">Restore revision</button></form>';
            } else { echo '<span class="kgdm-muted">—</span>'; }
            echo '</td></tr>';
        }
        echo '</tbody></table></div><p class="description">Template revisions preserve the form definition. Record-value snapshots are maintained separately for each applied data migration.</p>';
        $migrations = self::get_collection_migrations($database_id, $collection['slug'], 20);
        echo '<h3>Data migration history</h3>';
        if (empty($migrations)) {
            echo '<p>No data migrations have been applied to this collection.</p>';
        } else {
            echo '<div class="kgdm-table-wrap"><table class="widefat striped"><thead><tr><th>Migration</th><th>Managed records</th><th>Data changes</th><th>Date</th><th>Status</th><th>Recovery</th></tr></thead><tbody>';
            foreach ($migrations as $migration) {
                $counts = (array)($migration['summary']['counts'] ?? array());
                $description = (int)($counts['defaults_added'] ?? 0).' defaults · '.(int)($counts['values_copied'] ?? 0).' copied · '.(int)($counts['version_tags_advanced'] ?? 0).' version tags';
                if (!empty($counts['incompatible_mappings'])) { $description .= ' · '.(int)$counts['incompatible_mappings'].' skipped'; }
                if (!empty($counts['stale_version_records'])) { $description .= ' · '.(int)$counts['stale_version_records'].' older-version records'; }
                if (!empty($counts['unversioned_records'])) { $description .= ' · '.(int)$counts['unversioned_records'].' unversioned'; }
                echo '<tr><td><strong>V'.(int)$migration['from_version'].' → V'.(int)$migration['to_version'].'</strong><br><code>'.esc_html(substr((string)$migration['migration_id'],0,8)).'</code></td><td>'.(int)$migration['changed_count'].' / '.(int)$migration['record_count'].'</td><td>'.esc_html($description).'</td><td>'.esc_html($migration['created_at']).'</td><td>'.esc_html(ucwords(str_replace('_',' ',(string)$migration['status']))).((int)$migration['conflict_count']>0?'<br><small>'.(int)$migration['conflict_count'].' rollback conflicts</small>':'').'</td><td>';
                if ((string)$migration['status'] === 'completed') {
                    echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" onsubmit="return confirm(&quot;Restore only records that have not been edited since this migration?&quot;)"><input type="hidden" name="action" value="kgdm_rollback_migration"><input type="hidden" name="database_id" value="'.esc_attr($database_id).'"><input type="hidden" name="collection_slug" value="'.esc_attr($collection['slug']).'"><input type="hidden" name="migration_id" value="'.esc_attr($migration['migration_id']).'">'; wp_nonce_field('kgdm_rollback_migration'); echo '<button class="button">Rollback data</button></form>';
                } else { echo '<span class="kgdm-muted">—</span>'; }
                echo '</td></tr>';
            }
            echo '</tbody></table></div>';
        }
        echo '</section>'; 
    }

    private static function render_tab_collections($database, $selected_db) {
        if (!$database) { echo '<section class="kgdm-panel"><h2>No database selected</h2><p>Create a database first in the Databases section.</p><a class="button button-primary" href="'.esc_url(self::tab_url('databases')).'"><span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span> Create database</a></section>'; return; }
        $collections = self::get_collections($selected_db, false);
        $folder_slug = sanitize_title(self::admin_query_param('folder'));
        $edit_slug = sanitize_title(self::admin_query_param('edit', self::admin_query_param('collection')));
        $editing = $edit_slug !== '' ? self::get_collection($selected_db,$edit_slug,false) : null;
        $current_folder = $folder_slug !== '' ? self::get_collection($selected_db,$folder_slug,false) : null;
        if (!$current_folder) { $folder_slug = ''; }
        $active_collections = array_values(array_filter($collections,function($c){ return ($c['status'] ?? 'active') === 'active'; }));
        $record_counts = self::collection_record_counts($selected_db, false);
        $collections_by_parent = array();
        $child_counts = array();
        foreach ($collections as $candidate) {
            $candidate_parent = (string)($candidate['parent_id'] ?? '');
            if (!isset($collections_by_parent[$candidate_parent])) { $collections_by_parent[$candidate_parent] = array(); }
            $collections_by_parent[$candidate_parent][] = $candidate;
            if ($candidate_parent !== '') { $child_counts[$candidate_parent] = (int)($child_counts[$candidate_parent] ?? 0) + 1; }
        }
        $schema = $editing ? $editing['schema'] : array();
        $templates = $editing ? ($editing['form_templates'] ?? array()) : array();
        $mode = $editing ? ($editing['collection_mode'] ?? 'form') : 'form';
        $preview_token = sanitize_text_field(self::admin_query_param('preview'));
        $parent_selection_slug = $editing ? self::collection_parent_slug($editing) : sanitize_title(self::admin_query_param('parent', $current_folder['slug'] ?? ''));
        $show_editor = (bool)$editing || !empty(self::admin_query_param('create')) || $preview_token !== '';
        $new_folder_parent = ($current_folder && ($current_folder['status'] ?? 'active') === 'active') ? $folder_slug : '';
        $new_folder_url = self::tab_url('collections',array('db'=>$selected_db,'create'=>1,'parent'=>$new_folder_parent));
        $current_folder_active = $current_folder && ($current_folder['status'] ?? 'active') === 'active';

        echo '<div class="kgdm-action-bar kgdm-folder-actions">';
        self::render_workspace_trash_link('folders',$selected_db);
        echo '<a class="button" href="'.esc_url(self::database_settings_url($selected_db)).'"><span class="dashicons dashicons-admin-settings" aria-hidden="true"></span> Database settings</a></div>';
        echo '<div class="kgdm-folder-layout"><aside class="kgdm-panel kgdm-folder-panel"><div class="kgdm-folder-panel-head"><div class="kgdm-folder-panel-title"><span class="dashicons dashicons-database" aria-hidden="true"></span><div><strong>'.esc_html($database['name']).'</strong><small>Database folders</small></div></div><span class="kgdm-status">'.count($active_collections).' active</span></div><a class="kgdm-tree-root '.($folder_slug==='' && !$show_editor?'is-selected':'').'" href="'.esc_url(self::tab_url('collections',array('db'=>$selected_db))).'"><span class="dashicons dashicons-category" aria-hidden="true"></span> All folders</a>';
        if (empty($collections)) {
            echo self::empty_state_html('dashicons-open-folder', 'No active folders yet', 'Create a folder using the New folder action, or open Trash to restore a previously archived folder.', array(array('url'=>self::tab_url('trash',array('db'=>$selected_db,'trash_type'=>'folders')),'label'=>'Open Trash','icon'=>'dashicons-trash')), 'kgdm-folder-empty kgdm-folder-empty-compact');
        } else {
            echo '<ul class="kgdm-folder-tree kgdm-folder-root">'; $visited=array(); self::render_collection_tree_nodes($collections_by_parent, '', $selected_db, $folder_slug, 0, $visited, $edit_slug, $record_counts); echo '</ul>';
        }
        echo '</aside><div class="kgdm-collection-workspace">';

        if ($preview_token !== '') {
            self::render_collection_migration_preview($selected_db, $edit_slug, $preview_token);
            echo '</div></div>';
            return;
        }

        if ($show_editor) {
            echo '<div class="kgdm-modal kgdm-folder-editor-modal" id="kgdm-folder-editor-modal" aria-hidden="true"><div class="kgdm-modal-dialog kgdm-modal-dialog-large" role="dialog" aria-modal="true" aria-labelledby="kgdm-folder-editor-title"><button type="button" class="kgdm-modal-close" aria-label="Close"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></button>';
            $editor_title = $editing ? 'Edit folder' : 'Create folder';
            $editor_description = $editing ? 'Update this folder, its record schema and its location in the database.' : 'Create a folder for a record type. You can add fields now or choose list-only mode for flexible JSON records.';
            $cancel_args = array('db'=>$selected_db);
            if ($editing && $parent_selection_slug !== '') { $cancel_args['folder'] = $parent_selection_slug; }
            elseif (!$editing && $parent_selection_slug !== '') { $cancel_args['folder'] = $parent_selection_slug; }
            $cancel_url = self::tab_url('collections',$cancel_args);
            echo '<section class="kgdm-panel kgdm-folder-editor"><div class="kgdm-editor-title"><span class="dashicons '.($editing?'dashicons-edit':'dashicons-open-folder'). '" aria-hidden="true"></span><div><h2 id="kgdm-folder-editor-title">'.esc_html($editor_title).'</h2><p>'.esc_html($editor_description).'</p></div></div><form id="kgdm-collection-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="kgdm_preview_collection"><input type="hidden" name="database_id" value="'.esc_attr($selected_db).'"><input type="hidden" name="collection_existing_slug" value="'.esc_attr($editing['slug'] ?? '').'">'; wp_nonce_field('kgdm_save_collection');
            echo '<div class="kgdm-form-grid"><label>Folder name<input type="text" name="collection_name" value="'.esc_attr($editing['name'] ?? '').'" placeholder="Characters" required></label><label>Folder ID <span class="kgdm-muted">(optional for new folders)</span><input type="text" name="collection_slug" id="kgdm-collection-slug" value="'.esc_attr($editing['slug'] ?? '').'" placeholder="Auto from folder name"'.($editing?' readonly':'').'><small>Leave blank to generate an ID from the folder name. Keep it stable after creating records. Preview: <code id="kgdm-collection-id-preview">'.esc_html($editing['slug'] ?? 'your-folder-name').'</code></small></label><label>Singular record label<input type="text" name="collection_singular" value="'.esc_attr($editing['singular_name'] ?? '').'" placeholder="Character"></label><label>Parent folder<select name="collection_parent"><option value="">Root level</option>';
            $parent_options = array_values(array_filter($collections, function($candidate) use ($editing) {
                if (($candidate['status'] ?? 'active') === 'active') { return true; }
                return $editing && (string)($editing['parent_id'] ?? '') !== '' && (string)$candidate['id'] === (string)$editing['parent_id'];
            }));
            foreach ($parent_options as $parent) {
                if ($editing && $parent['id'] === $editing['id']) { continue; }
                $depth = 0; $cursor = $parent; $seen_ancestors=array();
                while (!empty($cursor['parent_id']) && $depth < 20 && !isset($seen_ancestors[$cursor['id']])) { $seen_ancestors[$cursor['id']]=true; $cursor=self::get_collection_by_id($selected_db,$cursor['parent_id'],true); if ($cursor) { $depth++; } else { break; } }
                $prefix = str_repeat('— ', $depth);
                $parent_label = $prefix.$parent['name'].((($parent['status'] ?? 'active') === 'archived') ? ' (In Trash · existing parent)' : '');
                echo '<option value="'.esc_attr($parent['slug']).'" '.selected($parent_selection_slug,$parent['slug'],false).'>'.esc_html($parent_label).'</option>';
            }
            echo '</select></label><label>Collection mode<select name="collection_mode" id="kgdm-collection-mode"><option value="form" '.selected($mode,'form',false).'>Custom form</option><option value="list" '.selected($mode,'list',false).'>List only — flexible JSON</option></select></label></div><label>Description<textarea name="collection_description" rows="2">'.esc_textarea($editing['description'] ?? '').'</textarea></label>'; self::render_visual_settings_fields('collection_visual', $editing['visual'] ?? self::default_visual_settings(false), false, false); echo '<section class="kgdm-section-terms-editor"><h3>Record sections</h3><p>Create WordPress-style sections for organizing records. Enter one section path per line; use <code>Parent &gt; Child</code> for nested sections.</p><textarea name="collection_sections" rows="5" class="large-text code" placeholder="Characters&#10;Characters &gt; Archons&#10;Characters &gt; Mondstadt">'.esc_textarea(self::collection_sections_text($editing['sections'] ?? array())).'</textarea><p class="description">Records can belong to multiple sections. Changing sections does not alter the record form schema.</p></section>';
            echo '<div class="kgdm-form-only"><div class="kgdm-builder-section"><div class="kgdm-section-head"><div><h3>Form field builder</h3><p>Define every property this folder can store. Organise fields into sections and choose their types, layout and defaults.</p></div></div>';
            self::render_field_builder($schema, self::faction_form_preset());
            echo '</div><div class="kgdm-template-section"><div class="kgdm-section-head"><div><h3>Category form templates</h3><p>For example: Playable Character, NPC, Boss or Weapon. Each template can show a different subset of fields.</p></div></div>';
            self::render_form_template_builder($templates, $schema);
            echo '</div></div><p id="kgdm-form-builder-error" class="kgdm-form-builder-error" role="alert" aria-live="polite"></p><div class="kgdm-migration-safety"><span class="dashicons dashicons-shield" aria-hidden="true"></span><div><strong>Existing data is protected</strong><p>New defaults are only applied when a record is missing that field. Removed fields stay in the record JSON and remain available in Legacy / Additional Data. Every saved form change creates a revision.</p></div></div><p class="kgdm-form-actions"><button class="button button-primary"><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span> Review changes</button> <a class="button" href="'.esc_url($cancel_url).'">Cancel</a></p></form></section>';
            if ($editing) {
                echo '<section class="kgdm-panel kgdm-folder-status-panel"><div class="kgdm-section-head"><div><h3>Folder status</h3><p>Moving a folder to Trash hides it from active record workflows. Its records remain stored until permanent deletion.</p></div><span class="kgdm-status '.(($editing['status'] ?? 'active')==='active'?'kgdm-status-active':'kgdm-status-archived').'">'.esc_html(($editing['status'] ?? 'active') === 'archived' ? 'In Trash' : 'Active').'</span></div>';
                self::render_collection_trash_button($selected_db, $editing['slug']);
                echo '</section>';
                self::render_collection_history($selected_db, $editing);
            }
            echo '</div></div>';
        }
        {
            $folder_path = $current_folder ? self::collection_breadcrumb($current_folder,$selected_db) : array();
            echo '<section class="kgdm-folder-browser"><nav class="kgdm-folder-breadcrumb" aria-label="Folder path"><a href="'.esc_url(self::tab_url('collections',array('db'=>$selected_db))).'"><span class="dashicons dashicons-database" aria-hidden="true"></span> '.esc_html($database['name']).'</a>';
            foreach ($folder_path as $index=>$part) {
                echo '<span class="kgdm-breadcrumb-separator" aria-hidden="true">/</span>'.($index === count($folder_path)-1 ? '<strong>'.esc_html($part['name']).'</strong>' : '<a href="'.esc_url(self::tab_url('collections',array('db'=>$selected_db,'folder'=>$part['slug']))).'">'.esc_html($part['name']).'</a>');
            }
            echo '</nav><div class="kgdm-folder-browser-heading"><div><h2>'.esc_html($current_folder ? $current_folder['name'] : 'All folders').'</h2><p>'.esc_html($current_folder ? ($current_folder['description'] ?: 'Browse the folders inside this location.') : 'Choose a folder to open it, or create a new folder at the root level.').'</p></div>';
            if ($current_folder) {
                $parent_slug = self::collection_parent_slug($current_folder);
                if ($parent_slug !== '') { echo '<a class="button" href="'.esc_url(self::tab_url('collections',array('db'=>$selected_db,'folder'=>$parent_slug))).'"><span class="dashicons dashicons-arrow-up-alt2" aria-hidden="true"></span> Parent folder</a>'; }
            }
            echo '</div>';
            if ($current_folder) {
                $folder_records = is_array($record_counts)
                    ? (int)($record_counts[(string)$current_folder['id']] ?? 0)
                    : self::count_admin_records($selected_db,$current_folder['slug'],false);
                echo '<article class="kgdm-ui-card kgdm-current-folder-card"><span class="kgdm-folder-card-icon"><span class="dashicons dashicons-media-document" aria-hidden="true"></span></span><div class="kgdm-current-folder-info"><strong>Records in this folder</strong><p>'.(int)$folder_records.' active records · '.esc_html($current_folder['collection_mode']==='list'?'Flexible JSON':'Template-based form').'</p></div><div class="kgdm-folder-card-actions">';
                echo '<a class="button button-primary" href="'.esc_url(self::tab_url('records',array('db'=>$selected_db,'collection'=>$current_folder['slug']))).'"><span class="dashicons dashicons-list-view" aria-hidden="true"></span> Open records</a>';
                echo '<a class="button" href="'.esc_url(self::tab_url('collections',array('db'=>$selected_db,'edit'=>$current_folder['slug']))).'"><span class="dashicons dashicons-edit" aria-hidden="true"></span> Setup folder &amp; form</a>';
                self::render_collection_trash_button($selected_db, $current_folder['slug']);
                echo '</div></article>';
            }
            $child_folders = array_values(array_filter($collections,function($c) use ($current_folder){ return (string)($c['parent_id'] ?? '') === (string)($current_folder['id'] ?? ''); }));
            echo '<div class="kgdm-section-head kgdm-child-folder-heading"><div><h3>'.($current_folder?'Subfolders':'Folders in this database').'</h3><p>'.count($child_folders).' folder'.(count($child_folders)===1?'':'s').' in this location.</p></div><a class="button button-primary" href="'.esc_url($new_folder_url).'"><span class="dashicons dashicons-open-folder" aria-hidden="true"></span> '.(($current_folder && !$current_folder_active)?'New root folder':'New folder here').'</a></div>';
            if (empty($child_folders)) {
                echo self::empty_state_html('dashicons-open-folder', $current_folder ? 'No subfolders in this folder' : 'No folders in this database', $current_folder ? 'Add a nested folder to organise related records. Use the New folder action above to continue.' : 'Create your first folder, for example Characters, Weapons or Artifacts. Use the New folder action above to continue.', array(), 'kgdm-folder-empty');
            } else {
                echo '<div class="kgdm-folder-card-grid">';
                foreach ($child_folders as $child) {
                    $record_count = is_array($record_counts)
                        ? (int)($record_counts[(string)$child['id']] ?? 0)
                        : self::count_admin_records($selected_db,$child['slug'],false);
                    $subfolder_count = (int)($child_counts[(string)$child['id']] ?? 0);
                    $child_archived = ($child['status'] ?? 'active') === 'archived';
                    $folder_visual = self::sanitize_visual_settings($child['visual'] ?? array(), false);
                    $folder_style = '--kgdm-card-bg:'.esc_attr($folder_visual['background_color']).';--kgdm-card-accent:'.esc_attr($folder_visual['accent_color']).';';
                    echo '<article class="kgdm-ui-card kgdm-folder-card'.($child_archived?' is-archived':'').'" style="'.esc_attr($folder_style).'"><a class="kgdm-folder-card-main" href="'.esc_url(self::tab_url('collections',array('db'=>$selected_db,'folder'=>$child['slug']))).'"><span class="kgdm-folder-card-icon">'.self::visual_icon_html($folder_visual, false).'</span><span class="kgdm-folder-card-copy"><strong>'.esc_html($child['name']).($child_archived?' · In Trash':'').'</strong><small>'.esc_html($child['slug']).'</small><span>'.(int)$subfolder_count.' subfolders · '.(int)$record_count.' records</span></span></a><div class="kgdm-folder-card-actions"><a class="button" href="'.esc_url(self::tab_url('collections',array('db'=>$selected_db,'edit'=>$child['slug']))).'"><span class="dashicons dashicons-edit" aria-hidden="true"></span> Edit</a>';
                    if (!$child_archived) { self::render_collection_trash_button($selected_db, $child['slug']); }
                    echo '</div></article>';
                }
                echo '</div>';
            }
            echo '</section>';
        }
        echo '</div></div>';
    }

    private static function is_empty_value_tree($value) {
        if ($value === null || $value === '' || $value === array()) { return true; }
        if (is_array($value)) {
            foreach ($value as $item) { if (!self::is_empty_value_tree($item)) { return false; } }
            return true;
        }
        return false; // false and zero are valid values.
    }

    private static function record_completeness_detail($record, $collection) {
        if (($collection['collection_mode'] ?? 'form') === 'list' || empty($collection['schema'])) {
            return array('state'=>'flexible','label'=>'Flexible JSON','missing_required'=>0,'required'=>0,'missing_recommended'=>0,'recommended'=>0,'missing_paths'=>array(),'template_id'=>'','template_name'=>'');
        }
        $template_id = (string)($record['_kgdm_template'] ?? '');
        $template = null;
        foreach ((array)($collection['form_templates'] ?? array()) as $candidate) {
            if (($candidate['category'] ?? '') === $template_id) { $template = $candidate; break; }
        }
        if (!empty($collection['form_templates']) && !$template) {
            return array('state'=>'unassigned','label'=>'No template','missing_required'=>0,'required'=>0,'missing_recommended'=>0,'recommended'=>0,'missing_paths'=>array(),'template_id'=>$template_id,'template_name'=>'');
        }
        $visible = $template && !empty($template['visible_fields']) ? (array)$template['visible_fields'] : array();
        $required_override = $template ? (array)($template['required_fields'] ?? array()) : array();
        $required = 0; $missing_required = 0; $recommended = 0; $missing_recommended = 0;
        $missing_paths = array();
        $root_record = is_array($record) ? $record : array();
        $walk = function($value, $fields, $depth = 0, $top = false, $path_prefix = '') use (&$walk, &$required, &$missing_required, &$recommended, &$missing_recommended, &$missing_paths, $visible, $required_override, $root_record) {
            if ($depth > 5) { return; }
            foreach ((array)$fields as $field) {
                $key = (string)($field['key'] ?? '');
                if ($key === '') { continue; }
                if ($top && !empty($visible) && !in_array($key, $visible, true)) { continue; }
                if (!self::field_condition_matches($root_record, is_array($value) ? $value : array(), $field['show_if'] ?? array())) { continue; }
                $path = $path_prefix === '' ? $key : $path_prefix . '.' . $key;
                $has = is_array($value) && array_key_exists($key, $value);
                $item = $has ? $value[$key] : null;
                $empty = !$has || $item === null || $item === '' || $item === array();
                if (($field['type'] ?? '') === 'group' && is_array($item)) { $empty = self::is_empty_value_tree($item); }
                $is_required = !empty($field['required']) || ($top && in_array($key, $required_override, true));
                $is_recommended = !$is_required;
                if ($is_required) { $required++; if ($empty) { $missing_required++; if (count($missing_paths) < 100) { $missing_paths[] = $path; } } }
                elseif ($is_recommended) { $recommended++; if ($empty) { $missing_recommended++; } }
                if (!$empty && ($field['type'] ?? '') === 'group' && is_array($item)) {
                    $walk($item, $field['children'] ?? array(), $depth + 1, false, $path);
                } elseif (!$empty && ($field['type'] ?? '') === 'repeater' && is_array($item)) {
                    foreach (array_values($item) as $index => $row) {
                        if (is_array($row)) { $walk($row, $field['children'] ?? array(), $depth + 1, false, $path . '[' . $index . ']'); }
                    }
                }
            }
        };
        $walk($root_record, $collection['schema'], 0, true, '');
        if ($required === 0) {
            $state = $missing_recommended > 0 ? 'partial' : 'optional';
            $label = $missing_recommended > 0 ? ($missing_recommended . ' recommended missing') : 'No required fields';
        } else {
            $state = $missing_required > 0 ? 'incomplete' : 'complete';
            $label = $missing_required > 0 ? ($missing_required . ' required missing') : 'Complete';
            if ($state === 'complete' && $missing_recommended > 0) { $state = 'partial'; $label = $missing_recommended . ' recommended missing'; }
        }
        return array(
            'state'=>$state,'label'=>$label,'missing_required'=>$missing_required,'required'=>$required,
            'missing_recommended'=>$missing_recommended,'recommended'=>$recommended,'missing_paths'=>$missing_paths,
            'template_id'=>$template_id,'template_name'=>$template ? (string)($template['name'] ?? $template_id) : ''
        );
    }

    private static function record_completeness($record, $collection) {
        $detail = self::record_completeness_detail($record, $collection);
        return array('state'=>$detail['state'],'label'=>$detail['label'],'missing'=>$detail['missing_required'],'required'=>$detail['required']);
    }

    private static function render_repeater_row($field, $row_value, $path, $root, $depth, $index, $prototype = false) {
        $row_value = is_array($row_value) ? $row_value : array();
        $index_token = $prototype ? '__INDEX_' . ($depth + 1) . '__' : (string)$index;
        $row_path = $path . '.' . $index_token;
        echo '<div class="kgdm-repeater-row" data-repeater-row data-index="'.esc_attr($index_token).'" data-original-row="'.esc_attr(wp_json_encode($row_value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)).'">';
        echo '<div class="kgdm-repeater-row-head"><strong>'.($prototype ? 'New entry' : 'Entry '.((int)$index + 1)).'</strong><button type="button" class="button-link-delete kgdm-remove-repeater-row">Remove entry</button></div>';
        echo '<div class="kgdm-repeater-row-fields">';
        foreach ((array)($field['children'] ?? array()) as $child) {
            self::render_record_field($child, $row_value[$child['key'] ?? ''] ?? null, $row_path, $root, $depth + 1);
        }
        echo '</div></div>';
    }

    private static function record_field_control_id($path) {
        $safe_path = sanitize_html_class(str_replace('.', '-', (string)$path));
        return 'kgdm-record-field-' . ($safe_path !== '' ? $safe_path : 'value');
    }

    private static function render_record_field($field, $value = null, $parent_path = '', $root_key = '', $depth = 0) {
        $key = (string)($field['key'] ?? '');
        if ($key === '' || $key === 'id' || $depth > 5) { return; }
        $path = $parent_path === '' ? $key : $parent_path . '.' . $key;
        $control_id = self::record_field_control_id($path);
        $root = $root_key === '' ? $key : $root_key;
        $label = (string)($field['label'] ?? $key);
        $type = (string)($field['type'] ?? 'text');
        if ($value === null && array_key_exists('default', $field)) { $value = $field['default']; }
        $width = (int)($field['width'] ?? 100);
        $width_class = 'kgdm-width-' . (in_array($width, array(25,33,50,66,75,100), true) ? $width : 100);
        $condition_json = !empty($field['show_if']) ? wp_json_encode($field['show_if'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : '';
        $help = trim((string)($field['help'] ?? ''));
        if ($type === 'group') {
            echo '<fieldset class="kgdm-record-group kgdm-record-field-wrap '.esc_attr($width_class).'" data-kgdm-field data-field-type="group" data-top-key="'.esc_attr($root).'" data-key-path="'.esc_attr($path).'" data-parent-path="'.esc_attr($parent_path).'" data-required="'.(!empty($field['required'])?'1':'0').'"';
            if ($condition_json !== '') { echo ' data-show-if="'.esc_attr($condition_json).'"'; }
            echo '>';
            echo '<legend>'.esc_html($label).(!empty($field['required'])?' <span aria-hidden="true">*</span>':'').'</legend>';
            if ($help !== '') { echo '<p class="description">'.esc_html($help).'</p>'; }
            echo '<div class="kgdm-record-group-grid">';
            $nested_values = is_array($value) ? $value : array();
            foreach ((array)($field['children'] ?? array()) as $child) {
                self::render_record_field($child, $nested_values[$child['key'] ?? ''] ?? null, $path, $root, $depth + 1);
            }
            echo '</div></fieldset>';
            return;
        }
        if ($type === 'image' || $type === 'gallery') {
            $ids = $type === 'gallery' ? (array)$value : ($value ? array((int)$value) : array());
            $ids = array_values(array_filter(array_map('absint', $ids)));
            $stored = $type === 'gallery' ? wp_json_encode($ids) : (string)($ids[0] ?? '');
            echo '<div class="kgdm-record-field-wrap kgdm-media-field '.esc_attr($width_class).'" data-kgdm-field data-field-type="'.esc_attr($type).'" data-top-key="'.esc_attr($root).'" data-key-path="'.esc_attr($path).'" data-parent-path="'.esc_attr($parent_path).'" data-media-type="'.esc_attr($type).'" data-required="'.(!empty($field['required'])?'1':'0').'"';
            if ($condition_json !== '') { echo ' data-show-if="'.esc_attr($condition_json).'"'; }
            echo '>';
            echo '<span class="kgdm-field-label">'.esc_html($label).(!empty($field['required'])?' <span aria-hidden="true">*</span>':'').'</span>';
            echo '<input type="hidden" id="'.esc_attr($control_id).'" class="kgdm-record-value kgdm-media-value" data-key="'.esc_attr($path).'" data-top-key="'.esc_attr($root).'" value="'.esc_attr($stored).'">';
            echo '<div class="kgdm-media-preview" aria-live="polite">';
            foreach ($ids as $attachment_id) { $thumb = self::attachment_image_html($attachment_id, 'thumbnail', 'kgdm-media-thumb', ''); if ($thumb !== '') { echo $thumb; } }
            if (empty($ids)) { echo self::image_placeholder_html('kgdm-media-placeholder', 'No image selected'); }
            $media_action_label = $type === 'gallery' ? (empty($ids) ? 'Choose images' : 'Replace images') : (empty($ids) ? 'Choose image' : 'Replace image');
            echo '</div><div class="kgdm-media-actions"><button type="button" class="button kgdm-select-media">'.esc_html($media_action_label).'</button><button type="button" class="button kgdm-remove-media"'.(empty($ids)?' disabled':'').'>Remove</button></div>';
            if ($help !== '') { echo '<small>'.esc_html($help).'</small>'; }
            echo '</div>';
            return;
        }
        if ($type === 'repeater') {
            $rows = is_array($value) ? array_values($value) : array();
            $max_items = max(1, min(500, absint($field['max_items'] ?? 100)));
            echo '<fieldset class="kgdm-record-repeater kgdm-record-field-wrap '.esc_attr($width_class).'" data-kgdm-field data-kgdm-repeater data-field-type="repeater" data-top-key="'.esc_attr($root).'" data-key-path="'.esc_attr($path).'" data-parent-path="'.esc_attr($parent_path).'" data-required="'.(!empty($field['required'])?'1':'0').'" data-max-items="'.(int)$max_items.'" data-repeater-level="'.(int)($depth + 1).'"';
            if ($condition_json !== '') { echo ' data-show-if="'.esc_attr($condition_json).'"'; }
            echo '>';
            echo '<legend>'.esc_html($label).(!empty($field['required'])?' <span aria-hidden="true">*</span>':'').'</legend>';
            if ($help !== '') { echo '<p class="description">'.esc_html($help).'</p>'; }
            echo '<div class="kgdm-repeater-items">';
            foreach ($rows as $index => $row_value) { self::render_repeater_row($field, $row_value, $path, $root, $depth, $index, false); }
            echo '</div><template class="kgdm-repeater-prototype">';
            self::render_repeater_row($field, array(), $path, $root, $depth, 0, true);
            echo '</template><div class="kgdm-repeater-actions"><button type="button" class="button kgdm-add-repeater-row"'.(count($rows) >= $max_items ? ' disabled' : '').'>Add entry</button><small>'.count($rows).' / '.(int)$max_items.' entries</small></div></fieldset>';
            return;
        }
        echo '<label class="kgdm-record-field-wrap kgdm-record-field '.esc_attr($width_class).'" data-kgdm-field data-field-type="'.esc_attr($type).'" data-top-key="'.esc_attr($root).'" data-key-path="'.esc_attr($path).'" data-parent-path="'.esc_attr($parent_path).'" data-required="'.(!empty($field['required'])?'1':'0').'"';
        if ($condition_json !== '') { echo ' data-show-if="'.esc_attr($condition_json).'"'; }
        echo '>'.esc_html($label).(!empty($field['required'])?' <span aria-hidden="true">*</span>':'');
        if ($type === 'boolean') {
            echo '<span class="kgdm-toggle"><input type="checkbox" id="'.esc_attr($control_id).'" class="kgdm-record-value" data-key="'.esc_attr($path).'" data-top-key="'.esc_attr($root).'" '.checked((bool)$value,true,false).'> Yes</span>';
        } elseif ($type === 'textarea') {
            echo '<textarea id="'.esc_attr($control_id).'" class="kgdm-record-value" data-key="'.esc_attr($path).'" data-top-key="'.esc_attr($root).'" rows="3" placeholder="'.esc_attr($field['placeholder'] ?? '').'"';
            if (!empty($field['required'])) { echo ' required'; }
            echo '>'.esc_textarea(is_scalar($value)?(string)$value:'').'</textarea>';
        } elseif ($type === 'json') {
            echo '<textarea id="'.esc_attr($control_id).'" class="kgdm-record-value kgdm-json-field" data-key="'.esc_attr($path).'" data-top-key="'.esc_attr($root).'" rows="4" placeholder="[] or {}"';
            if (!empty($field['required'])) { echo ' required'; }
            echo '>'.esc_textarea($value !== null ? wp_json_encode($value,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) : '{}').'</textarea><small>Enter valid JSON (array or object).</small>';
        } elseif ($type === 'select' || $type === 'multiselect') {
            $multiple = $type === 'multiselect';
            $selected_values = $multiple ? (array)$value : array((string)$value);
            echo '<select id="'.esc_attr($control_id).'" class="kgdm-record-value" data-key="'.esc_attr($path).'" data-top-key="'.esc_attr($root).'"';
            if ($multiple) { echo ' multiple size="4"'; }
            if (!empty($field['required'])) { echo ' required'; }
            echo '><option value="">Select</option>';
            foreach ((array)($field['options'] ?? array()) as $option) { echo '<option value="'.esc_attr($option).'" '.selected(in_array((string)$option, array_map('strval',$selected_values), true),true,false).'>'.esc_html($option).'</option>'; }
            echo '</select>';
        } else {
            $html_type = in_array($type, array('number','url','email','date','datetime-local','color'), true) ? $type : ($type === 'datetime' ? 'datetime-local' : 'text');
            $default_value = is_scalar($value) ? (string)$value : '';
            echo '<input id="'.esc_attr($control_id).'" type="'.esc_attr($html_type).'" class="kgdm-record-value" data-key="'.esc_attr($path).'" data-top-key="'.esc_attr($root).'" value="'.esc_attr($default_value).'" placeholder="'.esc_attr($field['placeholder'] ?? '').'"';
            if (!empty($field['required'])) { echo ' required'; }
            if ($type === 'number') {
                echo ' step="any"';
                if (isset($field['min'])) { echo ' min="'.esc_attr($field['min']).'"'; }
                if (isset($field['max'])) { echo ' max="'.esc_attr($field['max']).'"'; }
            }
            echo '>';
        }
        if ($help !== '') { echo '<small>'.esc_html($help).'</small>'; }
        echo '</label>';
    }

    private static function first_media_field($schema, $prefix = '') {
        foreach ((array)$schema as $field) {
            $key = (string)($field['key'] ?? '');
            if ($key === '') { continue; }
            $path = $prefix === '' ? $key : $prefix . '.' . $key;
            if (in_array(($field['type'] ?? ''), array('image','gallery'), true)) { return array('key'=>$path,'type'=>$field['type']); }
            if (in_array(($field['type'] ?? ''), array('group','repeater'), true)) {
                $nested = self::first_media_field($field['children'] ?? array(), $path);
                if ($nested) { return $nested; }
            }
        }
        return null;
    }

    private static function first_media_field_key($collection) {
        $field = self::first_media_field($collection['schema'] ?? array());
        return $field ? $field['key'] : '';
    }

    private static function first_media_field_type($collection) {
        $field = self::first_media_field($collection['schema'] ?? array());
        return $field ? $field['type'] : '';
    }

    private static function get_record_path($record, $path) {
        $value = $record;
        foreach (explode('.', (string)$path) as $segment) {
            if (!is_array($value) || !array_key_exists($segment, $value)) { return null; }
            $value = $value[$segment];
        }
        return $value;
    }

    private static function record_thumbnail_html($record, $collection) {
        $field = self::first_media_field($collection['schema'] ?? array());
        $value = $field ? self::get_record_path($record, $field['key']) : null;
        $attachment_id = $field && $field['type'] === 'gallery' && is_array($value) ? absint(reset($value)) : absint($value);
        if ($attachment_id) {
            $alt = (string)($record['name'] ?? $record['title'] ?? $record['label'] ?? '');
            $image = self::attachment_image_html($attachment_id, 'thumbnail', 'kgdm-record-thumb', $alt);
            if ($image !== '') { return $image; }
        }
        return self::image_placeholder_html('kgdm-record-thumb-placeholder', 'No profile image');
    }

    private static function collection_breadcrumb($collection, $database_id) {
        $parts = array(); $cursor = $collection; $guard = 0;
        while ($cursor && $guard++ < 25) {
            array_unshift($parts, $cursor);
            $parent_id = (string)($cursor['parent_id'] ?? '');
            $cursor = $parent_id !== '' ? self::get_collection_by_id($database_id, $parent_id, true) : null;
        }
        return $parts;
    }

    private static function render_tab_completeness($database, $selected_db) {
        if (!$database) { echo self::empty_state_html('dashicons-database', 'No database selected', 'Create or select a database before checking record completeness.', array(array('url'=>self::tab_url('databases'),'label'=>'Open Databases','icon'=>'dashicons-database','variant'=>'primary'))); return; }
        $collections = array_values(array_filter(self::get_collections($selected_db, false), function($c){ return ($c['status'] ?? '') === 'active' && ($c['collection_mode'] ?? 'form') === 'form' && !empty($c['schema']); }));
        $collection_slug = sanitize_title(self::admin_query_param('collection', $collections[0]['slug'] ?? ''));
        $collection = self::get_collection($selected_db, $collection_slug, false);
        echo '<section class="kgdm-panel"><div class="kgdm-section-head"><div><h2>Missing data / completeness checker</h2><p>Read-only audit of saved records against the active collection schema and category template. No record data is changed.</p></div><span class="kgdm-status kgdm-status-active">Live check</span></div>';
        if (!$collection || ($collection['collection_mode'] ?? 'form') !== 'form' || empty($collection['schema'])) {
            echo self::empty_state_html('dashicons-forms', 'A form is needed before completeness can be checked', 'Create or configure a form collection first. Flexible JSON collections can store records, but they do not have a fixed field schema for completeness audits.', array(array('url'=>self::tab_url('collections',array('db'=>$selected_db)),'label'=>'Open Folders & forms','icon'=>'dashicons-open-folder','variant'=>'primary'),array('url'=>self::tab_url('records',array('db'=>$selected_db)),'label'=>'Browse records','icon'=>'dashicons-list-view'))); echo '</section>'; return;
        }
        echo '<div class="kgdm-record-tools"><label>Collection<select class="kgdm-select" id="kgdm-completeness-collection">';
        foreach ($collections as $col) { echo '<option value="'.esc_attr($col['slug']).'" '.selected($collection_slug,$col['slug'],false).'>'.esc_html($col['name']).'</option>'; }
        echo '</select></label><div class="kgdm-record-tool-actions"><a class="button" href="'.esc_url(self::tab_url('records',array('db'=>$selected_db,'collection'=>$collection_slug))).'"><span class="dashicons dashicons-list-view" aria-hidden="true"></span> Open records</a>';
        self::render_workspace_trash_link('records',$selected_db,$collection_slug);
        echo '<a class="button button-primary" href="'.esc_url(self::tab_url('collections',array('db'=>$selected_db,'edit'=>$collection_slug))).'"><span class="dashicons dashicons-admin-generic" aria-hidden="true"></span> Edit form setup</a></div></div>';
        $records = self::get_admin_records($selected_db, $collection_slug, false);
        $stats = array('complete'=>0,'partial'=>0,'incomplete'=>0,'unassigned'=>0,'optional'=>0,'flexible'=>0);
        $required_total=0; $required_missing=0; $recommended_total=0; $recommended_missing=0;
        $rows=array();
        foreach ($records as $id=>$record) {
            $detail=self::record_completeness_detail($record,$collection); $state=$detail['state']; if(isset($stats[$state])){$stats[$state]++;}
            $required_total += $detail['required']; $required_missing += $detail['missing_required']; $recommended_total += $detail['recommended']; $recommended_missing += $detail['missing_recommended'];
            $rows[]=array('id'=>$id,'name'=>(string)($record['name']??$record['title']??$record['label']??$id),'detail'=>$detail);
        }
        $total=count($rows); $complete_pct=$total?round(($stats['complete']/$total)*100):0;
        echo '<div class="kgdm-completeness-summary">';
        echo self::summary_metric_html($total, 'Records checked');
        echo self::summary_metric_html($stats['complete'], 'Complete', 'good');
        echo self::summary_metric_html($stats['partial'], 'Partial', 'warning');
        echo self::summary_metric_html($stats['incomplete'], 'Incomplete', 'bad');
        echo self::summary_metric_html($complete_pct.'%', 'Fully complete');
        echo '</div>';
        echo '<div class="kgdm-completeness-meta"><span>Required fields: <strong>'.(int)$required_missing.'</strong> missing of '.(int)$required_total.'</span><span>Recommended fields: <strong>'.(int)$recommended_missing.'</strong> missing of '.(int)$recommended_total.'</span><span>Template version: <strong>'.(int)($collection['template_version']??1).'</strong></span></div>';
        echo '<div class="kgdm-section-head kgdm-completeness-filter-head"><div><h3>Record coverage</h3><p>Use the filter to focus on records needing attention.</p></div><label class="kgdm-search">Search<input type="search" id="kgdm-completeness-search" placeholder="Search record or missing field…"></label></div>';
        echo '<div class="kgdm-completeness-filters" role="group" aria-label="Completeness filters"><button type="button" class="button button-primary" data-completeness-filter="all">All '.(int)$total.'</button><button type="button" class="button" data-completeness-filter="incomplete">Incomplete '.(int)$stats['incomplete'].'</button><button type="button" class="button" data-completeness-filter="partial">Partial '.(int)$stats['partial'].'</button><button type="button" class="button" data-completeness-filter="complete">Complete '.(int)$stats['complete'].'</button><button type="button" class="button" data-completeness-filter="unassigned">No template '.(int)$stats['unassigned'].'</button></div>';
        echo '<div class="kgdm-table-wrap"><table class="widefat striped kgdm-completeness-table"><thead><tr><th>Record</th><th>Template</th><th>Status</th><th>Required</th><th>Recommended</th><th>Missing fields</th><th>Action</th></tr></thead><tbody id="kgdm-completeness-rows">';
        if(empty($rows)){echo '<tr><td colspan="7">No records found.</td></tr>';}
        foreach($rows as $row){$d=$row['detail'];$missing=array_slice($d['missing_paths'],0,8);$missing_text=implode(', ',$missing);if($d['missing_required']>8){$missing_text.=' …';}$search=strtolower($row['id'].' '.$row['name'].' '.$missing_text.' '.$d['template_name']);echo '<tr data-completeness-row data-state="'.esc_attr($d['state']).'" data-search="'.esc_attr($search).'" data-record-id="'.esc_attr($row['id']).'"><td><strong>'.esc_html($row['name']).'</strong><br><code>'.esc_html($row['id']).'</code></td><td>'.esc_html($d['template_name']?:($d['template_id']?:'—')).'<br><small>current v'.(int)($collection['template_version']??1).'</small></td><td><span class="kgdm-completeness kgdm-completeness-'.esc_attr($d['state']).'">'.esc_html($d['label']).'</span></td><td>'.(int)$d['missing_required'].' / '.(int)$d['required'].'</td><td>'.(int)$d['missing_recommended'].' / '.(int)$d['recommended'].'</td><td class="kgdm-missing-paths">'.($missing_text!==''?esc_html($missing_text):'<span class="kgdm-muted">None</span>').'</td><td><a class="button" href="'.esc_url(self::tab_url('records',array('db'=>$selected_db,'collection'=>$collection_slug,'record'=>$row['id']))).'"><span class="dashicons dashicons-edit" aria-hidden="true"></span> Open record</a></td></tr>';}
        echo '</tbody></table></div><p class="kgdm-muted kgdm-completeness-empty" id="kgdm-completeness-empty" hidden>No records match the current filter.</p></section>';
    }

    private static function render_tab_records($database, $selected_db) {
        if (!$database) { echo self::empty_state_html('dashicons-database', 'No database selected', 'Create or select a database before managing records.', array(array('url'=>self::tab_url('databases'),'label'=>'Open Databases','icon'=>'dashicons-database','variant'=>'primary'))); return; }
        $all_collections = self::get_collections($selected_db, false);
        $collections = array_values(array_filter($all_collections, function($c){ return $c['status'] === 'active'; }));
        $collection_slug = sanitize_title(self::admin_query_param('collection', $collections[0]['slug'] ?? ''));
        $collection = self::get_collection($selected_db, $collection_slug, false);
        if (!$collection) { echo self::empty_state_html('dashicons-open-folder', 'No active folders', 'Create a folder and choose a form before adding records.', array(array('url'=>self::tab_url('collections',array('db'=>$selected_db)),'label'=>'Create folder','icon'=>'dashicons-plus-alt2','variant'=>'primary')), 'kgdm-record-empty'); return; }
        // Deleted-record management is centralized in the shared Trash workspace.
        // The legacy view=deleted route is redirected before this renderer runs.
        $per_page = 50; $paged = max(1, absint(self::admin_query_param('paged', 1)));
        $total = self::count_admin_records($selected_db, $collection_slug, false);
        $pages = max(1, (int)ceil($total/$per_page));
        $records = self::get_admin_records_page($selected_db, $collection_slug, false, $per_page, ($paged-1)*$per_page);
        $breadcrumb = self::collection_breadcrumb($collection, $selected_db);
        echo '<div class="kgdm-record-heading"><div class="kgdm-record-heading-main"><nav class="kgdm-breadcrumb" aria-label="Folder path"><a class="kgdm-breadcrumb-home" href="'.esc_url(self::tab_url('collections',array('db'=>$selected_db))).'"><span class="dashicons dashicons-database" aria-hidden="true"></span><span>'.esc_html($database['name']).'</span></a>';
        foreach ($breadcrumb as $i=>$part) {
            $crumb_url = (($part['status'] ?? 'active') === 'archived')
                ? self::tab_url('collections',array('db'=>$selected_db,'folder'=>$part['slug']))
                : self::tab_url('records',array('db'=>$selected_db,'collection'=>$part['slug']));
            echo '<span class="kgdm-breadcrumb-separator" aria-hidden="true"><span class="dashicons dashicons-arrow-right-alt2"></span></span>'.($i === count($breadcrumb)-1 ? '<strong aria-current="page">'.esc_html($part['name']).'</strong>' : '<a href="'.esc_url($crumb_url).'">'.esc_html($part['name']).'</a>');
        }
        echo '</nav><h2>'.esc_html($collection['name']).'</h2><p>'.esc_html($collection['description']).'</p></div><div class="kgdm-record-count"><strong>'.(int)$total.'</strong><span>records</span></div></div>';
        echo '<div class="kgdm-record-tools"><label>Folder / collection<select class="kgdm-select" id="kgdm-record-collection">';
        foreach ($collections as $col) {
            $depth=0; $cursor=$col; $guard=0; $visited=array();
            while (!empty($cursor['parent_id']) && $guard++<25 && !isset($visited[$cursor['id']])) { $visited[$cursor['id']]=true; $cursor=self::get_collection_by_id($selected_db,$cursor['parent_id'],false); if ($cursor) $depth++; else break; }
            echo '<option value="'.esc_attr($col['slug']).'" '.selected($collection_slug,$col['slug'],false).'>'.esc_html(str_repeat('— ',$depth).$col['name']).'</option>';
        }
        echo '</select></label><div class="kgdm-record-tool-actions"><a class="button button-primary" href="'.esc_url(self::tab_url('records',array('db'=>$selected_db,'collection'=>$collection_slug))).'">Active records</a>';
        self::render_workspace_trash_link('records',$selected_db,$collection_slug);
        echo '<button type="button" class="button button-primary" id="kgdm-add-record"><span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span> Add new '.esc_html($collection['singular_name'] ?: 'record').'</button></div></div>';
        echo '<div class="kgdm-record-setup-links"><a class="button" href="'.esc_url(self::tab_url('collections',array('db'=>$selected_db,'edit'=>$collection_slug))).'"><span class="dashicons dashicons-admin-generic" aria-hidden="true"></span> Edit folder &amp; form</a></div>';
        self::render_record_bulk_toolbar($collection, $selected_db, $collection_slug);
        $initial_record = self::new_record_template($collection);
        $initial_record['id'] = '';
        $initial_record['_kgdm_template_version'] = (int)($collection['template_version'] ?? 1);
        echo '<section class="kgdm-panel kgdm-record-editor" id="kgdm-record-editor" hidden><div class="kgdm-section-head"><div><h3 id="kgdm-editor-title">Add record</h3><p>Enter the data using this collection’s form template. All saved values stay in your WordPress database.</p></div></div><form id="kgdm-record-form" data-default-record="'.esc_attr(wp_json_encode($initial_record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)).'"><input type="hidden" id="kgdm-original-id" value=""><input type="hidden" id="kgdm-record-template-id" value=""><div class="kgdm-form-grid"><label>Record ID <span class="kgdm-muted">(required)</span><input type="text" id="kgdm-record-id" required placeholder="unique-record-id"><small>Enter a unique ID such as playground-sample-item. Keep it stable for links and code.</small></label>';
        if (($collection['collection_mode'] ?? 'form') === 'form' && !empty($collection['form_templates'])) {
            echo '<label>Entry template<select id="kgdm-record-template" required><option value="">Select a category template…</option>'; 
            foreach ($collection['form_templates'] as $template) {
                echo '<option value="'.esc_attr($template['category']).'" data-category="'.esc_attr($template['category']).'" data-defaults="'.esc_attr(wp_json_encode($template['defaults'] ?? array())).'" data-visible="'.esc_attr(wp_json_encode($template['visible_fields'] ?? array())).'" data-required="'.esc_attr(wp_json_encode($template['required_fields'] ?? array())).'">'.esc_html(($template['name'] ?? '').' — '.($template['category'] ?? '')).'</option>';
            }
            echo '</select><small>Each category form can show different fields from the same collection.</small></label>';
        }
        echo '</div>';
        $record_sections = (array)($collection['sections'] ?? array());
        echo '<section class="kgdm-record-publishing"><div class="kgdm-section-head"><div><h4>Organization &amp; publishing</h4><p>Assign one or more sections and control when this record is visible on the live site.</p></div></div>';
        if (!empty($record_sections)) {
            echo '<fieldset class="kgdm-record-section-terms"><legend>Sections</legend><div class="kgdm-section-term-grid">';
            foreach ($record_sections as $term) { $depth = substr_count((string)($term['path'] ?? ''), ' > '); echo '<label class="kgdm-section-term"><input type="checkbox" class="kgdm-record-section-checkbox" value="'.esc_attr($term['slug']).'"> <span>'.str_repeat('— ', $depth).esc_html($term['name']).'</span></label>'; }
            echo '</div></fieldset>';
        } else { echo '<p class="kgdm-muted">No sections yet. Add them in Folders &amp; forms → Edit folder → Record sections.</p>'; }
        echo '<div class="kgdm-record-publication-grid"><label>Visibility<select id="kgdm-record-visibility"><option value="public">Public</option><option value="private">Private</option></select><small>Private records are visible to administrators only.</small></label><label>Show from <span class="kgdm-muted">(optional)</span><input type="datetime-local" id="kgdm-record-publish-at"><small>Leave blank to publish immediately.</small></label><label>Hide after <span class="kgdm-muted">(optional)</span><input type="datetime-local" id="kgdm-record-hide-at"><small>Leave blank to keep it visible.</small></label></div></section>';
        if (($collection['collection_mode'] ?? 'form') === 'form') {
            $current_section = null;
            foreach ((array)$collection['schema'] as $field) {
                $section = trim((string)($field['section'] ?? 'General')) ?: 'General';
                if ($section !== $current_section) {
                    if ($current_section !== null) { echo '</div></section>'; }
                    echo '<section class="kgdm-record-section"><h4>'.esc_html($section).'</h4><div class="kgdm-record-fields">';
                    $current_section = $section;
                }
                self::render_record_field($field, null);
            }
            if ($current_section !== null) { echo '</div></section>'; }
        }
        echo '<details class="kgdm-advanced"';
        if (($collection['collection_mode'] ?? 'form') === 'list' || empty($collection['schema'])) { echo ' open'; }
        echo '><summary>'.((($collection['collection_mode'] ?? 'form') === 'list')?'Full JSON record':'Legacy / additional JSON data').'</summary><p class="kgdm-muted">Use this for data not currently represented by the active form. Values from removed fields remain here and are preserved when saving.</p><textarea id="kgdm-advanced-json" class="large-text code" rows="8">{}</textarea></details><p class="kgdm-form-actions"><button type="submit" class="button button-primary" id="kgdm-save-record">Save record</button><button type="button" class="button" id="kgdm-cancel-record">Cancel</button><span id="kgdm-record-message" role="status"></span></p></form></section>';
        echo '<section class="kgdm-panel"><div class="kgdm-section-head"><div><h3>Saved entries</h3><p>Entries in '.esc_html($collection['name']).'. Search, filter by section, and select records for bulk changes.</p></div><div class="kgdm-record-list-filters"><label>Section<select id="kgdm-record-section-filter"><option value="all">All sections</option><option value="unassigned">Unassigned</option>'; foreach ($record_sections as $term) { echo '<option value="'.esc_attr($term['slug']).'">'.esc_html($term['path'] ?? $term['name']).'</option>'; } echo '</select></label><label class="kgdm-search">Search<input type="search" id="kgdm-record-search" placeholder="Search records…"></label></div></div><div class="kgdm-table-wrap"><table class="widefat striped kgdm-record-table"><thead><tr><th><input type="checkbox" id="kgdm-select-all-records" aria-label="Select all visible records"></th><th class="kgdm-thumb-column">Image</th><th>Name</th><th>Record ID</th><th>Sections</th><th>Visibility</th><th>Origin</th><th>Completeness</th><th>Actions</th></tr></thead><tbody id="kgdm-record-rows" data-sections="'.esc_attr(wp_json_encode($record_sections)).'" data-image-key="'.esc_attr(self::first_media_field_key($collection)).'" data-image-type="'.esc_attr(self::first_media_field_type($collection)).'">';
        if (empty($records)) { echo '<tr class="kgdm-empty-row"><td colspan="9">No records yet. Use Add new record to create one.</td></tr>'; }
        foreach ($records as $id=>$record) {
            $is_managed = self::record_status($selected_db,$collection_slug,$id) !== '';
            $name = (string)($record['name'] ?? $record['title'] ?? $record['label'] ?? $id);
            $search = strtolower($id.' '.$name.' '.wp_json_encode($record));
            $completeness = self::record_completeness($record, $collection);
            $record = self::sanitize_record_metadata($record, $collection);
            $assigned_sections = (array)$record['_kgdm_sections']; $section_names = array();
            foreach ($record_sections as $term) { if (in_array($term['slug'], $assigned_sections, true)) { $section_names[] = $term['name']; } }
            $publication_state = self::record_publication_state($record);
            echo '<tr data-kgdm-record-row data-id="'.esc_attr($id).'" data-search="'.esc_attr($search).'" data-name="'.esc_attr($name).'" data-sections="'.esc_attr(implode(',', $assigned_sections)).'" data-visibility="'.esc_attr($publication_state).'"><td><input type="checkbox" class="kgdm-record-select" form="kgdm-bulk-records-form" name="record_ids[]" value="'.esc_attr($id).'" aria-label="Select '.esc_attr($name).'"></td><td class="kgdm-thumb-cell">'.wp_kses_post(self::record_thumbnail_html($record,$collection)).'</td><td><strong class="kgdm-row-name">'.esc_html($name).'</strong></td><td><code>'.esc_html($id).'</code></td><td>'.(!empty($section_names)?esc_html(implode(', ',$section_names)):'<span class="kgdm-muted">Unassigned</span>').'</td><td><span class="kgdm-visibility-pill kgdm-visibility-'.esc_attr($publication_state).'">'.esc_html(ucfirst($publication_state)).'</span></td><td>'.esc_html($is_managed?'Website database':'Master / source data').'</td><td><span class="kgdm-completeness kgdm-completeness-'.esc_attr($completeness['state']).'" title="'.esc_attr($completeness['required'] ? ($completeness['missing'].' of '.$completeness['required'].' required fields missing') : $completeness['label']).'">'.esc_html($completeness['label']).'</span></td><td class="kgdm-actions">';
            echo '<button type="button" class="button kgdm-edit-record" data-id="'.esc_attr($id).'">Edit</button> <button type="button" class="button-link-delete kgdm-delete-record" data-id="'.esc_attr($id).'">Move to Trash</button>';
            echo '</td></tr>';
        }
        echo '</tbody></table></div><p class="kgdm-muted kgdm-no-search-results" hidden>No records match this search.</p>';
        if ($pages>1) { echo '<div class="tablenav"><div class="tablenav-pages">'.wp_kses_post(paginate_links(array('base'=>add_query_arg('paged','%#%',self::tab_url('records',array('db'=>$selected_db,'collection'=>$collection_slug))),'format'=>'','current'=>$paged,'total'=>$pages,'type'=>'plain'))) . '</div></div>'; }
        echo '</section><input type="hidden" id="kgdm-ajax-config" data-url="'.esc_url(admin_url('admin-ajax.php')).'" data-nonce="'.esc_attr(wp_create_nonce('kgdm_record_action')).'" data-db="'.esc_attr($selected_db).'" data-collection="'.esc_attr($collection_slug).'" data-deleted="0">';
    }

    private static function render_record_bulk_toolbar($collection, $database_id, $collection_slug) {
        echo '<form id="kgdm-bulk-records-form" class="kgdm-bulk-records" method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="kgdm_bulk_update_records"><input type="hidden" name="database_id" value="'.esc_attr($database_id).'"><input type="hidden" name="collection_slug" value="'.esc_attr($collection_slug).'">';
        wp_nonce_field('kgdm_bulk_update_records');
        echo '<div class="kgdm-bulk-toolbar"><div class="kgdm-bulk-toolbar-heading"><span class="dashicons dashicons-edit" aria-hidden="true"></span><span><strong>Bulk edit selected</strong><small>Apply visibility, section and publishing changes to multiple records.</small></span></div><label>Visibility<select name="bulk_visibility"><option value="unchanged">Do not change</option><option value="public">Public</option><option value="private">Private</option></select></label><label>Sections<select name="bulk_sections_action"><option value="unchanged">Do not change</option><option value="replace">Replace</option><option value="add">Add</option><option value="remove">Remove</option><option value="clear">Clear all</option></select></label><label>Apply sections<select name="bulk_sections[]" multiple size="4">';
        foreach ((array)($collection['sections'] ?? array()) as $term) { echo '<option value="'.esc_attr($term['slug']).'">'.esc_html($term['path'] ?? $term['name']).'</option>'; }
        echo '</select></label><label>Show from<select name="bulk_publish_action"><option value="unchanged">Do not change</option><option value="set">Set date</option><option value="clear">Clear date</option></select></label><label>Publish date<input type="datetime-local" name="bulk_publish_at"></label><label>Hide after<select name="bulk_hide_action"><option value="unchanged">Do not change</option><option value="set">Set date</option><option value="clear">Clear date</option></select></label><label>Hide date<input type="datetime-local" name="bulk_hide_at"></label><button type="submit" class="button button-primary"><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span> Apply to selected</button><span class="kgdm-muted">Select records in the table below. Maximum 500 per action.</span></div></form>';
    }

    public function handle_bulk_update_records() {
        self::require_admin(); check_admin_referer('kgdm_bulk_update_records');
        $db = sanitize_key(wp_unslash($_POST['database_id'] ?? ''));
        $slug = sanitize_title(wp_unslash($_POST['collection_slug'] ?? ''));
        $collection = self::get_collection($db, $slug, false);
        $ids = array_values(array_unique(array_filter(array_map('sanitize_title', (array)wp_unslash($_POST['record_ids'] ?? array())))));
        if (!$collection || empty($ids) || count($ids) > 500) { self::redirect(array('tab'=>'records','db'=>$db,'collection'=>$slug,'notice'=>'bulk_records_invalid')); }
        $visibility = sanitize_key(wp_unslash($_POST['bulk_visibility'] ?? 'unchanged'));
        if (!in_array($visibility, array('unchanged','public','private'), true)) { $visibility = 'unchanged'; }
        $section_action = sanitize_key(wp_unslash($_POST['bulk_sections_action'] ?? 'unchanged'));
        if (!in_array($section_action, array('unchanged','replace','add','remove','clear'), true)) { $section_action = 'unchanged'; }
        $allowed = array(); foreach ((array)$collection['sections'] as $term) { $allowed[$term['slug']] = true; }
        $selected = array_values(array_filter(array_unique(array_map('sanitize_title',(array)wp_unslash($_POST['bulk_sections'] ?? array()))),function($v)use($allowed){return isset($allowed[$v]);}));
        $date_actions = array();
        foreach (array('publish','hide') as $key) {
            $action = sanitize_key(wp_unslash($_POST['bulk_'.$key.'_action'] ?? 'unchanged'));
            if (!in_array($action, array('unchanged','set','clear'), true)) { $action = 'unchanged'; }
            $value = str_replace('T',' ',sanitize_text_field(wp_unslash($_POST['bulk_'.$key.'_at'] ?? '')));
            if ($action === 'set') {
                if (!preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}(:\d{2})?$/',$value)) { self::redirect(array('tab'=>'records','db'=>$db,'collection'=>$slug,'notice'=>'bulk_date_invalid')); }
                if (strlen($value) === 16) { $value .= ':00'; }
                $dt = DateTime::createFromFormat('Y-m-d H:i:s',$value,wp_timezone());
                if (!$dt || $dt->format('Y-m-d H:i:s') !== $value) { self::redirect(array('tab'=>'records','db'=>$db,'collection'=>$slug,'notice'=>'bulk_date_invalid')); }
                $date_actions[$key] = $value;
            } else { $date_actions[$key] = ''; }
            $date_actions[$key.'_action'] = $action;
        }
        if ($date_actions['publish_action'] === 'set' && $date_actions['hide_action'] === 'set' && $date_actions['hide'] <= $date_actions['publish']) { self::redirect(array('tab'=>'records','db'=>$db,'collection'=>$slug,'notice'=>'bulk_date_invalid')); }
        $updated = 0; $failed = 0;
        foreach ($ids as $id) {
            $record = self::get_admin_record($db,$slug,$id,false);
            if (!is_array($record)) { $failed++; continue; }
            $record = self::sanitize_record_metadata($record,$collection);
            $publication = $record['_kgdm_publication'];
            if ($visibility !== 'unchanged') { $publication['visibility'] = $visibility; }
            foreach (array('publish','hide') as $key) {
                $action = $date_actions[$key.'_action']; $field = $key === 'publish' ? 'publish_at' : 'hide_at';
                if ($action === 'set') { $publication[$field] = $date_actions[$key]; }
                elseif ($action === 'clear') { $publication[$field] = ''; }
            }
            if ($publication['publish_at'] !== '' && $publication['hide_at'] !== '' && $publication['hide_at'] <= $publication['publish_at']) { $failed++; continue; }
            $record['_kgdm_publication'] = $publication;
            $sections = $record['_kgdm_sections'];
            if ($section_action === 'replace') { $sections = $selected; }
            elseif ($section_action === 'add') { $sections = array_values(array_unique(array_merge($sections,$selected))); }
            elseif ($section_action === 'remove') { $sections = array_values(array_diff($sections,$selected)); }
            elseif ($section_action === 'clear') { $sections = array(); }
            $record['_kgdm_sections'] = $sections;
            if (self::upsert_record($db,$slug,$id,$record,'active')) { $updated++; } else { $failed++; }
        }
        self::redirect(array('tab'=>'records','db'=>$db,'collection'=>$slug,'notice'=>'bulk_records_updated','bulk_updated'=>$updated,'bulk_failed'=>$failed));
    }

    /** Restore one database entry. Shared by single-item and bulk Trash actions. */
    private static function restore_trashed_database($database_id) {
        global $wpdb;
        $tables = self::table_names();
        $id = sanitize_key((string)$database_id);
        $database = self::get_database($id, true);
        if (!$database || ($database['status'] ?? '') !== 'archived') { return new WP_Error('kgdm_trash_database_missing', 'The selected database is no longer in Trash.'); }
        $updated = $wpdb->update($tables['databases'], array('status'=>'active','updated_at'=>self::now()), array('id'=>$id,'status'=>'archived'));
        if ($updated === false || $updated < 1) { return new WP_Error('kgdm_trash_database_restore_failed', 'The database could not be restored.'); }
        update_option(self::ACTIVE_DB_OPTION, $id, false);
        self::invalidate_all_query_cache();
        return true;
    }

    /** Permanently remove one archived database and all KGDM-owned descendants. */
    private static function purge_trashed_database($database_id) {
        global $wpdb;
        $tables = self::table_names();
        $id = sanitize_key((string)$database_id);
        $database = self::get_database($id, true);
        if (!$database || ($database['status'] ?? '') !== 'archived') { return new WP_Error('kgdm_trash_database_missing', 'Only databases in Trash can be permanently deleted.'); }
        $transactional = self::backup_tables_are_transactional();
        if (is_wp_error($transactional)) { return $transactional; }
        $migration_ids = $wpdb->get_col($wpdb->prepare('SELECT migration_id FROM %i WHERE database_id = %s', $tables['migrations'], $id));
        $record_ids = $wpdb->get_col($wpdb->prepare('SELECT record_id FROM %i WHERE database_id = %s', $tables['records'], $id));
        if ($wpdb->last_error !== '') { return new WP_Error('kgdm_trash_database_inspect_failed', 'Database contents could not be inspected.'); }
        if ($wpdb->query('START TRANSACTION') === false) { return new WP_Error('kgdm_trash_database_transaction_failed', 'A safe delete transaction could not be started.'); }
        $failed = false;
        foreach (array_chunk(array_values(array_filter(array_map('strval',(array)$migration_ids))), 250) as $batch) {
            if (self::delete_rows_in_column($tables['migration_records'], 'migration_id', $batch) === false) { $failed = true; break; }
        }
        if (!$failed) {
            foreach (array_chunk(array_values(array_filter(array_map('strval',(array)$record_ids))), 250) as $batch) {
                if (self::delete_rows_in_column($tables['migration_records'], 'record_id', $batch) === false) { $failed = true; break; }
            }
        }
        foreach (array('records','template_versions','migrations','collections') as $key) {
            if ($failed) { break; }
            if ($wpdb->delete($tables[$key], array('database_id'=>$id), array('%s')) === false) { $failed = true; }
        }
        if (!$failed && $wpdb->delete($tables['databases'], array('id'=>$id), array('%s')) === false) { $failed = true; }
        if ($failed || $wpdb->query('COMMIT') === false) {
            $wpdb->query('ROLLBACK');
            return new WP_Error('kgdm_trash_database_purge_failed', 'The database deletion was rolled back; stored data was retained.');
        }
        if (get_option(self::ACTIVE_DB_OPTION, '') === $id) {
            $remaining = self::get_databases(false);
            update_option(self::ACTIVE_DB_OPTION, !empty($remaining) ? $remaining[0]['id'] : '', false);
        }
        self::invalidate_all_query_cache();
        return true;
    }

    /** Restore a trashed folder group after validating the active database and ancestor chain. */
    private static function restore_trashed_folder($database_id, $slug) {
        $db = sanitize_key((string)$database_id);
        $folder_slug = sanitize_title((string)$slug);
        if (!self::get_database($db, false)) { return new WP_Error('kgdm_trash_folder_database_first', 'Restore the database before restoring its folders.'); }
        $collection = self::get_collection($db, $folder_slug, true);
        $result = self::restore_collection_subtree($db, $collection);
        return is_wp_error($result) ? $result : ($result ? true : new WP_Error('kgdm_trash_folder_restore_failed', 'The folder group could not be restored.'));
    }

    /** Permanently delete one top-level archived folder and its full KGDM subtree. */
    private static function purge_trashed_folder($database_id, $slug) {
        global $wpdb;
        $db = sanitize_key((string)$database_id);
        $folder_slug = sanitize_title((string)$slug);
        $tables = self::table_names();
        $collection = self::get_collection($db, $folder_slug, true);
        if (!$collection || ($collection['status'] ?? '') !== 'archived') { return new WP_Error('kgdm_trash_folder_missing', 'Only folders in Trash can be permanently deleted.'); }
        if (!self::get_database($db, false)) { return new WP_Error('kgdm_trash_folder_database_first', 'Restore the database before deleting folders inside it.'); }
        $transactional = self::backup_tables_are_transactional();
        if (is_wp_error($transactional)) { return $transactional; }
        $all_collections = self::get_collections($db, true);
        $all_by_id = array();
        foreach ($all_collections as $item) { $all_by_id[(string)$item['id']] = $item; }
        if (!self::collection_is_trash_root($collection, $all_by_id)) { return new WP_Error('kgdm_trash_folder_parent_first', 'Restore the trashed parent folder first.'); }
        $subtree = self::collection_subtree($all_collections, $collection['id']);
        if (empty($subtree)) { return new WP_Error('kgdm_trash_folder_subtree_missing', 'The folder subtree could not be loaded.'); }
        $collection_ids = array_values(array_unique(array_map(function($item) { return (string)$item['id']; }, $subtree)));
        $slugs = array_values(array_unique(array_map(function($item) { return (string)$item['slug']; }, $subtree)));
        if ($wpdb->query('START TRANSACTION') === false) { return new WP_Error('kgdm_trash_folder_transaction_failed', 'A safe folder delete transaction could not be started.'); }
        $failed = false;
        foreach (array_chunk($collection_ids, 250) as $id_batch) {
            $placeholders = implode(',', array_fill(0, count($id_batch), '%s'));
            $migration_query = $wpdb->prepare('SELECT migration_id FROM %i WHERE database_id = %s AND collection_id IN ('.$placeholders.')', array_merge(array($tables['migrations'],$db),$id_batch));
            $migration_ids = $wpdb->get_col($migration_query);
            if ($wpdb->last_error !== '') { $failed = true; break; }
            foreach (array_chunk(array_values(array_filter(array_map('strval',(array)$migration_ids))),250) as $batch) {
                if (self::delete_rows_in_column($tables['migration_records'],'migration_id',$batch) === false) { $failed=true; break; }
            }
            if ($failed) { break; }
            $record_query = $wpdb->prepare('SELECT record_id FROM %i WHERE database_id = %s AND collection_id IN ('.$placeholders.')', array_merge(array($tables['records'],$db),$id_batch));
            $record_ids = $wpdb->get_col($record_query);
            if ($wpdb->last_error !== '') { $failed = true; break; }
            foreach (array_chunk(array_values(array_filter(array_map('strval',(array)$record_ids))),250) as $batch) {
                if (self::delete_rows_in_column($tables['migration_records'],'record_id',$batch) === false) { $failed=true; break; }
            }
            if ($failed) { break; }
            if (self::delete_rows_in_column($tables['records'],'collection_id',$id_batch,'database_id',$db) === false
                || self::delete_rows_in_column($tables['template_versions'],'collection_id',$id_batch,'database_id',$db) === false
                || self::delete_rows_in_column($tables['migrations'],'collection_id',$id_batch,'database_id',$db) === false
                || self::delete_rows_in_column($tables['collections'],'id',$id_batch,'database_id',$db) === false) { $failed=true; break; }
        }
        if ($failed || $wpdb->query('COMMIT') === false) {
            $wpdb->query('ROLLBACK');
            return new WP_Error('kgdm_trash_folder_purge_failed', 'Folder deletion was rolled back; the stored data was retained.');
        }
        foreach ($slugs as $deleted_slug) { self::invalidate_collection_query_cache($db, $deleted_slug); }
        return true;
    }

    /** Restore one deleted record, including the legacy restore-base behavior. */
    private static function restore_trashed_record($database_id, $collection_slug, $record_id) {
        global $wpdb;
        $db = sanitize_key((string)$database_id);
        $slug = sanitize_title((string)$collection_slug);
        $id = sanitize_title((string)$record_id);
        if (!self::get_database($db, false) || !self::get_collection($db, $slug, false)) { return new WP_Error('kgdm_trash_record_parent_first', 'Restore the database and folder first.'); }
        $entry = self::db_record_entry($db, $slug, $id);
        if (!$entry || ($entry['status'] ?? '') !== 'deleted') { return new WP_Error('kgdm_trash_record_missing', 'The selected record is no longer in Trash.'); }
        if (!empty($entry['record']['__kgdm_restore_base'])) {
            $tables = self::table_names();
            $collection = self::get_collection($db, $slug, true);
            $deleted = $collection ? $wpdb->delete($tables['records'], array('collection_id'=>$collection['id'],'item_key'=>$id,'status'=>'deleted')) : false;
            if ($deleted === false || $deleted < 1) { return new WP_Error('kgdm_trash_record_restore_failed', 'The record could not be restored.'); }
            self::flush_record_cache($db, $slug, $id);
        } elseif (!self::upsert_record($db, $slug, $id, $entry['record'], 'active')) {
            return new WP_Error('kgdm_trash_record_restore_failed', 'The record could not be restored.');
        }
        return true;
    }

    /** Permanently delete a record and its recovery snapshots; preserve a Genshin source tombstone when required. */
    private static function purge_trashed_record($database_id, $collection_slug, $record_id) {
        global $wpdb;
        $db = sanitize_key((string)$database_id);
        $slug = sanitize_title((string)$collection_slug);
        $id = sanitize_title((string)$record_id);
        $tables = self::table_names();
        $database = self::get_database($db, false);
        $collection = self::get_collection($db, $slug, false);
        if (!$database || !$collection || $id === '') { return new WP_Error('kgdm_trash_record_parent_first', 'Restore the database and folder before deleting this record.'); }
        $row = $wpdb->get_row($wpdb->prepare('SELECT record_id FROM %i WHERE database_id = %s AND collection_id = %s AND item_key = %s AND status = %s LIMIT 1',$tables['records'],$db,$collection['id'],$id,'deleted'), ARRAY_A);
        if (!$row) { return new WP_Error('kgdm_trash_record_missing', 'The selected record is no longer in Trash.'); }
        $is_master_record = self::is_legacy_master_record($db,$slug,$id);
        $transactional = self::backup_tables_are_transactional();
        if (is_wp_error($transactional)) { return $transactional; }
        if ($wpdb->query('START TRANSACTION') === false) { return new WP_Error('kgdm_trash_record_transaction_failed', 'A safe record delete transaction could not be started.'); }
        $record_db_id = (int)$row['record_id'];
        $snapshot_delete = $wpdb->delete($tables['migration_records'],array('record_id'=>$record_db_id),array('%d'));
        if ($is_master_record) {
            $tombstone = array('id'=>$id,'_kgdm_permanent_tombstone'=>true);
            $encoded = self::encode_record_payload($tombstone);
            $record_change = is_wp_error($encoded) ? false : $wpdb->update($tables['records'],array(
                'item_name'=>$id,'payload'=>$encoded['json'],'payload_hash'=>$encoded['hash'],'payload_version'=>$encoded['version'],'payload_format'=>$encoded['format'],'status'=>'purged','updated_at'=>self::now(),'updated_by'=>get_current_user_id()
            ),array('record_id'=>$record_db_id,'status'=>'deleted'));
        } else {
            $record_change = $wpdb->delete($tables['records'],array('record_id'=>$record_db_id,'status'=>'deleted'));
        }
        if ($snapshot_delete === false || $record_change === false || $record_change < 1 || $wpdb->query('COMMIT') === false) {
            $wpdb->query('ROLLBACK');
            return new WP_Error('kgdm_trash_record_purge_failed','The record delete was rolled back; the record and recovery snapshots were retained.');
        }
        self::flush_record_cache($db,$slug,$id);
        return true;
    }

    /** Shared bulk action handler for one or more selected Trash entries of one type. */
    public function handle_bulk_trash_action() {
        self::require_admin();
        check_admin_referer('kgdm_bulk_trash_action');
        $type = sanitize_key(wp_unslash($_POST['trash_type'] ?? ''));
        $bulk_action = sanitize_key(wp_unslash($_POST['bulk_action'] ?? ''));
        $allowed = array('databases','folders','records');
        if (!in_array($type,$allowed,true) || !in_array($bulk_action,array('restore','purge'),true)) {
            self::redirect(array('tab'=>'trash','trash_type'=>'all','notice'=>'trash_bulk_invalid'));
        }
        $selected = isset($_POST['selected']) ? (array)wp_unslash($_POST['selected']) : array();
        $selected = array_values(array_unique(array_filter(array_slice(array_map(function($value) { return is_scalar($value) ? sanitize_text_field((string)$value) : ''; }, $selected),0,100), function($value) { return $value !== ''; })));
        if (empty($selected)) { self::redirect(array('tab'=>'trash','trash_type'=>$type,'notice'=>'trash_bulk_empty')); }
        $done = 0; $failed = 0;
        foreach ($selected as $token) {
            $parts = explode('|',(string)$token);
            if ($type === 'databases') {
                if (count($parts) !== 1) { $failed++; continue; }
                $result = $bulk_action === 'restore' ? self::restore_trashed_database($parts[0]) : self::purge_trashed_database($parts[0]);
            } elseif ($type === 'folders') {
                if (count($parts) !== 2) { $failed++; continue; }
                $result = $bulk_action === 'restore' ? self::restore_trashed_folder($parts[0],$parts[1]) : self::purge_trashed_folder($parts[0],$parts[1]);
            } else {
                if (count($parts) !== 3) { $failed++; continue; }
                $result = $bulk_action === 'restore' ? self::restore_trashed_record($parts[0],$parts[1],$parts[2]) : self::purge_trashed_record($parts[0],$parts[1],$parts[2]);
            }
            if (is_wp_error($result) || $result !== true) { $failed++; } else { $done++; }
        }
        $redirect_args = array('tab'=>'trash','trash_type'=>$type,'bulk_done'=>$done,'bulk_failed'=>$failed,'notice'=>'trash_bulk_done');
        $database_scope = sanitize_key(wp_unslash($_POST['database_scope'] ?? ''));
        $collection_scope = sanitize_title(wp_unslash($_POST['collection_scope'] ?? ''));
        $view = sanitize_key(wp_unslash($_POST['trash_view'] ?? 'list'));
        if ($database_scope !== '') { $redirect_args['db'] = $database_scope; }
        if ($type === 'records' && $collection_scope !== '') { $redirect_args['collection'] = $collection_scope; }
        if (in_array($view,array('list','grid'),true)) { $redirect_args['trash_view'] = $view; }
        self::redirect($redirect_args);
    }

    private static function render_trash_action_form($action, $nonce, $fields, $label, $confirm = '') {
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"'.($confirm !== '' ? ' onsubmit="return confirm(\''.esc_js($confirm).'\')"' : '').'><input type="hidden" name="action" value="'.esc_attr($action).'">';
        foreach ($fields as $name=>$value) { echo '<input type="hidden" name="'.esc_attr($name).'" value="'.esc_attr($value).'">'; }
        wp_nonce_field($nonce);
        echo '<button type="submit" class="button'.(strpos($action,'purge') !== false || $action === 'kgdm_delete_collection' ? ' button-link-delete' : '').'">'.($action === 'kgdm_restore_database' || $action === 'kgdm_restore_collection' || $action === 'kgdm_restore_record' ? '<span class="dashicons dashicons-backup" aria-hidden="true"></span>' : '<span class="dashicons dashicons-trash" aria-hidden="true"></span>').' '.esc_html($label).'</button></form>';
    }

    /** Render one reusable Trash section toolbar; checkboxes on cards are associated by form ID. */
    private static function render_trash_bulk_toolbar($type, $form_id, $view, $database_scope, $collection_scope = '') {
        echo '<form class="kgdm-trash-bulk-form" id="'.esc_attr($form_id).'" method="post" action="'.esc_url(admin_url('admin-post.php')).'" data-trash-bulk-form data-trash-type="'.esc_attr($type).'">';
        echo '<input type="hidden" name="action" value="kgdm_bulk_trash_action"><input type="hidden" name="trash_type" value="'.esc_attr($type).'"><input type="hidden" name="database_scope" value="'.esc_attr($database_scope).'"><input type="hidden" name="collection_scope" value="'.esc_attr($collection_scope).'"><input type="hidden" name="trash_view" value="'.esc_attr($view).'">';
        wp_nonce_field('kgdm_bulk_trash_action');
        echo '<div class="kgdm-trash-bulk-toolbar"><label class="kgdm-trash-select-page"><input type="checkbox" data-trash-select-all="'.esc_attr($type).'"> <span>Select page</span></label><span class="kgdm-trash-selected-count" data-trash-selected-count="'.esc_attr($type).'">0 selected</span><span class="kgdm-trash-bulk-spacer"></span><button type="submit" class="button" name="bulk_action" value="restore" data-trash-bulk-button disabled><span class="dashicons dashicons-backup" aria-hidden="true"></span> Restore selected</button><button type="submit" class="button button-link-delete" name="bulk_action" value="purge" data-trash-bulk-button data-trash-bulk-purge disabled><span class="dashicons dashicons-trash" aria-hidden="true"></span> Delete permanently</button></div></form>';
    }

    /** Render pagination while preserving the current category, scopes and view mode. */
    private static function render_trash_pagination($query_key, $current, $total_pages, $type, $database_scope, $collection_scope, $view) {
        if ((int)$total_pages <= 1) { return; }
        $args = array('trash_type'=>$type,'db'=>$database_scope,'trash_view'=>$view);
        if ($collection_scope !== '') { $args['collection'] = $collection_scope; }
        foreach (array('trash_db_paged','trash_folder_paged','trash_record_paged') as $other_key) {
            if ($other_key === $query_key) { continue; }
            $other_page = max(1, absint(self::admin_query_param($other_key, 1)));
            if ($other_page > 1) { $args[$other_key] = $other_page; }
        }
        $base = add_query_arg($query_key,'%#%',self::tab_url('trash',$args));
        echo '<nav class="kgdm-trash-pagination" aria-label="Trash pages">'.wp_kses_post(paginate_links(array('base'=>$base,'format'=>'','current'=>(int)$current,'total'=>(int)$total_pages,'type'=>'list','prev_text'=>'<span class="dashicons dashicons-arrow-left-alt2" aria-hidden="true"></span> Previous','next_text'=>'Next <span class="dashicons dashicons-arrow-right-alt2" aria-hidden="true"></span>'))).'</nav>';
    }

    private static function render_trash_workspace($selected_db) {
        $type = sanitize_key(self::admin_query_param('trash_type','all'));
        if (!in_array($type,array('all','databases','folders','records'),true)) { $type='all'; }
        $view = sanitize_key(self::admin_query_param('trash_view','list'));
        if (!in_array($view,array('list','grid'),true)) { $view='list'; }
        $trash_collection = sanitize_title(self::admin_query_param('collection',''));
        $counts = self::get_trash_counts($selected_db,$trash_collection);
        $databases = self::get_databases(true);
        $active_databases = self::get_databases(false);
        $total_count = array_sum($counts);
        $view_args = array('db'=>$selected_db,'trash_type'=>$type,'trash_view'=>$view);
        if ($trash_collection !== '') { $view_args['collection'] = $trash_collection; }
        $list_url = self::tab_url('trash',array_merge($view_args,array('trash_view'=>'list')));
        $grid_url = self::tab_url('trash',array_merge($view_args,array('trash_view'=>'grid')));
        echo '<section class="kgdm-trash-workspace kgdm-trash-workspace-modern" data-trash-view="'.esc_attr($view).'">';
        echo '<header class="kgdm-trash-hero"><div class="kgdm-trash-hero-icon"><span class="dashicons dashicons-trash" aria-hidden="true"></span></div><div class="kgdm-trash-hero-copy"><span class="kgdm-trash-eyebrow">RECOVERY CENTER</span><h2>Trash &amp; recovery</h2><p>Restore items you still need, or permanently remove items you no longer use. Each section keeps its own selection and page controls.</p></div><div class="kgdm-trash-hero-total"><strong>'.(int)$total_count.'</strong><span>items in Trash</span></div></header>';
        echo '<div class="kgdm-trash-guidance"><span class="dashicons dashicons-info-outline" aria-hidden="true"></span><div><strong>How Trash works</strong><p>Restoring returns an item to its previous workspace. Permanent deletion cannot be undone. Permanently deleting a folder also deletes its nested folders and KGDM records.</p></div></div>';
        echo '<nav class="kgdm-trash-tabs" aria-label="Trash categories">';
        $tabs=array('all'=>'All items','databases'=>'Databases','folders'=>'Folders','records'=>'Records');
        foreach($tabs as $key=>$label){
            $count=$key==='all'?$total_count:(int)$counts[$key];
            $args=array('db'=>$selected_db,'trash_type'=>$key,'trash_view'=>$view);
            if($trash_collection!=='' && in_array($key,array('all','records'),true)){$args['collection']=$trash_collection;}
            echo '<a class="kgdm-trash-tab'.($type===$key?' is-active':'').'" href="'.esc_url(self::tab_url('trash',$args)).'"'.($type===$key?' aria-current="page"':'').'><span>'.esc_html($label).'</span><strong>'.(int)$count.'</strong></a>';
        }
        echo '</nav>';
        echo '<div class="kgdm-trash-controls"><label class="kgdm-trash-search"><span class="dashicons dashicons-search" aria-hidden="true"></span><input type="search" id="kgdm-trash-search" placeholder="Search the items on this page…" autocomplete="off"></label><div class="kgdm-trash-view-switch" role="group" aria-label="Trash layout"><a class="button'.($view==='list'?' is-active':'').'" href="'.esc_url($list_url).'" aria-pressed="'.($view==='list'?'true':'false').'"><span class="dashicons dashicons-list-view" aria-hidden="true"></span> List</a><a class="button'.($view==='grid'?' is-active':'').'" href="'.esc_url($grid_url).'" aria-pressed="'.($view==='grid'?'true':'false').'"><span class="dashicons dashicons-grid-view" aria-hidden="true"></span> Grid</a></div></div>';
        if($selected_db!=='' || $trash_collection!==''){
            $scope_db=$selected_db!==''?self::get_database($selected_db,true):null;
            $scope_name=$scope_db['name']??($selected_db!==''?$selected_db:'All databases');
            echo '<div class="kgdm-trash-scope"><span class="dashicons dashicons-filter" aria-hidden="true"></span><span>Folder and record items scoped to <strong>'.esc_html($scope_name).'</strong>'.($trash_collection!==''?' · collection <code>'.esc_html($trash_collection).'</code>':'').'.</span><a href="'.esc_url(self::tab_url('trash',array('trash_type'=>$type,'trash_view'=>$view))).'">Clear scope</a></div>';
        }

        // Databases: paginated list/grid cards with single-item and multi-select actions.
        if($type==='all'||$type==='databases'){
            $database_rows=array_values(array_filter($databases,function($row){return ($row['status']??'')==='archived';}));
            $db_per_page=20;$db_page=max(1,absint(self::admin_query_param('trash_db_paged',1)));$db_total=count($database_rows);$db_pages=max(1,(int)ceil($db_total/$db_per_page));$db_page=min($db_page,$db_pages);$db_rows=array_slice($database_rows,($db_page-1)*$db_per_page,$db_per_page);
            echo '<section class="kgdm-panel kgdm-trash-panel-modern"><div class="kgdm-trash-section-head"><div class="kgdm-trash-section-title"><span class="kgdm-trash-section-icon is-database"><span class="dashicons dashicons-database" aria-hidden="true"></span></span><div><h3>Databases</h3><p>Archived workspaces with their folders, records and template history.</p></div></div><span class="kgdm-trash-section-total">'.(int)$db_total.' items</span></div>';
            if(empty($database_rows)){echo self::empty_state_html('dashicons-database','No databases in Trash','Databases moved to Trash will appear here.',array(),'kgdm-trash-empty');}
            else{
                self::render_trash_bulk_toolbar('databases','kgdm-trash-bulk-databases',$view,$selected_db);
                echo '<div class="kgdm-trash-items" data-view="'.esc_attr($view).'" data-trash-items="databases">';
                foreach($db_rows as $row){
                    $cols=self::get_collections($row['id'],true);global $wpdb;$tables=self::table_names();$record_count=(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE database_id = %s',$tables['records'],$row['id']));
                    $search=strtolower($row['name'].' '.$row['id'].' '.$row['kind']);$token=esc_attr($row['id']);
                    echo '<article class="kgdm-trash-entry" data-kgdm-trash-row data-search="'.esc_attr($search).'" data-trash-entry><label class="kgdm-trash-entry-select"><input type="checkbox" form="kgdm-trash-bulk-databases" name="selected[]" value="'.$token.'" data-trash-select-item="databases" aria-label="Select database '.esc_attr($row['name']).'"><span class="screen-reader-text">Select item</span></label><span class="kgdm-trash-entry-icon is-database"><span class="dashicons dashicons-database" aria-hidden="true"></span></span><div class="kgdm-trash-entry-copy"><strong>'.esc_html($row['name']).'</strong><code>'.esc_html($row['id']).'</code><span class="kgdm-trash-entry-meta">'.esc_html(self::database_type_label($row['kind'])).' · '.count($cols).' folders · '.$record_count.' records retained</span><small>Last updated '.esc_html($row['updated_at']??'—').'</small></div><div class="kgdm-trash-entry-actions">';
                    self::render_trash_action_form('kgdm_restore_database','kgdm_restore_database',array('database_id'=>$row['id']),'Restore');
                    self::render_trash_action_form('kgdm_purge_database','kgdm_purge_database',array('database_id'=>$row['id']),'Delete permanently','Permanently delete this database and all its folders, records, templates and recovery history? This cannot be undone.');
                    echo '</div></article>';
                }
                echo '</div>';
                echo '<div class="kgdm-trash-page-summary">Showing '.(($db_page-1)*$db_per_page+1).'–'.min($db_page*$db_per_page,$db_total).' of '.(int)$db_total.' databases</div>';
                self::render_trash_pagination('trash_db_paged',$db_page,$db_pages,$type,$selected_db,$trash_collection,$view);
            }
            echo '</section>';
        }

        // Folders: top-level trash roots only; a selected folder action applies to its subtree.
        if($type==='all'||$type==='folders'){
            $folder_rows=array();
            foreach($active_databases as $db){
                if($selected_db!=='' && $db['id']!==$selected_db){continue;}
                $all=self::get_collections($db['id'],true);$by_id=array();foreach($all as $item){$by_id[(string)$item['id']]=$item;}
                foreach($all as $item){if(($item['status']??'')!=='archived'||!self::collection_is_trash_root($item,$by_id)){continue;}$folder_rows[]=array('database'=>$db,'collection'=>$item,'subtree'=>self::collection_subtree($all,$item['id']));}
            }
            $folder_per_page=20;$folder_page=max(1,absint(self::admin_query_param('trash_folder_paged',1)));$folder_total=count($folder_rows);$folder_pages=max(1,(int)ceil($folder_total/$folder_per_page));$folder_page=min($folder_page,$folder_pages);$folder_rows_page=array_slice($folder_rows,($folder_page-1)*$folder_per_page,$folder_per_page);
            echo '<section class="kgdm-panel kgdm-trash-panel-modern"><div class="kgdm-trash-section-head"><div class="kgdm-trash-section-title"><span class="kgdm-trash-section-icon is-folder"><span class="dashicons dashicons-open-folder" aria-hidden="true"></span></span><div><h3>Folders &amp; forms</h3><p>Folder groups are kept together. Restoring a parent restores only the descendants it moved.</p></div></div><span class="kgdm-trash-section-total">'.(int)$folder_total.' items</span></div>';
            if(empty($folder_rows)){echo self::empty_state_html('dashicons-open-folder','No folders in Trash','Folders moved to Trash will appear here.',array(),'kgdm-trash-empty');}
            else{
                self::render_trash_bulk_toolbar('folders','kgdm-trash-bulk-folders',$view,$selected_db);
                echo '<div class="kgdm-trash-items" data-view="'.esc_attr($view).'" data-trash-items="folders">';
                foreach($folder_rows_page as $entry){
                    $db=$entry['database'];$folder=$entry['collection'];$subtree=$entry['subtree'];$ids=array_map(function($x){return (string)$x['id'];},$subtree);$records_total=0;
                    if(!empty($ids)){$ph=implode(',',array_fill(0,count($ids),'%s'));global $wpdb;$tables=self::table_names();$sql='SELECT COUNT(*) FROM %i WHERE database_id = %s AND collection_id IN ('.$ph.')';$args=array_merge(array($tables['records'],$db['id']),$ids);$records_total=(int)$wpdb->get_var($wpdb->prepare($sql,$args));}
                    $search=strtolower($db['name'].' '.$folder['name'].' '.$folder['slug']);$token=esc_attr($db['id'].'|'.$folder['slug']);
                    echo '<article class="kgdm-trash-entry" data-kgdm-trash-row data-search="'.esc_attr($search).'" data-trash-entry><label class="kgdm-trash-entry-select"><input type="checkbox" form="kgdm-trash-bulk-folders" name="selected[]" value="'.$token.'" data-trash-select-item="folders" aria-label="Select folder '.esc_attr($folder['name']).'"><span class="screen-reader-text">Select item</span></label><span class="kgdm-trash-entry-icon is-folder"><span class="dashicons dashicons-open-folder" aria-hidden="true"></span></span><div class="kgdm-trash-entry-copy"><strong>'.esc_html($folder['name']).'</strong><code>'.esc_html($db['name']).' · '.esc_html($folder['slug']).'</code><span class="kgdm-trash-entry-meta">'.count($subtree).' folders · '.(int)$records_total.' records retained'.(!empty($folder['trash_batch_id'])?' · grouped deletion':'').'</span><small>Last updated '.esc_html($folder['updated_at']??'—').'</small></div><div class="kgdm-trash-entry-actions">';
                    self::render_trash_action_form('kgdm_restore_collection','kgdm_restore_collection',array('database_id'=>$db['id'],'collection_slug'=>$folder['slug']),'Restore');
                    self::render_trash_action_form('kgdm_delete_collection','kgdm_delete_collection',array('database_id'=>$db['id'],'collection_slug'=>$folder['slug']),'Delete permanently','Permanently delete this folder and every nested folder, record, form revision and recovery snapshot? This cannot be undone.');
                    echo '</div></article>';
                }
                echo '</div><div class="kgdm-trash-page-summary">Showing '.(($folder_page-1)*$folder_per_page+1).'–'.min($folder_page*$folder_per_page,$folder_total).' of '.(int)$folder_total.' folders</div>';
                self::render_trash_pagination('trash_folder_paged',$folder_page,$folder_pages,$type,$selected_db,$trash_collection,$view);
            }
            echo '</section>';
        }

        // Records: independent pagination and bulk controls, with per-row restore/purge still available.
        if($type==='all'||$type==='records'){
            $record_per_page=20;$record_page=max(1,absint(self::admin_query_param('trash_record_paged',self::admin_query_param('trash_paged',1))));$record_total=(int)$counts['records'];$record_pages=max(1,(int)ceil($record_total/$record_per_page));$record_page=min($record_page,$record_pages);
            $record_rows=self::get_trashed_records($selected_db,$trash_collection,$record_per_page,($record_page-1)*$record_per_page);
            echo '<section class="kgdm-panel kgdm-trash-panel-modern"><div class="kgdm-trash-section-head"><div class="kgdm-trash-section-title"><span class="kgdm-trash-section-icon is-record"><span class="dashicons dashicons-list-view" aria-hidden="true"></span></span><div><h3>Records</h3><p>Deleted records stay recoverable while their database and folder remain active.</p></div></div><span class="kgdm-trash-section-total">'.(int)$record_total.' items</span></div>';
            if(empty($record_rows)){echo self::empty_state_html('dashicons-list-view','No records in Trash','Records moved to Trash will appear here.',array(),'kgdm-trash-empty');}
            else{
                self::render_trash_bulk_toolbar('records','kgdm-trash-bulk-records',$view,$selected_db,$trash_collection);
                echo '<div class="kgdm-trash-items" data-view="'.esc_attr($view).'" data-trash-items="records">';
                foreach($record_rows as $row){
                    $search=strtolower($row['item_name'].' '.$row['item_key'].' '.$row['database_name'].' '.$row['collection_name']);$token=esc_attr($row['database_id'].'|'.$row['collection_slug'].'|'.$row['item_key']);
                    echo '<article class="kgdm-trash-entry" data-kgdm-trash-row data-search="'.esc_attr($search).'" data-trash-entry><label class="kgdm-trash-entry-select"><input type="checkbox" form="kgdm-trash-bulk-records" name="selected[]" value="'.$token.'" data-trash-select-item="records" aria-label="Select record '.esc_attr($row['item_name']).'"><span class="screen-reader-text">Select item</span></label><span class="kgdm-trash-entry-icon is-record"><span class="dashicons dashicons-media-document" aria-hidden="true"></span></span><div class="kgdm-trash-entry-copy"><strong>'.esc_html($row['item_name']).'</strong><code>'.esc_html($row['item_key']).'</code><span class="kgdm-trash-entry-meta">'.esc_html($row['database_name']).' · '.esc_html($row['collection_name']).'</span><small>Last updated '.esc_html($row['updated_at']).'</small></div><div class="kgdm-trash-entry-actions">';
                    self::render_trash_action_form('kgdm_restore_record','kgdm_restore_record',array('database_id'=>$row['database_id'],'collection_slug'=>$row['collection_slug'],'record_id'=>$row['item_key']),'Restore');
                    self::render_trash_action_form('kgdm_purge_record','kgdm_purge_record',array('database_id'=>$row['database_id'],'collection_slug'=>$row['collection_slug'],'record_id'=>$row['item_key']),'Delete permanently','Permanently delete this record and its migration recovery snapshots? This cannot be undone.');
                    echo '</div></article>';
                }
                echo '</div><div class="kgdm-trash-page-summary">Showing '.(($record_page-1)*$record_per_page+1).'–'.min($record_page*$record_per_page,$record_total).' of '.(int)$record_total.' records'.($trash_collection!==''?' in this collection':'').'</div>';
                self::render_trash_pagination('trash_record_paged',$record_page,$record_pages,$type,$selected_db,$trash_collection,$view);
            }
            echo '</section>';
        }
        echo '<footer class="kgdm-trash-footnote"><span class="dashicons dashicons-shield-alt" aria-hidden="true"></span><span><strong>Permanent deletion is irreversible.</strong> Create a full KGDM backup before cleanup. KGDM does not delete WordPress posts, users, Media Library attachments or uploaded files. Bundled Genshin source entries use a hidden suppression marker after purge.</span></footer>';
        echo '</section>';
    }

    private static function render_workspace_trash_link($type, $database_id = '', $collection_slug = '') {
        $counts = self::get_trash_counts($database_id);
        $count = (int)($counts[$type] ?? array_sum($counts));
        $args = array('trash_type'=>$type);
        if ($database_id !== '') { $args['db'] = $database_id; }
        if ($type === 'records' && $collection_slug !== '') { $args['collection'] = $collection_slug; }
        echo '<a class="button kgdm-trash-action" href="'.esc_url(self::tab_url('trash',$args)).'"><span class="dashicons dashicons-trash" aria-hidden="true"></span> Trash <span class="kgdm-trash-count">'.$count.'</span></a>';
    }

    private static function render_tab_data_access($database, $selected_db) {
        $collections = $database ? self::get_collections($selected_db,false) : array();
        $collection = !empty($collections) ? $collections[0] : null;
        $db_code = $database ? $selected_db : 'your-database-id';
        $collection_code = $collection ? $collection['slug'] : 'your-collection';
        echo '<section class="kgdm-panel"><h2>Use saved data in PHP snippets</h2><p>Use the KGDM PHP API from snippets, theme templates, custom plugins and other code running inside this WordPress site. These calls stay inside WordPress; they do not require the public REST API.</p>';
        $get_example = '$record = kgdm()->get(' . self::php_single_quoted_literal($db_code) . ', ' . self::php_single_quoted_literal($collection_code) . ", 'record-id');\n\n";
        $get_example .= "if (\$record) {\n    echo esc_html(\$record['name'] ?? \$record['id'] ?? '');\n}";
        $find_example = '$records = kgdm()->find(' . self::php_single_quoted_literal($db_code) . ', ' . self::php_single_quoted_literal($collection_code) . ", array(\n    'where' => array('element' => 'Pyro'),\n    'order_by' => 'name',\n    'limit' => 20,\n    'cache' => true,\n));\n\n";
        $find_example .= "foreach (\$records as \$record) {\n    echo esc_html(\$record['name'] ?? '');\n}";
        $nested_example = '$records = kgdm()->find(' . self::php_single_quoted_literal($db_code) . ', ' . self::php_single_quoted_literal($collection_code) . ", array(\n    'where' => array(\n        'region' => 'Liyue',\n        'stats.hp' => array('operator' => 'gte', 'value' => 10000),\n    ),\n    'cache' => true,\n));";
        $helper_example = '$record = kgdm_get_record(' . self::php_single_quoted_literal($db_code) . ', ' . self::php_single_quoted_literal($collection_code) . ", 'record-id');\n// Existing helper functions remain supported.\n// kgdm()->get()/find() add the query and cache layer.";
        echo '<h3>Get one record</h3><div class="kgdm-code-block"><pre>'.esc_html($get_example).'</pre><button type="button" class="button kgdm-copy-code">Copy PHP snippet</button></div>';
        echo '<h3>Find records</h3><div class="kgdm-code-block"><pre>'.esc_html($find_example).'</pre><button type="button" class="button kgdm-copy-code">Copy PHP snippet</button></div>';
        echo '<h3>Find with nested fields</h3><div class="kgdm-code-block"><pre>'.esc_html($nested_example).'</pre><button type="button" class="button kgdm-copy-code">Copy PHP snippet</button></div>';
        echo '<h3>Existing helper functions</h3><div class="kgdm-code-block"><pre>'.esc_html($helper_example).'</pre><button type="button" class="button kgdm-copy-code">Copy PHP snippet</button></div>';
        echo '<p><strong>find() options:</strong> <code>where</code>, <code>search</code>, <code>order_by</code>, <code>order</code>, <code>limit</code>, <code>offset</code>, <code>section</code>, <code>include_deleted</code> (administrators only), <code>cache</code>.</p>';
        echo '<p><strong>where operators:</strong> exact value, <code>contains</code>, <code>in</code>, <code>not_in</code>, <code>exists</code>, <code>gt</code>, <code>gte</code>, <code>lt</code>, <code>lte</code>. Nested paths use dot notation such as <code>stats.hp</code>. Values are returned as PHP arrays from the stored JSON.</p>';
        echo '<p class="kgdm-muted">Caching uses the WordPress object-cache API and is enabled by default for get() and find(). Set cache = false on find() to bypass result caching. With Redis or Memcached, cached results can persist across requests; without a persistent object cache, they are reused within the current request. Cache entries are size-limited and invalidated by per-site, per-collection generation keys after record writes, migrations, restores and deletes.</p></section>';
        if ($database) {
            $status = ($database['api_access'] ?? 'private') === 'public';
            echo '<section class="kgdm-panel"><h3>REST endpoint links</h3><p>Public API is currently '.($status?'<strong>enabled</strong>':'<strong>private</strong>').' for this database. Change this in Settings. These are read-only endpoints.</p>';
            $urls = array(array('Collections', rest_url('kgdm/v1/databases/'.$selected_db.'/collections')));
            foreach ($collections as $c) { $urls[] = array($c['name'].' records', rest_url('kgdm/v1/databases/'.$selected_db.'/collections/'.$c['slug'])); }
            foreach ($urls as $endpoint) { echo '<div class="kgdm-endpoint"><span>'.esc_html($endpoint[0]).'</span><code>'.esc_html($endpoint[1]).'</code><a href="'.esc_url($endpoint[1]).'" target="_blank" rel="noopener">Test</a></div>'; }
            echo '</section>';
        }
    }

    private static function render_tab_import_export($database, $selected_db) {
        $backups = self::backup_index();
        uasort($backups, function($a, $b) { return strcmp((string)($b['created_at'] ?? ''), (string)($a['created_at'] ?? '')); });
        echo '<section class="kgdm-panel"><div class="kgdm-section-head"><div><h2>Full KGDM backup &amp; recovery</h2><p>Back up every KGDM database, collection, record, template revision, migration log and migration recovery snapshot on this WordPress site.</p></div><span class="kgdm-status kgdm-status-active">Site-wide</span></div>';
        echo '<p>Full backups are compressed and stored in a private KGDM backup directory. They include archived and soft-deleted data. Each archive has a SHA-256 checksum and is validated before restore. A fresh pre-restore backup is created automatically before existing KGDM tables are replaced.</p>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="kgdm-inline-form"><input type="hidden" name="action" value="kgdm_create_backup">'; wp_nonce_field('kgdm_create_backup'); echo '<button class="button button-primary">Create full backup now</button></form>';
        echo '<form method="post" enctype="multipart/form-data" action="'.esc_url(admin_url('admin-post.php')).'" class="kgdm-inline-form"><input type="hidden" name="action" value="kgdm_upload_backup">'; wp_nonce_field('kgdm_upload_backup'); echo '<label>Upload existing full backup (.json.gz)<input type="file" name="backup_file" accept=".gz,application/gzip" required></label><button class="button">Validate and add backup</button></form>';
        echo '<p class="kgdm-muted">Backup files are stored in a site-specific private directory under <code>wp-content</code> with Apache/IIS access-denial rules. On Nginx, add a server rule denying HTTP access to this directory, or use the <code>kgdm_backup_directory</code> filter to place backups outside the document root. Backup creation is local; copy downloaded files to a separate device or storage location for disaster recovery.</p>';
        if (!empty($backups)) {
            echo '<h3>Available recovery points</h3><div class="kgdm-table-wrap"><table class="widefat striped"><thead><tr><th>Created</th><th>Type</th><th>Size</th><th>Records / rows</th><th>Integrity</th><th>Actions</th></tr></thead><tbody>';
            foreach ($backups as $id => $entry) {
                $download_url = wp_nonce_url(admin_url('admin-post.php?action=kgdm_download_backup&backup_id=' . rawurlencode($id)), 'kgdm_download_backup');
                echo '<tr><td>'.esc_html((string)($entry['created_at'] ?? '')).'<br><small>'.esc_html((string)($entry['plugin_version'] ?? '')).'</small></td><td>'.esc_html(ucwords(str_replace('-', ' ', (string)($entry['purpose'] ?? 'backup')))).'</td><td>'.esc_html(size_format((int)($entry['size'] ?? 0))).'</td><td>';
                $counts = (array)($entry['row_counts'] ?? array());
                echo esc_html('DBs '.(int)($counts['databases'] ?? 0).' · folders '.(int)($counts['collections'] ?? 0).' · records '.(int)($counts['records'] ?? 0));
                echo '</td><td>'.(!empty($entry['warning_count']) ? '<span class="kgdm-status kgdm-status-archived">'.(int)$entry['warning_count'].' record warning(s)</span>' : '<span class="kgdm-status kgdm-status-active">Checksum verified</span>').'</td><td class="kgdm-actions"><a class="button button-small" href="'.esc_url($download_url).'">Download</a>';
                echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="kgdm-backup-restore-form"><input type="hidden" name="action" value="kgdm_restore_backup"><input type="hidden" name="backup_id" value="'.esc_attr($id).'">'; wp_nonce_field('kgdm_restore_backup');
                echo '<label class="kgdm-muted">Type RESTORE KGDM BACKUP <input type="text" name="restore_confirmation" autocomplete="off" required></label><button class="button button-secondary" onclick="return confirm(\'Restore all KGDM-managed tables from this backup? A pre-restore backup will be created first.\')">Restore</button></form>';
                echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="kgdm-inline-form"><input type="hidden" name="action" value="kgdm_delete_backup"><input type="hidden" name="backup_id" value="'.esc_attr($id).'">'; wp_nonce_field('kgdm_delete_backup'); echo '<button class="button button-link-delete" onclick="return confirm(\'Delete this backup file permanently?\')">Delete</button></form></td></tr>';
            }
            echo '</tbody></table></div>';
        } else {
            echo '<p class="description">No full recovery points have been created yet.</p>';
        }
        $last_error = get_option('kgdm_last_backup_error', '');
        if ($last_error !== '') { echo '<p class="notice notice-error inline"><strong>Last backup/recovery issue:</strong> '.esc_html((string)$last_error).'</p>'; }
        echo '<div class="kgdm-danger-zone"><strong>Restore scope:</strong> Full restore replaces only the six KGDM-owned tables and restores the saved active-database selection plus interface preferences. It preserves the current uninstall-deletion policy and plugin version markers. WordPress posts, pages, users, themes, plugin settings outside KGDM and Media Library attachments/files are not changed. Backup and restore both require all six KGDM tables to use InnoDB, so backups use a consistent database snapshot and restores can be rolled back atomically.</div></section>';

        echo '<div class="kgdm-two-col">';
        echo '<section class="kgdm-panel"><h2>Export JSON</h2>';
        if ($database) {
            echo '<p>Download a portable JSON export of '.esc_html($database['name']).', including collection schemas and active or deleted records.</p><a class="button button-primary" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=kgdm_export&database_id='.rawurlencode($selected_db)),'kgdm_export_database')).'">Download selected database</a>';
        } else {
            echo '<p>Create a database first. Export becomes available after a database exists.</p>';
        }
        echo '<p><a href="'.esc_url(plugins_url('templates/blank-database-template.json', __FILE__)).'">Download blank JSON structure</a></p></section>';
        echo '<section class="kgdm-panel"><h2>Import custom JSON</h2><p>Paste a valid KGDM database JSON document or upload a .json file. The entire file is validated before any database data is changed.</p><form id="kgdm-import-form" method="post" enctype="multipart/form-data" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="kgdm_import">'; wp_nonce_field('kgdm_import_database');
        echo '<label>Paste JSON<textarea id="kgdm-import-json" name="import_json" rows="12" class="large-text code" placeholder="Paste your KGDM database JSON here. You may also upload a file below."></textarea></label><label>Or upload JSON file<input type="file" name="import_file" accept=".json,application/json"></label><p><button type="button" id="kgdm-validate-json" class="button">Validate JSON</button> <span id="kgdm-json-validation" role="status" class="kgdm-muted"></span></p><fieldset><legend>Import mode</legend><label class="kgdm-radio"><input type="radio" name="import_mode" value="merge" checked> Merge records</label><label class="kgdm-radio"><input type="radio" name="import_mode" value="replace"> Replace managed records in the target database</label></fieldset><button class="button button-primary">Import validated JSON</button></form></section></div>';
        if ($database) {
            $validation_url = wp_nonce_url(admin_url('admin-post.php?action=kgdm_validate_json_storage&database_id=' . rawurlencode($database['id'])), 'kgdm_validate_json_storage');
            echo '<section class="kgdm-panel"><h3>JSON storage integrity</h3><p>Validate every saved record payload, SHA-256 integrity hash, storage version and JSON format without changing data. Create a full backup before attempting record-level correction or restoring an older recovery point.</p><a class="button" href="' . esc_url($validation_url) . '">Validate saved JSON</a></section>';
        }
        echo '<section class="kgdm-panel"><h3>Accepted JSON structure</h3><p>Use <code>format: kgdm-database</code> and <code>format_version: 1</code>. Add one database definition, an array of collections, each collection’s fields, and its records. Every record must have a unique <code>id</code>. An empty collections array is valid. The importer also accepts V2.1 backup files for backward compatibility.</p><p class="kgdm-muted">File size limit: 25 MB. Invalid field types, duplicate collection IDs, duplicate record IDs and missing required values reject the entire import. No partial import is performed.</p></section>';
    }

    private static function render_tab_settings($database, $selected_db) {
        $settings = self::get_settings();
        $api_access = $database ? ($database['api_access'] ?? 'private') : 'private';
        echo '<section class="kgdm-panel"><div class="kgdm-section-head"><div><h2>Workspace display</h2><p>Adjust spacing and guidance for the workspace.</p></div></div><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="kgdm_save_settings"><input type="hidden" name="database_id" value="'.esc_attr($selected_db).'">'; wp_nonce_field('kgdm_save_settings');
        echo '<p class="description">Use the grouped workspace navigation to move between database, data tools and system sections. It adapts to smaller screens.</p>';
        echo '<fieldset class="kgdm-settings-options kgdm-appearance-settings"><legend><strong>Appearance</strong></legend><p class="description">Choose how the KGDM workspace looks. System follows your operating system or device preference and updates automatically.</p><div class="kgdm-theme-options" role="radiogroup" aria-label="Workspace appearance">';
        $appearance_options = array(
            'system' => array('System', 'Follows device preference', 'desktop'),
            'light' => array('Light', 'Always use light appearance', 'sun'),
            'dark' => array('Dark', 'Always use dark appearance', 'moon'),
        );
        foreach ($appearance_options as $mode => $option) {
            echo '<label class="kgdm-theme-option'.(($settings['appearance_mode'] ?? 'system') === $mode ? ' is-selected' : '').'"><input type="radio" name="appearance_mode" value="'.esc_attr($mode).'" '.checked(($settings['appearance_mode'] ?? 'system'),$mode,false).'><span class="kgdm-theme-option-copy"><strong>'.esc_html($option[0]).'</strong><small>'.esc_html($option[1]).'</small></span></label>';
        }
        echo '</div></fieldset><fieldset class="kgdm-settings-options"><legend><strong>Workspace density</strong></legend><label class="kgdm-radio"><input type="checkbox" name="compact_ui" value="1" '.checked(!empty($settings['compact_ui']),true,false).'> Compact spacing</label><label class="kgdm-radio"><input type="checkbox" name="show_help" value="1" '.checked(!empty($settings['show_help']),true,false).'> Show helper text and guidance</label></fieldset><fieldset class="kgdm-settings-options kgdm-danger-settings"><legend><strong>Plugin uninstall data policy</strong></legend>';
        $uninstall_enabled = !empty($settings['delete_data_on_uninstall']);
        echo '<p><strong>Default policy: Keep all data.</strong> Deactivating KG Database Management never deletes records, templates, migrations or settings.</p>';
        echo '<label class="kgdm-radio"><input id="kgdm-delete-on-uninstall" type="checkbox" name="delete_data_on_uninstall" value="1" data-already-enabled="'.($uninstall_enabled ? '1' : '0').'" '.checked($uninstall_enabled,true,false).'> Enable permanent deletion of KGDM data when this plugin is uninstalled</label>';
        echo '<label class="kgdm-uninstall-confirm-label" for="kgdm-delete-data-confirmation">Confirmation phrase <input id="kgdm-delete-data-confirmation" type="text" name="delete_data_confirmation" value="" autocomplete="off" spellcheck="false" placeholder="Type DELETE KGDM DATA to enable"></label>';
        echo '<p class="description">To enable this policy for the first time, enter exactly <code>DELETE KGDM DATA</code> and save. Once enabled, deleting the plugin permanently removes all six KGDM tables, KGDM-prefixed options and transients, legacy KGDM migration data, local KGDM backup archives and plugin cache state for this site. A fresh installation starts with empty tables, default settings and a new cache namespace. In multisite, the uninstall handler checks each site’s own setting.</p>';
        echo '<p class="description"><strong>Not deleted:</strong> WordPress Media Library attachments/files, uploaded images, posts, pages, users, themes, other plugins’ data, and unrelated database tables/options. Custom backup directories outside KGDM’s protected local backup folder are retained unless you manage those separately.</p>';
        echo '<p class="description">Export a JSON backup and a full WordPress database backup before enabling permanent deletion. Disabling this setting returns the policy to data preservation.</p></fieldset>';

        echo '<div class="kgdm-settings-api"><h3>REST API access</h3>';
        if ($database) {
            echo '<p>Selected database: <strong>'.esc_html($database['name']).'</strong></p><label class="kgdm-radio"><input type="checkbox" name="public_api_enabled" value="1" '.checked($api_access,'public',false).'> Allow public read-only REST API access for this database</label><p class="kgdm-muted">When disabled, WordPress snippets can still read the database. When enabled, unauthenticated visitors can read active records through its REST endpoints. No public write endpoints are provided.</p>';
        } else {
            echo '<p>Create or select a database before configuring REST API access.</p>';
        }
        echo '</div><p><button class="button button-primary">Save settings</button></p></form></section>';
        echo '<section class="kgdm-panel"><h3>Performance and privacy</h3><ul><li>Admin CSS and JavaScript load only on the KG Database Management screen.</li><li>No third-party libraries, external requests, scheduled jobs or front-end assets are required.</li><li>Database records remain in your WordPress database.</li><li>REST access is private by default.</li></ul></section>';
    }

    private static function render_tab_updates() {
        echo '<section class="kgdm-panel kgdm-update-log-panel"><div class="kgdm-section-head"><div><h2>Plugin update log</h2><p>Release notes, improvements and fixes, with the latest release first.</p></div><div class="kgdm-update-log-tools"><span class="kgdm-status kgdm-status-active">Version '.esc_html(self::VERSION).'</span><div class="kgdm-update-log-view" role="group" aria-label="Release display mode"><button type="button" class="button button-primary" data-update-log-mode="list" aria-pressed="true"><span class="dashicons dashicons-list-view" aria-hidden="true"></span> List</button><button type="button" class="button" data-update-log-mode="grid" aria-pressed="false"><span class="dashicons dashicons-grid-view" aria-hidden="true"></span> Grid</button></div></div></div>';
        echo '<ol class="kgdm-release-timeline is-list-view" data-view="list" aria-label="Plugin release history">';
        foreach (self::changelog() as $entry) {
            echo '<li class="kgdm-release-entry"><article><header><div><h3>Version '.esc_html($entry['version']).' — '.esc_html($entry['title']).'</h3><time datetime="'.esc_attr($entry['date']).'">'.esc_html($entry['date']).'</time></div></header><ul>';
            foreach ($entry['items'] as $item) { echo '<li>'.esc_html($item).'</li>'; }
            echo '</ul></article></li>';
        }
        echo '</ol></section>';

        $upgrade = get_option('kgdm_upgrade_state', array());
        if (!is_array($upgrade)) { $upgrade = array(); }
        $history = get_option(self::UPDATE_HISTORY_OPTION, array());
        if (!is_array($history)) { $history = array(); }
        $ledger = get_option(self::RELEASE_MIGRATION_OPTION, array());
        if (!is_array($ledger)) { $ledger = array(); }
        $installed_release = (string)get_option(self::PLUGIN_VERSION_OPTION, 'Not recorded');
        $installed_schema = (string)get_option(self::SCHEMA_OPTION, 'Not recorded');
        $installed_engine = (int)get_option('kgdm_migration_engine_version', 0);
        $status = (string)($upgrade['status'] ?? 'not_run');
        $success = $status === 'complete';
        echo '<section class="kgdm-panel"><div class="kgdm-section-head"><div><h2>Plugin update migration engine</h2><p>Plugin releases and WordPress storage schema are tracked and migrated independently.</p></div><span class="kgdm-status kgdm-status-active">Current release '.esc_html(self::VERSION).'</span></div>';
        echo '<div class="kgdm-update-version-grid"><div><span>Installed plugin release</span><strong>'.esc_html($installed_release).'</strong></div><div><span>Installed storage schema</span><strong>'.esc_html($installed_schema).'</strong></div><div><span>JSON storage format</span><strong>'.(int)self::JSON_STORAGE_VERSION.'</strong></div><div><span>Installed migration engine</span><strong>'.(int)$installed_engine.' / '.(int)self::MIGRATION_ENGINE_VERSION.'</strong></div></div>';
        if (!empty($upgrade['status'])) {
            $state_class = $success ? 'is-success' : ($status === 'failed' ? 'is-warning' : 'is-running');
            $state_title = $success ? 'Plugin update verified' : ($status === 'failed' ? 'Plugin update needs attention' : 'Plugin update in progress');
            echo '<div class="kgdm-upgrade-state '.esc_attr($state_class).'"><strong>'.esc_html($state_title).'</strong><p>'.esc_html($upgrade['message'] ?? '').'</p>';
            if (!empty($upgrade['plugin_from']) || !empty($upgrade['plugin_to'])) { echo '<small>Plugin: '.esc_html(($upgrade['plugin_from'] ?: 'new').' → '.($upgrade['plugin_to'] ?? self::VERSION)).'</small><br>'; }
            if (!empty($upgrade['from']) || !empty($upgrade['to'])) { echo '<small>Schema: '.esc_html(($upgrade['from'] ?: 'new').' → '.($upgrade['to'] ?? self::SCHEMA_VERSION)).'</small>'; }
            if (!empty($upgrade['current_step'])) { echo '<br><small>Current step: <code>'.esc_html($upgrade['current_step']).'</code></small>'; }
            if (!empty($upgrade['finished_at'])) { echo '<br><small>Last attempt: '.esc_html($upgrade['finished_at']).'</small>'; }
            echo '</div>';
        } else {
            echo '<p class="kgdm-muted">No update migration has run on this installation yet.</p>';
        }
        $update_needed = ($installed_release !== self::VERSION || $installed_schema !== self::SCHEMA_VERSION || $installed_engine !== self::MIGRATION_ENGINE_VERSION || $status !== 'complete');
        if ($update_needed) {
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="kgdm-update-retry-form"><input type="hidden" name="action" value="kgdm_retry_upgrade">';
            wp_nonce_field('kgdm_retry_upgrade');
            echo '<button class="button button-primary">Retry update verification</button><span class="description">Use this after resolving a database or hosting issue. The migration engine skips completed steps and safely retries failed steps.</span></form>';
        }
        echo '</section>';

        echo '<section class="kgdm-panel"><h3>Release migration ledger</h3><p>Each release migration is recorded separately. Completed steps are not replayed, while failed steps remain eligible for a controlled retry.</p>';
        if (empty($ledger)) {
            echo '<p class="kgdm-muted">No release-level migration steps are recorded.</p>';
        } else {
            echo '<div class="kgdm-table-wrap"><table class="widefat striped"><thead><tr><th>Migration</th><th>Release</th><th>Status</th><th>Attempts</th><th>Last message</th></tr></thead><tbody>';
            foreach ($ledger as $migration_id => $entry) {
                if (!is_array($entry)) { continue; }
                echo '<tr><td><code>'.esc_html($migration_id).'</code><br>'.esc_html($entry['label'] ?? '').'</td><td>'.esc_html($entry['version'] ?? '').'</td><td>'.esc_html(ucwords(str_replace('_',' ',(string)($entry['status'] ?? 'unknown')))).'</td><td>'.(int)($entry['attempts'] ?? 0).'</td><td>'.esc_html($entry['message'] ?? '').'</td></tr>';
            }
            echo '</tbody></table></div>';
        }
        echo '</section>';

        echo '<section class="kgdm-panel"><h3>Recent update history</h3>';
        if (empty($history)) {
            echo '<p class="kgdm-muted">No update history has been recorded.</p>';
        } else {
            echo '<div class="kgdm-table-wrap"><table class="widefat striped"><thead><tr><th>Date</th><th>Type</th><th>Step</th><th>Version path</th><th>Status</th><th>Details</th></tr></thead><tbody>';
            foreach (array_slice($history, 0, 20) as $entry) {
                if (!is_array($entry)) { continue; }
                echo '<tr><td>'.esc_html($entry['timestamp'] ?? '').'</td><td>'.esc_html(ucwords(str_replace('_',' ',(string)($entry['type'] ?? 'update')))).'</td><td><code>'.esc_html($entry['step'] ?? '').'</code></td><td>'.esc_html(($entry['from'] ?? '').' → '.($entry['to'] ?? '')).'</td><td>'.esc_html(ucwords((string)($entry['status'] ?? 'unknown'))).'</td><td>'.esc_html($entry['message'] ?? '').'</td></tr>';
            }
            echo '</tbody></table></div>';
        }
        echo '</section>';

    }

    private static function render_tab_about() {
        global $wpdb;
        $tables = self::table_names();
        echo '<section class="kgdm-panel"><div class="kgdm-about-brand"><span class="dashicons dashicons-database"></span><div><h2>KG Database Management</h2><p>Empty-by-default structured data management for WordPress.</p></div><span class="kgdm-status kgdm-status-active">Version '.esc_html(self::VERSION).'</span></div><p>Manage independent databases for games, applications, catalogues, knowledge bases, research projects and other structured datasets. Collections describe record types, while records store the data used by your shortcodes, templates and integrations.</p></section>';
        echo '<div class="kgdm-two-col"><section class="kgdm-panel"><h3>System information</h3><table class="widefat striped"><tbody><tr><th>Plugin version</th><td>'.esc_html(self::VERSION).'</td></tr><tr><th>Database schema</th><td>'.esc_html(self::SCHEMA_VERSION).'</td></tr><tr><th>Migration engine</th><td>'.(int)self::MIGRATION_ENGINE_VERSION.'</td></tr><tr><th>WordPress</th><td>'.esc_html(get_bloginfo('version')).'</td></tr><tr><th>PHP</th><td>'.esc_html(PHP_VERSION).'</td></tr><tr><th>Storage</th><td>WordPress MySQL / MariaDB</td></tr><tr><th>Database table</th><td><code>'.esc_html($tables['databases']).'</code></td></tr><tr><th>Collection table</th><td><code>'.esc_html($tables['collections']).'</code></td></tr><tr><th>Record table</th><td><code>'.esc_html($tables['records']).'</code></td></tr><tr><th>Template history table</th><td><code>'.esc_html($tables['template_versions']).'</code></td></tr><tr><th>Migration log table</th><td><code>'.esc_html($tables['migrations']).'</code></td></tr><tr><th>Migration recovery table</th><td><code>'.esc_html($tables['migration_records']).'</code></td></tr></tbody></table></section>';
        echo '<section class="kgdm-panel"><h3>Capabilities</h3><ul class="kgdm-feature-list"><li>Multiple isolated datasets</li><li>Custom collections and record fields</li><li>Record create, edit, soft-delete and restore</li><li>JSON import and export</li><li>PHP functions for WordPress snippets</li><li>Optional read-only public REST API</li><li>Optional compatibility adapter for legacy Genshin master data</li><li>Role-protected admin actions and nonce validation</li></ul></section></div>';
        echo '<section class="kgdm-panel"><h3>Data ownership and access</h3><p>Data is saved in your own website’s WordPress database. The manager does not send records to an external service. WordPress backups that include the database will include these tables. Other site snippets can read records through the documented <code>kgdm_*</code> PHP functions.</p><p>Public REST API access is optional and disabled by default for every database. When enabled, it is read-only and returns active records only. Admin create, edit and delete actions remain restricted to authorized WordPress administrators.</p><p><a href="'.esc_url(self::tab_url('update-log')).'">View plugin update log</a></p></section>';
    }

    public function render_admin_page() {
        self::require_admin();
        $databases = self::get_databases(true);
        $selected_db = sanitize_key(self::admin_query_param('db', get_option(self::ACTIVE_DB_OPTION, '')));
        $database = $selected_db !== '' ? self::get_database($selected_db, true) : null;
        if (!$database && !empty($databases)) { $database = $databases[0]; $selected_db = $database['id']; }

        $page_slug = sanitize_key(self::admin_query_param('page', self::MENU_SLUG));
        $requested_tab = sanitize_key(self::admin_query_param('tab', self::tab_for_page_slug($page_slug)));
        $help_section = sanitize_key(self::admin_query_param('help_section', 'overview'));
        if (in_array($requested_tab, array('update-log','updates'), true)) { $help_section = 'updates'; }
        $tab_aliases = array('dashboard'=>'databases','data-access'=>'developer','about'=>'help','update-log'=>'help','updates'=>'help');
        $tab = $tab_aliases[$requested_tab] ?? $requested_tab;
        // Keep the legacy inline Trash URLs working while routing them to the shared Trash controller.
        if ($requested_tab === 'collections' && sanitize_key(self::admin_query_param('view','')) === 'trash') { $tab = 'trash'; $_GET['trash_type'] = 'folders'; }
        if ($requested_tab === 'records' && sanitize_key(self::admin_query_param('view','')) === 'deleted') { $tab = 'trash'; $_GET['trash_type'] = 'records'; }
        $nav_groups = array(
            'Workspace' => array(
                'databases' => array('label'=>'Databases','icon'=>'dashicons-database','description'=>'Create databases, choose the active workspace and manage database-level settings.'),
                'collections' => array('label'=>'Folders & forms','icon'=>'dashicons-open-folder','description'=>'Organize collection folders and design reusable record forms.'),
                'records' => array('label'=>'Records','icon'=>'dashicons-list-view','description'=>'Create, search, edit, restore and organize records.'),
                'completeness' => array('label'=>'Completeness','icon'=>'dashicons-yes-alt','description'=>'Audit required fields, template assignments and missing data.'),
                'trash' => array('label'=>'Trash','icon'=>'dashicons-trash','description'=>'Restore archived databases, folders and records, or permanently delete them.'),
            ),
            'Data tools' => array(
                'import-export' => array('label'=>'Import / Export','icon'=>'dashicons-database-import','description'=>'Move database packages, create backups and restore KGDM data safely.'),
                'developer' => array('label'=>'Developer','icon'=>'dashicons-editor-code','description'=>'Use the PHP query API, code examples and integration references.'),
            ),
            'System' => array(
                'settings' => array('label'=>'Settings','icon'=>'dashicons-admin-settings','description'=>'Configure workspace behavior, API access and uninstall data policy.'),
                'help' => array('label'=>'Help & updates','icon'=>'dashicons-editor-help','description'=>'Read plugin information, system details, release notes and update status.'),
            ),
        );
        $nav_items = array();
        foreach ($nav_groups as $group_label => $items) {
            foreach ($items as $key => $item) {
                $item['group'] = $group_label;
                $nav_items[$key] = $item;
            }
        }
        if (!isset($nav_items[$tab])) { $tab = 'databases'; }
        if (!in_array($help_section, array('overview','updates'), true)) { $help_section = 'overview'; }

        $settings = self::get_settings();
        $appearance_mode = in_array(($settings['appearance_mode'] ?? 'system'), array('system','light','dark'), true) ? $settings['appearance_mode'] : 'system';
        $root_classes = 'kgdm-wrap kgdm-modern-layout kgdm-theme-' . $appearance_mode . (!empty($settings['compact_ui']) ? ' kgdm-compact' : '') . (empty($settings['show_help']) ? ' kgdm-hide-help' : '');
        echo '<div class="wrap '.esc_attr($root_classes).'">';
        if (self::admin_query_param('notice') !== '') {
            $message=self::notice_text(sanitize_key(self::admin_query_param('notice')));
            if($message!==''){echo '<div class="notice notice-info is-dismissible"><p>'.esc_html($message).'</p></div>';}
        }

        echo '<div class="kgdm-workspace"><main class="kgdm-main-content" tabindex="-1">';
        $active_item = $nav_items[$tab];
        echo '<header class="kgdm-view-header"><div class="kgdm-view-header-copy"><span class="kgdm-view-eyebrow">'.esc_html($active_item['group']).'</span><h2>'.esc_html($active_item['label']).'</h2><p>'.esc_html($active_item['description']).'</p></div><div class="kgdm-view-header-actions">';
        if (!in_array($tab, array('help','databases'), true)) { self::render_database_picker($databases,$selected_db,$tab); }
        $theme_label = ($appearance_mode === 'dark') ? 'Switch to light mode' : 'Switch to dark mode';
        echo '<button type="button" id="kgdm-theme-toggle" class="kgdm-theme-toggle" data-mode="'.esc_attr($appearance_mode).'" data-ajax-url="'.esc_url(admin_url('admin-ajax.php')).'" data-nonce="'.esc_attr(wp_create_nonce('kgdm_set_appearance')).'" aria-label="'.esc_attr($theme_label).'" title="'.esc_attr($theme_label).'" aria-pressed="'.($appearance_mode === 'dark' ? 'true' : 'false').'"><svg class="kgdm-theme-toggle-icon kgdm-theme-toggle-sun" data-theme-icon="light" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.93 4.93l1.42 1.42m11.3 11.3 1.42 1.42M2 12h2m16 0h2M4.93 19.07l1.42-1.42m11.3-11.3 1.42-1.42"/></svg><svg class="kgdm-theme-toggle-icon kgdm-theme-toggle-moon" data-theme-icon="dark" viewBox="0 0 24 24" aria-hidden="true" hidden><path d="M20.3 15.2A8.6 8.6 0 0 1 8.8 3.7 8.7 8.7 0 1 0 20.3 15.2Z"/><path d="M16.7 3.2v3.1m-1.55-1.55h3.1"/></svg><span class="screen-reader-text">'.esc_html($theme_label).'</span></button>';
        echo '</div></header>';
        self::render_workspace_workflow($tab, $database, $selected_db);

        if ($tab === 'help') {
            echo '<nav class="kgdm-help-nav" aria-label="Help and updates"><a class="'.($help_section==='overview'?'is-active':'').'" href="'.esc_url(self::tab_url('help',array('db'=>$selected_db,'help_section'=>'overview'))).'"'.($help_section==='overview'?' aria-current="page"':'').'><span class="dashicons dashicons-book" aria-hidden="true"></span> Help & system info</a><a class="'.($help_section==='updates'?'is-active':'').'" href="'.esc_url(self::tab_url('help',array('db'=>$selected_db,'help_section'=>'updates'))).'"'.($help_section==='updates'?' aria-current="page"':'').'><span class="dashicons dashicons-update" aria-hidden="true"></span> Release notes & updates</a></nav>';
            if ($help_section === 'updates') { self::render_tab_updates(); }
            else { self::render_tab_about(); }
        } else {
            switch ($tab) {
                case 'databases': self::render_tab_databases($databases,$database,$selected_db); break;
                case 'collections': self::render_tab_collections($database,$selected_db); break;
                case 'records': self::render_tab_records($database,$selected_db); break;
                case 'completeness': self::render_tab_completeness($database,$selected_db); break;
                case 'trash': self::render_trash_workspace($selected_db); break;
                case 'developer': self::render_tab_data_access($database,$selected_db); break;
                case 'import-export': self::render_tab_import_export($database,$selected_db); break;
                case 'settings': self::render_tab_settings($database,$selected_db); break;
                default: self::render_tab_databases($databases,$database,$selected_db); break;
            }
        }
        echo '</main></div><p class="kgdm-footer">KG Database Management · '.esc_html(self::VERSION).' · WordPress admin workspace</p></div>';
    }

}

register_activation_hook(__FILE__, array('KG_Database_Management', 'activate'));
KG_Database_Management::boot();

if (!function_exists('kgdm')) {
    function kgdm() { return KG_Database_Management::boot(); }
}
if (!function_exists('kgdm_get')) {
    function kgdm_get($database_id, $collection_slug, $record_id, $args = array()) { return kgdm()->get($database_id, $collection_slug, $record_id, $args); }
}
if (!function_exists('kgdm_find')) {
    function kgdm_find($database_id, $collection_slug, $args = array()) { return kgdm()->find($database_id, $collection_slug, $args); }
}

if (!function_exists('kgdm_get_databases')) {
    function kgdm_get_databases($include_archived = false) { return KG_Database_Management::api_get_databases($include_archived); }
}
if (!function_exists('kgdm_get_database')) {
    function kgdm_get_database($database_id = null) { return KG_Database_Management::api_get_database($database_id); }
}
if (!function_exists('kgdm_get_collections')) {
    function kgdm_get_collections($database_id = null, $include_archived = false) { return KG_Database_Management::api_get_collections($database_id, $include_archived); }
}
if (!function_exists('kgdm_get_records')) {
    function kgdm_get_records($database_id, $collection_slug, $args = array()) { return KG_Database_Management::api_get_records($database_id, $collection_slug, $args); }
}
if (!function_exists('kgdm_get_record')) {
    function kgdm_get_record($database_id, $collection_slug, $record_id) { return KG_Database_Management::api_get_record($database_id, $collection_slug, $record_id); }
}

}
