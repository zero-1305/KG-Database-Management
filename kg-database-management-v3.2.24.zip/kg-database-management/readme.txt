=== KG Database Management ===

== Version 3.2.24 ==
* Removed the 1,500px `.kgdm-wrap` width cap and the 1,600px `.kgdm-modern-layout` width cap. Both now use `width:100%`, `max-width:none` and `min-width:0` within the WordPress admin content area, including the higher-specificity `#wpbody-content` wrapper rule.
* Added a shared button layout template for KGDM anchor and button controls using inline-flex, centered cross-axis alignment, consistent icon/text gaps, predictable minimum heights and responsive padding.
* Standardized Dashicons, SVG and image icon sizing inside buttons without applying flex alignment or vertical-align rules to the Dashicons glyph itself.
* Kept input-based buttons and compact component-specific controls compatible with their existing behavior and sizing.
* Preserved button variants, destinations, form submissions, AJAX actions and all existing database, Trash, record, backup and theme behavior.
* No database schema, JSON storage, REST API or migration changes.

== Version 3.2.23 ==
* Rebuilt Trash as a modern recovery center with clearer guidance, category summaries, scoped search, layout controls and responsive section cards.
* Added a shared List / Grid layout switch for Databases, Folders & forms and Records in Trash.
* Added single-item checkboxes, select-this-page controls and bulk Restore / Delete permanently actions for all three Trash categories. Bulk permanent deletion requires an additional confirmation and uses the same validation rules as single-item actions.
* Added independent pagination for databases, folders and records, with 20 entries per page and preserved category, database, collection and layout context.
* Added shared, transaction-safe bulk action services for database, folder-subtree and record restore/purge. Folder parent/child safeguards, migration snapshot cleanup and Genshin source tombstones remain in effect.
* Added accessible selected counts, page selection state, clearer item metadata and mobile-friendly action layouts.
* No storage schema, record format, public API or JSON import/export format changes.

== Version 3.2.22 ==
* Removed `align-items: center` and `vertical-align: middle` from the broad `.kgdm-modern-layout .dashicons` normalization rule; Dashicons now retain their natural inline alignment unless a specific component intentionally defines a flex alignment.
* Expanded the KGDM wrapper to the full available WordPress content width and viewport height, replacing the previous 1,500/1,600px content cap.
* Added a responsive full-height flex layout using `min-height` rather than fixed height, allowing long forms, tables, builders and modals to grow and scroll normally.
* Added width/overflow safeguards for the folder workspace, panels, tables, code blocks and media on desktop, tablet and mobile breakpoints.
* No database schema, record format, PHP API, import/export, Trash, backup, appearance preference or uninstall behavior changes.

== Version 3.2.21 ==
* Removed the redundant KGDM page-level brand header from workspace views.
* Moved the database picker into the right side of the view header and added a compact Light/Dark theme quick toggle.
* Added an administrator-only, nonce-protected AJAX handler that saves only the appearance preference while preserving other settings.
* Preserved System mode as the default; the quick toggle switches the resolved current appearance to explicit Light or Dark. Return to System from Settings.
* Restyled record breadcrumbs with database/folder hierarchy, accessible current-page semantics and responsive wrapping.
* Rebuilt the bulk-edit toolbar with a clear heading, grouped controls, consistent inputs and responsive layouts.
* No storage schema, record format, import/export, Trash, backup, publication or REST behavior changes.

== Version 3.2.18 ==
* Moved all KGDM workspace destinations into the native WordPress admin submenu: Databases, Folders & forms, Records, Completeness, Trash, Import / Export, Developer, Settings and Help & updates.
* Removed the duplicate in-page KGDM sidebar so the WordPress admin navigation is the single global navigation source.
* Routed internal navigation, database picker changes and admin-post redirects through the appropriate native submenu page while retaining legacy ?page=...&tab=... URLs.
* Enqueued KGDM styles, scripts and Dashicons on every registered submenu page, including media controls when the selected collection contains media fields.
* Rebuilt Workspace Flow as a responsive four-step guide with clear step labels, concise descriptions, current/next states, selected database/folder context, and a single contextual Continue action.
* Disabled folder, record and completeness steps when no active database is available, with clear guidance to choose or restore a database first.
* No storage schema, record payload, public PHP API, JSON format, Trash, backup, migration or uninstall behavior changes.

== Version 3.2.17 ==
* Added shared metric-card, completeness-counter, empty-state and image-placeholder renderers for consistent UI components across the plugin.
* Reduced database overview record-count queries to one grouped SQL query for standard databases, while preserving the bundled Genshin source/override/tombstone behavior.
* Centralized attachment thumbnails through WordPress responsive image helpers with srcset, intrinsic dimensions, lazy loading, asynchronous decoding and low fetch priority.
* Hardened client-side Media Library previews to accept HTTP(S) URLs only and replaced placeholder HTML strings with safe DOM construction.
* Added shared card styling tokens, responsive empty-state actions and reduced-motion support.
* No database schema, record format, PHP API, import/export, Trash, backup or uninstall behavior changes.

== Version 3.2.16 ==
* Added Light, Dark and System appearance modes in Settings. System is the default and follows the device operating-system preference automatically.
* Applied shared theme color tokens and dark-mode styling across database cards, folder navigation, form builders, records, completeness tables, import/export, settings, modals and developer/help panels.
* Added live appearance preview before saving and preserved the selected appearance in full KGDM backup/restore.
* Hardened the explicit uninstall cleanup to remove KGDM-owned tables, options, transients, legacy bridge data and protected local backups; plugin deactivation still preserves all data.
* Added an installation-generation cache namespace so persistent object-cache entries from an older, deleted installation cannot appear after a clean reinstall.
* A reinstall after enabling permanent deletion starts with empty KGDM tables and default settings, with the uninstall deletion policy reset to OFF.
* No WordPress content, users, themes, unrelated plugin data or Media Library attachments/files are removed.

== Version 3.2.15 ==
* Added one shared Trash workspace for Databases, Folders & forms and Records, with category tabs and contextual links from all four Workspace sections, including Completeness.
* Standardized soft-delete wording to Move to Trash and added Restore and Delete permanently actions for databases, folder groups and records.
* Added transaction-protected permanent deletion for archived databases and trashed records, including KGDM-owned templates, migrations and recovery snapshots.
* Added grouped folder Trash behavior: moving a parent folder archives its active descendants together; independently trashed child subtrees keep their state and remain hidden until the parent is restored.
* Prevented restoring or permanently deleting a child while an ancestor is still in Trash.
* Preserved folder Trash group IDs in database JSON export/import and added collection-scoped Trash filtering with accurate SQL counts.
* Advanced the storage schema to 2.7.0 with a collection trash_batch_id column; the update engine adds it automatically, and older full backups are normalized on restore.
* Permanent deletion is limited to KGDM-owned data and never deletes WordPress posts, users or Media Library attachments. When a bundled Genshin source entry is purged, KGDM removes its managed payload and leaves a minimal hidden suppression marker while that KGDM database and collection remain; the external source provider is not modified.

== Version 3.2.14 ==
* Replaced repeated workflow labels, step cards and breadcrumbs with one compact progress bar; the grouped sidebar is the single navigation source.
* Removed the duplicate Current database badge and repeated Database library count while preserving context-aware database switching.
* Made the folder tree navigation-only; folder editing is available from the selected-folder panel or content card, not repeated in the tree.
* Removed the extra Records-to-Completeness shortcut; the sidebar route preserves the selected collection.
* Removed the duplicate record-editor Close button and kept the footer Cancel action as the single dismissal control.
* Restored visibility of the Trash empty-state Back to folders action by removing an overbroad CSS hide rule.
* No database schema, record, API, import/export, backup, migration or uninstall behavior changes.

== Version 3.2.13 ==
* Added clickable overview metrics for active databases, folders, active records and KGDM storage usage.
* Database overview metrics route directly to the relevant Databases, Folders & forms, Records or Import / Export screens.
* Added direct database-name links and retained whole-card navigation with separate Settings actions.
* Enqueued the official WordPress Dashicons stylesheet on the KGDM admin screen and replaced unsupported icon classes with valid Dashicons.
* Improved responsive metric-card layouts and consistent icon alignment.
* No database schema, record payload, public API, JSON storage, import/export or backup format changes.

Contributors: kg
Tags: database, records, collections, json, rest-api
Requires at least: 7.0
Requires PHP: 7.4
Tested up to: 7.1
Stable tag: 3.2.24
License: GPL-2.0-or-later

A structured, template-driven database manager for WordPress.


== Version 3.2.20 ==
* Fixed database background-image CSS URL output so selected Media Library backgrounds render correctly on database cards.
* Preserved existing database icon/background attachments when a settings editor does not have the upload_files capability; users without media permission can still update name, description and colours without clearing existing images.
* Added safe public REST visual metadata for databases and folders, including dashicon, colors and public image URLs without exposing internal attachment IDs.
* Added hierarchical section definitions to public REST collection responses and a `section` query parameter to public REST record filtering.
* Added strict show/hide date validation to the AJAX record editor, admin form handler, shared record writer and JSON import validator. Invalid dates and hide-before-show ranges now return a clear error instead of silently clearing the hide date.
* No database schema, JSON storage format, import/export, Trash or uninstall behavior changes.

== Version 3.2.19 ==
* Databases support custom Dashicon, image icon, background image, background colour and accent colour settings; values can be set at creation and edited later.
* Folders support custom Dashicons and colours, without background-image uploads.
* Added hierarchical collection sections with multiple section assignments per record, similar to WordPress post categories.
* Added Public/Private visibility, site-timezone Show from and Hide after scheduling, section filters, and bulk section/publication editing.
* Added a section filter to kgdm()->find() and kgdm_get_records().
* Restricted include_deleted to administrators, isolated cached public/admin query results, and hid internal publication schedule metadata from public results.
* Ensured public kgdm_get_records() responses return sanitized record payloads and filtered-out rows are deselected before bulk edits.
* Added schema version 2.8.0; older imports and backups continue to normalize missing appearance/section data.

== Clean installation ==
A new installation creates only the manager's storage tables. It does not create a database, collection, sample record, faction, game dataset or preset content.

== Version 3.2.12 ==
* Added a context-aware four-step workflow across Databases, Folders & forms, Records and Completeness.
* Workflow navigation preserves the selected database and active folder/collection while moving between the main workspace steps.
* Added Previous / Next actions, step readiness hints and a current database/folder path indicator.
* Separated folder browsing from form/schema setup with dedicated browse guidance and Setup folder & form actions.
* Records now link directly to the matching Completeness audit, and Completeness can open the exact record editor even when the record is beyond the current page.
* Added matching shortcuts between Records, folder setup and Completeness; flexible JSON collections are clearly identified as not eligible for schema-based completeness checks.
* No database schema, record payload, public API, import/export format, backup format or migration-engine changes.

== Version 3.2.11 ==
* Refined the Create / Edit Folder workspace, folder cards, card actions and empty states for better spacing, alignment and responsive behavior.
* Improved modal sizing, close controls, sticky folder-editor heading and sticky Review changes / Cancel actions.
* Reworked field-builder cards, drag handles, required controls, advanced settings, nested option controls and category-template cards with clearer grouping.
* Improved the Faction preset panel, schema JSON panel, migration-safety notice and form-builder status presentation.
* This is a focused CSS/presentation update. Record behavior, templates, data formats, APIs and database schema are unchanged.

== Version 3.2.10 ==
* Replaced the crowded horizontal section tabs with grouped navigation: Workspace (Databases, Folders & forms, Records, Completeness), Data tools (Import / Export, Developer) and System (Settings, Help & updates).
* Added consistent page headings, concise section guidance and current-database context across the admin screens.
* Combined Help and the update log into one navigation destination with separate Help & system info and Release notes & updates sub-tabs. Existing update-log links remain compatible.
* Refreshed the shared design system for panels, tables, forms, cards, action bars, code examples, status labels and mobile navigation using native WordPress admin styles.
* No database schema, record, public API, template or import-format changes.

== Version 3.2.9 ==
* Added a built-in Faction / Organization collection form preset for Genshin Impact and similar lore databases.
* Includes 30 structured top-level fields and nested repeaters for members, ranks, goals, notable events, faction relationships, quests and source references.
* Includes category templates for general factions, military orders, governments / political groups, secret societies and guilds / associations.
* Added a guarded Load Faction form action. Loading replaces only the current unsaved form-builder fields/templates; stored records are not modified until the administrator reviews and applies the schema update.
* Existing template migration previews, revisions, defaults, snapshots and rollback safeguards continue to protect records.
* Retains the WordPress-native styling and CSS refinements delivered in 3.2.6, 3.2.7 and 3.2.8.
* No database schema, record, public API or import-format changes.

To use the preset, open **Folders & forms** in your database, create a folder named **Factions / Organizations** (or edit your existing `factions` folder), and click **Load Faction form** in the Form field builder. Review the generated fields and category templates. Choose **Review changes** and inspect the migration preview before applying it. Loading the preset alone does not save or change existing records.

== Features ==
* Create independent databases for any type of project.
* Create nested collection folders with a file-manager-style tree, breadcrumbs, child-folder cards and separate Open / Edit actions.
* Move folders to Trash, restore them, or permanently delete a folder subtree with its records and saved history.
* Build reusable, category-specific record forms with defaults, visibility and required-field rules.
* Generate record forms directly from collection schemas, including nested groups and repeaters with add/remove controls.
* Apply schema defaults to new records and category-specific defaults when an entry template is selected.
* Show or hide fields from other field values using configurable conditions; hidden values are preserved rather than discarded.
* Validate required and typed values in the browser and again on the server before saving.
* Track record completeness in the record list and associate each saved record with the template version used.
* Use the dedicated Completeness checker to audit required and recommended fields, nested groups, repeater rows and template assignment without changing saved data.
* Preserve unknown legacy values, including nested values, when the active form schema changes.
* Visual template builder supports drag-and-drop field ordering, field duplication and template duplication.
* Builder shows live field/template counts before saving; server validation remains authoritative.
* Organise custom fields into sections, groups and repeaters.
* Review a full field-by-field audit before applying a changed template.
* Preserve removed field values as legacy JSON; type changes never silently convert existing values.
* Save immutable template revisions and restore an earlier revision through the same review process.
* Migrate data between template versions with optional old-field to new-field mapping. Mapped values are copied only into empty destinations; source values remain available as legacy data.
* Snapshot each changed record before migration, record migration counts and preserve exact before/after payload hashes.
* Roll back a migration safely: only records unchanged since migration are restored; records edited afterward are skipped and reported as conflicts.
* View migration history, defaults applied, mapped values copied and template-version tags advanced for each collection.
* Optionally backfill defaults into newly added fields without overwriting existing data.
* Choose a form collection or list-only JSON collection.
* WordPress Media Library image and gallery fields; attachment IDs are stored in records.
* Add, edit, soft-delete and restore records.
* Paste or upload JSON; the full structure, schemas, template history and records are validated before writes.
* Store records as canonical JSON with storage version metadata and SHA-256 integrity hashes.
* Validate saved JSON storage from the Import / Export screen and detect corrupted or manually altered payloads.
* Validate imported storage metadata and payload hashes before any import writes occur.
* Horizontal tabs or WordPress-style side navigation.
* Optional read-only REST API per database; private by default.
* PHP query API for snippets and theme templates: kgdm()->get() and kgdm()->find() with nested field filters, sorting, pagination and object-cache support.
* Query cache uses per-site/per-collection generations instead of flushing unrelated KGDM cache entries on every write.
* Collection reads verify stored SHA-256 payload hashes consistently with single-record reads.
* Query cache entries have size limits to prevent oversized records or collections from consuming excessive object-cache memory.
* PHP helper functions for use from snippets and theme templates.
* Admin CSS and JavaScript load only on the plugin page; WordPress media scripts load only on Records screens that use image fields.
* Optional complete data cleanup when the plugin is deleted; disabled by default and requires typing DELETE KGDM DATA the first time it is enabled.

== Version model ==
The plugin release version, WordPress table schema version and each collection's template version are tracked separately. Release 3.0.0 uses storage schema 2.6.0 and update migration engine 1. The plugin release version, WordPress table schema, JSON payload version and each collection template version remain separate. New or edited records store the collection template version used at save time; older records are not assigned a guessed historical version.

== Storage ==
The plugin uses six WordPress database tables:
* {prefix}kgdm_databases
* {prefix}kgdm_collections
* {prefix}kgdm_records
* {prefix}kgdm_template_versions
* {prefix}kgdm_migrations
* {prefix}kgdm_migration_records

Records, collections, database definitions and template revisions are stored in your site's WordPress database. Media files remain in the WordPress Media Library; records store attachment IDs and uninstall never deletes original media files.

== PHP read API ==
* `kgdm()->get($database_id, $collection_slug, $record_id, $args = array())` — fast single-record lookup with WordPress object-cache support.
* `kgdm()->find($database_id, $collection_slug, $args = array())` — field-aware collection query with search, ordering, pagination and cache support.
* `kgdm_get($database_id, $collection_slug, $record_id, $args = array())` — function alias for `kgdm()->get()`.
* `kgdm_find($database_id, $collection_slug, $args = array())` — function alias for `kgdm()->find()`.
* Existing `kgdm_get_databases()`, `kgdm_get_database()`, `kgdm_get_collections()`, `kgdm_get_records()` and `kgdm_get_record()` helpers remain supported.

Example:

    $record = kgdm()->get('genshin-impact', 'characters', 'hutao');
    if ($record) {
        echo esc_html($record['name'] ?? $record['id'] ?? '');
    }

Find example:

    $records = kgdm()->find('genshin-impact', 'characters', array(
        'where' => array('element' => 'Pyro'),
        'order_by' => 'name',
        'limit' => 20,
        'cache' => true,
    ));

Nested-field example:

    $records = kgdm()->find('genshin-impact', 'characters', array(
        'where' => array(
            'region' => 'Liyue',
            'stats.hp' => array('operator' => 'gte', 'value' => 10000),
        ),
    ));

Supported `where` operators: exact match, `contains`, `in`, `not_in`, `exists`, `gt`, `gte`, `lt`, `lte`. Nested JSON paths use dot notation. `cache` defaults to enabled for `find()`; pass `'cache' => false` to bypass filtered-result caching. `get()` is cached by default. Cache entries are size-limited and invalidated through per-site, per-collection generation keys after record writes, template migrations, migration rollback, full backup restore and deletes. A persistent WordPress object-cache backend such as Redis or Memcached can keep cached data across requests; without one, cache reuse is limited to the current request.

== JSON import format ==
The plugin accepts `kgdm-database` format version 1 and compatible manager V2 backups. Root keys are `database` and `collections`. Each collection can include `slug`, `name`, `fields` or `schema`, optional `mode`, `form_templates`, `template_version`, `template_history`, nested `parent` and `records`. Each record must contain a unique ID. Empty collections are valid. Template history is validated before any import writes.

== Data migration and recovery ==
Every applied template change creates a migration log. Changed records are snapshotted before writes. Safe migration actions include filling newly added schema and category-template defaults, copying values from retired field keys to new field keys, and advancing only records explicitly tagged with the immediately previous template version. Older or unversioned records remain marked for review rather than being assigned a guessed version. Source fields are never deleted, and type conversions are not performed implicitly. Rollback compares the current record hash and status with the post-migration snapshot and restores only records that have not been edited, deleted or otherwise changed since the migration. Only records stored in KGDM tables are migrated; third-party or base/master source records are not rewritten. Recovery snapshots are local to this WordPress database and are not included in exported JSON files; keep regular database backups.

== Upgrade ==
Upgrade in place from V2.1.2 or later by uploading the new plugin package over the existing installation. WordPress automatic updates are detected on `plugins_loaded`, even though automatic updates do not run the activation hook. The update engine tracks the plugin release version separately from the storage schema version, takes a site-local atomic lock, runs immutable release migration steps in order, records per-step attempts/status, and verifies required storage tables and columns. The installed plugin version is committed only after all required steps succeed. Failed updates retain the old plugin version, preserve existing records, are logged in Update Log, and can be retried by an administrator. Completed steps are not replayed. Downgrades are blocked when the saved plugin or storage schema version is newer than the installed package. Do not delete existing KGDM storage tables before upgrading.

== Uninstall ==
The plugin preserves databases and settings when deleted unless **Settings → Enable permanent deletion of KGDM data when this plugin is uninstalled** has been enabled. To newly enable it, an administrator must type the exact phrase `DELETE KGDM DATA` and save. Deactivation never removes data. When enabled, uninstall drops only the six KGDM tables, removes KGDM-namespaced options/transients and the legacy V1 migration option, clears the KGDM query-cache group where supported, and deletes the protected local KGDM backup archive directory. A fresh installation starts with empty KGDM tables, default settings, no previous active database selection and a new install-generation cache namespace; the uninstall policy returns to OFF. WordPress Media Library attachments/files, posts, pages, users, themes, other plugins’ data and unrelated tables/options are not deleted. Custom backup paths outside KGDM’s protected local backup folder must be managed separately. On multisite, each site is evaluated independently using that site’s saved setting.


== Version 2.9.0 ==
* Completed Phase 7: uninstall data settings and cleanup hardening.
* Data preservation is the default; plugin deactivation never deletes data.
* Added a typed confirmation phrase before permanent uninstall deletion can be enabled for the first time.
* Uninstall removes only six KGDM-owned tables, KGDM options/transients and the known legacy V1 migration option.
* Uses WordPress option/transient APIs to keep caches consistent.
* Explicitly preserves Media Library attachments/files and all unrelated WordPress/site data.
* Multisite uninstall evaluates the cleanup setting separately for each site.
* No WordPress storage schema migration; internal schema remains 2.6.0.


== Version 3.0.0 ==
* Completed Phase 8: plugin update migration engine.
* Separated plugin release migrations from WordPress storage schema upgrades.
* Added sequential release migration registry, persistent per-step ledger, attempt counts, completion/failure states and bounded update history.
* Added atomic update locking, stale-lock recovery and administrator-only manual retry.
* Automatic plugin updates are detected on `plugins_loaded` when activation hooks are not run.
* Storage schema is installed/updated only when needed or when required tables/columns fail verification.
* Plugin version is updated only after required migrations succeed; failures preserve existing records and safely retry.
* Added version downgrade protection and Update Log reporting for current step, plugin release, schema, JSON storage and migration engine versions.
* JSON storage remains format 1 and WordPress storage schema remains 2.6.0.


== Version 3.2.7 ==
* Added List and Grid layouts to the dedicated Update log tab, with the release timeline preserved in List view and the preference remembered locally.
* Restyled the folder tree as card-based navigation with clearer folder opening and editing controls.
* Fixed the Create database plus icon so it displays instead of leaving an empty icon space.
* No database schema, record, API or import format changes.

== Version 3.2.6 ==
* Fixed all 47 Plugin Check errors in release 3.2.5, including output escaping, SQL preparation, backup filesystem operations and readme metadata.
* Escaped dynamic record form and status output at render time while preserving valid JSON and backup download payloads.
* Updated WordPress compatibility metadata and limited readme tags to the supported five-tag maximum.
* No database schema, record, API or import format changes.

== Version 3.2.5 ==
* Replaced the custom navigation bar with WordPress native admin tabs.
* Removed the duplicate Dashboard tab and combined system information with Help and updates.
* Fixed Database settings opening only from explicit Settings links, remaining open after save, and clearing its deep-link flag when closed.
* Restyled form builder templates and Database settings using clearer layouts and standard WordPress admin form patterns.
* Improved form review spacing, first-time audit guidance, empty JSON-object defaults and required record ID help text.
* No database schema, record, API or import format changes.

== Version 3.2.4 ==
* Scoped selector helpers inside the completeness checker so it runs independently of the main admin script closure.
* Resolved a JavaScript runtime error that prevented completeness filters from initializing.
* Kept the database schema, records, APIs and import formats unchanged.

== Version 3.2.3 ==
* Kept keyboard focus inside database and folder editor dialogs and returned focus to the opener when a dialog closes.
* Added dialog state and control relationships for the Create database action, plus a sensible focus target for dialogs opened from deep links.
* Standardized icon alignment and keyboard focus outlines across section navigation, action buttons and modal controls.
* Kept the database schema, stored records, APIs and import formats unchanged.

== Version 3.2.2 ==
* Added a dedicated Database tools header with aligned icon-and-label actions.
* Moved database creation and database settings into accessible modal dialogs while keeping the database library visible underneath.
* Moved folder creation/editing into large modal dialogs so the file-manager workspace remains visible behind the editor.
* Made database tiles behave like file-manager items with keyboard-accessible click navigation.
* Improved icon/text alignment across database cards and action buttons without changing storage, APIs or data formats.

== Version 3.2.1 ==
* Completed a maintenance audit of the PHP query API, data integrity checks, record write handlers and object-cache behavior.
* Collection reads now verify SHA-256 payload hashes consistently with single-record reads.
* Isolated record cache envelopes so user data is never modified to mark a cached response.
* Added per-site, per-collection cache generations and bounded cache item sizes.
* Improved nested-field sorting, boolean and null comparisons, and explicit operator validation.
* Made record renames transactional and blocked accidental duplicate-ID overwrites in the standard record editor.
* Made legacy scaffold cleanup transactional and invalidate cached query data after successful completion.
* JSON imports check transaction start/commit results and invalidate affected query caches after commit rather than per imported record.
* Kept WordPress storage schema 2.6.0, JSON storage format 1 and migration engine 1.

= 3.2.17 =
* Added shared reusable metric cards, empty states and image placeholders used across dashboard and recovery screens.
* Reduced database overview record-count queries to one grouped query for standard databases, while retaining the bundled Genshin provider merge behavior.
* Centralized attachment rendering through WordPress responsive image helpers with lazy loading, asynchronous decoding, `srcset`, intrinsic dimensions and low fetch priority.
* Hardened client-side media preview URLs to HTTP(S) only and replaced placeholder HTML strings with safe DOM construction.
* Added common card design tokens, dark-mode-aware metric borders, responsive empty-state actions and reduced-motion support.
* No database schema, record format, import/export, Trash, backup or PHP API changes.
