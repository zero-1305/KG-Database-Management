(function () {
    'use strict';

    const $ = (selector, root = document) => root.querySelector(selector);
    const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
    const slugify = (value) => String(value || '').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    const safeImageUrl = (value) => {
        try {
            const url = new URL(String(value || ''), window.location.href);
            return (url.protocol === 'http:' || url.protocol === 'https:') ? url.href : '';
        } catch (error) { return ''; }
    };
    const makeImagePlaceholder = (className, label) => {
        const placeholder = document.createElement('span');
        placeholder.className = 'kgdm-ui-image-placeholder ' + className;
        placeholder.setAttribute('role', 'img');
        placeholder.setAttribute('aria-label', label);
        const icon = document.createElement('span');
        icon.className = 'dashicons dashicons-format-image';
        icon.setAttribute('aria-hidden', 'true');
        placeholder.appendChild(icon);
        const sr = document.createElement('span');
        sr.className = 'screen-reader-text';
        sr.textContent = label;
        placeholder.appendChild(sr);
        return placeholder;
    };
    let generatedControlId = 0;
    function ensureFormControlIds(root = document) {
        const usedIds = new Set($$('[id]', document).map((element) => element.id).filter(Boolean));
        const seenIds = new Set();
        const visit = (node) => {
            Array.from(node.childNodes || []).forEach((child) => {
                if (child.nodeType !== 1) return;
                const element = child;
                const isControl = /^(INPUT|SELECT|TEXTAREA)$/.test(element.tagName);
                let id = element.getAttribute('id') || '';
                if (id && seenIds.has(id) && isControl) {
                    id = '';
                }
                if ((!id && !element.hasAttribute('name')) || (element.getAttribute('id') && !id)) {
                    do { id = 'kgdm-control-' + (++generatedControlId); } while (usedIds.has(id));
                    element.id = id;
                    usedIds.add(id);
                }
                if (element.id) seenIds.add(element.id);
                if (element.tagName === 'TEMPLATE') visit(element.content);
                else visit(element);
            });
        };
        if (root.nodeType === 1) {
            // Include the root itself when a newly inserted control or template is passed in.
            const parent = root.parentNode;
            if (parent) visit(parent);
            else visit(root);
        } else {
            visit(root);
        }
    }
    ensureFormControlIds();
    const parseObject = (value, label) => {
        let parsed;
        try { parsed = JSON.parse(value || '{}'); } catch (error) { throw new Error(label + ' must contain valid JSON.'); }
        if (!parsed || Array.isArray(parsed) || typeof parsed !== 'object') throw new Error(label + ' must be a JSON object.');
        return parsed;
    };
    const parseArray = (value, label) => {
        let parsed;
        try { parsed = JSON.parse(value || '[]'); } catch (error) { throw new Error(label + ' must contain valid JSON.'); }
        if (!Array.isArray(parsed)) throw new Error(label + ' must be a JSON array.');
        return parsed;
    };

    // Keep the release log's List/Grid preference between visits when browser storage is available.
    const releaseTimeline = $('.kgdm-release-timeline[data-view]');
    const releaseViewButtons = $$('.kgdm-update-log-view [data-update-log-mode]');
    if (releaseTimeline && releaseViewButtons.length) {
        const releaseViewStorageKey = 'kgdm_release_log_view';
        let releaseView = 'list';
        try {
            const savedView = window.localStorage.getItem(releaseViewStorageKey);
            if (savedView === 'list' || savedView === 'grid') releaseView = savedView;
        } catch (error) {}
        const setReleaseView = (mode, persist) => {
            if (mode !== 'list' && mode !== 'grid') return;
            releaseView = mode;
            releaseTimeline.dataset.view = mode;
            releaseTimeline.classList.toggle('is-list-view', mode === 'list');
            releaseTimeline.classList.toggle('is-grid-view', mode === 'grid');
            releaseViewButtons.forEach((button) => {
                const active = button.dataset.updateLogMode === mode;
                button.setAttribute('aria-pressed', active ? 'true' : 'false');
                button.classList.toggle('button-primary', active);
            });
            if (persist) {
                try { window.localStorage.setItem(releaseViewStorageKey, mode); } catch (error) {}
            }
        };
        releaseViewButtons.forEach((button) => {
            button.addEventListener('click', () => setReleaseView(button.dataset.updateLogMode, true));
        });
        setReleaseView(releaseView, false);
    }

    // Modal editors keep focus inside the dialog and return it to the opener when closed.
    const modalReturnFocus = new WeakMap();
    const modalFocusableSelector = 'a[href], button:not([disabled]), input:not([type="hidden"]):not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';
    const modalFocusable = (modal) => $$(modalFocusableSelector, modal).filter((element) => element.getClientRects().length > 0);
    const openModal = (modal, trigger = null) => {
        if (!modal || modal.classList.contains('is-open')) return;
        const activeElement = document.activeElement;
        modalReturnFocus.set(modal, trigger || (activeElement instanceof HTMLElement && activeElement !== document.body ? activeElement : null));
        modal.classList.add('is-open');
        modal.setAttribute('aria-hidden', 'false');
        document.body.classList.add('kgdm-modal-open');
        const dialog = $('[role="dialog"]', modal);
        if (dialog && !dialog.hasAttribute('tabindex')) dialog.setAttribute('tabindex', '-1');
        const focusTarget = $('input:not([type="hidden"]):not([disabled]), textarea:not([disabled]), select:not([disabled]), button:not([disabled])', modal) || $('[role="dialog"]', modal);
        if (focusTarget) window.requestAnimationFrame(() => {
            if (modal.classList.contains('is-open')) focusTarget.focus();
        });
    };
    const closeModal = (modal) => {
        if (!modal) return;
        modal.classList.remove('is-open');
        modal.setAttribute('aria-hidden', 'true');
        if (!$('.kgdm-modal.is-open')) document.body.classList.remove('kgdm-modal-open');
        if (modal.id === 'kgdm-database-settings-modal') {
            const url = new URL(window.location.href);
            if (url.searchParams.get('edit_database') === '1') {
                url.searchParams.delete('edit_database');
                window.history.replaceState(window.history.state, '', url.pathname + url.search + url.hash);
            }
        }
        const returnFocus = modalReturnFocus.get(modal);
        modalReturnFocus.delete(modal);
        const fallback = $('.kgdm-main-content');
        const focusTarget = returnFocus && returnFocus.isConnected ? returnFocus : fallback;
        if (focusTarget) window.requestAnimationFrame(() => {
            if (!modal.classList.contains('is-open')) focusTarget.focus({ preventScroll: true });
        });
    };
    $$('.kgdm-open-modal').forEach((trigger) => {
        trigger.addEventListener('click', () => {
            trigger.setAttribute('aria-expanded', 'true');
            openModal($(trigger.dataset.modalTarget), trigger);
        });
    });
    $$('.kgdm-modal-close').forEach((button) => {
        button.addEventListener('click', () => {
            const modal = button.closest('.kgdm-modal');
            const returnFocus = modal && modalReturnFocus.get(modal);
            if (returnFocus instanceof HTMLElement && returnFocus.matches('.kgdm-open-modal')) returnFocus.setAttribute('aria-expanded', 'false');
            closeModal(modal);
        });
    });
    $$('.kgdm-modal').forEach((modal) => {
        modal.addEventListener('click', (event) => {
            if (event.target === modal) {
                const returnFocus = modalReturnFocus.get(modal);
                if (returnFocus instanceof HTMLElement && returnFocus.matches('.kgdm-open-modal')) returnFocus.setAttribute('aria-expanded', 'false');
                closeModal(modal);
            }
        });
    });
    document.addEventListener('keydown', (event) => {
        const open = $('.kgdm-modal.is-open');
        if (!open) return;
        if (event.key === 'Escape') {
            const returnFocus = modalReturnFocus.get(open);
            if (returnFocus instanceof HTMLElement && returnFocus.matches('.kgdm-open-modal')) returnFocus.setAttribute('aria-expanded', 'false');
            closeModal(open);
            return;
        }
        if (event.key !== 'Tab') return;
        const focusable = modalFocusable(open);
        if (!focusable.length) {
            event.preventDefault();
            $('[role="dialog"]', open)?.focus();
            return;
        }
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (event.shiftKey && (document.activeElement === first || !open.contains(document.activeElement))) {
            event.preventDefault();
            last.focus();
        } else if (!event.shiftKey && (document.activeElement === last || !open.contains(document.activeElement))) {
            event.preventDefault();
            first.focus();
        }
    });

    // Deep links open the requested editor as a popup while leaving the file-manager page visible behind it.
    const autoDatabaseSettings = $('[data-auto-open="1"]#kgdm-database-settings-modal');
    if (autoDatabaseSettings) openModal(autoDatabaseSettings);
    if ($('#kgdm-folder-editor-modal')) openModal($('#kgdm-folder-editor-modal'));

    // Database cards behave like file-manager items; action links/buttons retain their normal behavior.
    $$('.kgdm-clickable-card[data-open-url]').forEach((card) => {
        const open = () => { window.location.href = card.dataset.openUrl; };
        card.addEventListener('click', (event) => {
            if (event.target.closest('a,button,input,select,textarea,form')) return;
            open();
        });
        card.addEventListener('keydown', (event) => {
            if (event.key === 'Enter' || event.key === ' ') {
                if (event.target !== card) return;
                event.preventDefault();
                open();
            }
        });
    });

    // Destructive uninstall is opt-in and requires typed confirmation the first time.
    const uninstallToggle = $('#kgdm-delete-on-uninstall');
    const uninstallConfirmation = $('#kgdm-delete-data-confirmation');
    if (uninstallToggle && uninstallConfirmation) {
        const wasAlreadyEnabled = uninstallToggle.dataset.alreadyEnabled === '1';
        const syncUninstallConfirmation = () => {
            uninstallConfirmation.disabled = !uninstallToggle.checked;
            uninstallConfirmation.required = uninstallToggle.checked && !wasAlreadyEnabled;
            uninstallConfirmation.setAttribute('aria-required', uninstallConfirmation.required ? 'true' : 'false');
        };
        uninstallToggle.addEventListener('change', syncUninstallConfirmation);
        syncUninstallConfirmation();
    }

    // Database ID preview. The server repeats the same normalization on save.
    const dbName = $('input[name="database_name"]');
    const dbSlug = $('#kgdm-database-slug');
    const dbSlugPreview = $('#kgdm-database-id-preview');
    function updateDatabaseSlugPreview() {
        if (!dbSlugPreview) return;
        const custom = dbSlug && dbSlug.value.trim();
        dbSlugPreview.textContent = slugify(custom || (dbName ? dbName.value : '')) || 'your-database-name';
    }
    if (dbName) dbName.addEventListener('input', updateDatabaseSlugPreview);
    if (dbSlug) dbSlug.addEventListener('input', updateDatabaseSlugPreview);
    updateDatabaseSlugPreview();

    const collectionNameInput = $('input[name="collection_name"]');
    const collectionSlugInput = $('#kgdm-collection-slug');
    const collectionSlugPreview = $('#kgdm-collection-id-preview');
    function updateCollectionSlugPreview() {
        if (!collectionSlugPreview) return;
        collectionSlugPreview.textContent = slugify((collectionSlugInput && collectionSlugInput.value.trim()) || (collectionNameInput ? collectionNameInput.value : '')) || 'your-folder-name';
    }
    if (collectionNameInput) collectionNameInput.addEventListener('input', updateCollectionSlugPreview);
    if (collectionSlugInput) collectionSlugInput.addEventListener('input', updateCollectionSlugPreview);
    updateCollectionSlugPreview();

    // Collection mode and full field builder.
    const fieldBuilder = $('#kgdm-field-builder');
    const templateBuilder = $('#kgdm-template-builder');
    const collectionMode = $('#kgdm-collection-mode');
    const collectionForm = $('#kgdm-collection-form');
    const formOnly = $$('.kgdm-form-only');

    function syncCollectionMode() {
        const isForm = !collectionMode || collectionMode.value !== 'list';
        formOnly.forEach((element) => { element.hidden = !isForm; });
    }
    if (collectionMode) {
        collectionMode.addEventListener('change', syncCollectionMode);
        syncCollectionMode();
    }

    function syncFieldTypeOptions(row) {
        const type = $('.kgdm-f-type', row);
        const options = $('.kgdm-f-options-wrap', row);
        const children = $('.kgdm-f-children-wrap', row);
        const range = $('.kgdm-f-number-range', row);
        if (options) options.hidden = !type || !['select', 'multiselect'].includes(type.value);
        if (children) children.hidden = !type || !['group', 'repeater'].includes(type.value);
        if (range) range.hidden = !type || type.value !== 'number';
    }

    function makeFieldRow(def = {}) {
        const row = document.createElement('article');
        row.className = 'kgdm-field-row';
        row.setAttribute('data-field-row', '');
        row.innerHTML = `
            <div class="kgdm-field-main">
                <span class="dashicons dashicons-menu kgdm-drag-handle" aria-hidden="true"></span>
                <label>Field key<input class="kgdm-f-key" type="text" placeholder="field_key" required></label>
                <label>Display label<input class="kgdm-f-label" type="text" placeholder="Character name"></label>
                <label>Field type<select class="kgdm-f-type">
                    <option value="text">Text</option><option value="textarea">Long text</option><option value="number">Number</option>
                    <option value="boolean">Toggle</option><option value="url">URL</option><option value="email">Email</option>
                    <option value="date">Date</option><option value="datetime">Date and time</option><option value="select">Select</option>
                    <option value="multiselect">Multi-select</option><option value="json">JSON</option><option value="image">Image</option>
                    <option value="gallery">Image gallery</option><option value="color">Color</option><option value="group">Object / field group</option>
                    <option value="repeater">Repeater / list</option>
                </select></label>
                <label class="kgdm-f-required"><input type="checkbox"> Required</label>
            </div>
            <details class="kgdm-field-advanced"><summary>Field settings</summary>
                <div class="kgdm-form-grid">
                    <label>Section<input class="kgdm-f-section" type="text" value="General"></label>
                    <label>Width<select class="kgdm-f-width"><option value="25">25%</option><option value="33">33%</option><option value="50">50%</option><option value="66">66%</option><option value="75">75%</option><option value="100" selected>Full width</option></select></label>
                    <label>Placeholder<input class="kgdm-f-placeholder" type="text"></label>
                    <label>Help text<input class="kgdm-f-help" type="text"></label>
                    <div class="kgdm-f-condition-wrap">
                        <label>Show when field key<input class="kgdm-f-condition-field" type="text" placeholder="has_signature"></label>
                        <label>Condition<select class="kgdm-f-condition-operator"><option value="equals">Equals</option><option value="not_equals">Does not equal</option><option value="contains">Contains</option><option value="not_contains">Does not contain</option><option value="is_checked">Is checked</option><option value="is_not_empty">Is not empty</option><option value="is_empty">Is empty</option></select></label>
                        <label>Value<input class="kgdm-f-condition-value" type="text" placeholder="true"></label>
                    </div>
                    <label class="kgdm-f-options-wrap">Options <small>For select fields; one option per comma</small><input class="kgdm-f-options" type="text" placeholder="Anemo, Geo, Electro"></label>
                    <label>Default value <small>Valid JSON value, e.g. "" or 0 or true</small><textarea class="kgdm-f-default" rows="2">""</textarea></label>
                    <label class="kgdm-f-children-wrap">Nested child fields <small>JSON definitions for Object / Repeater fields</small><textarea class="kgdm-f-children" rows="6">[]</textarea></label>
                    <div class="kgdm-f-number-range"><label>Minimum<input class="kgdm-f-min" type="number" step="any"></label><label>Maximum<input class="kgdm-f-max" type="number" step="any"></label><label>Maximum repeater entries<input class="kgdm-f-max-items" type="number" min="1" max="500" value="100"></label></div>
                </div>
            </details>
            <div class="kgdm-field-actions"><button type="button" class="button kgdm-move-field-up" aria-label="Move field up">↑</button><button type="button" class="button kgdm-move-field-down" aria-label="Move field down">↓</button><button type="button" class="button kgdm-duplicate-field">Duplicate</button><button type="button" class="button-link-delete kgdm-remove-field">Remove field</button></div>`;
        $('.kgdm-f-key', row).value = def.key || '';
        $('.kgdm-f-label', row).value = def.label || '';
        $('.kgdm-f-type', row).value = def.type || 'text';
        $('.kgdm-f-required input', row).checked = !!def.required;
        $('.kgdm-f-section', row).value = def.section || 'General';
        $('.kgdm-f-width', row).value = String(def.width || 100);
        $('.kgdm-f-placeholder', row).value = def.placeholder || '';
        $('.kgdm-f-help', row).value = def.help || '';
        $('.kgdm-f-condition-field', row).value = (def.show_if && def.show_if.field) || '';
        $('.kgdm-f-condition-operator', row).value = (def.show_if && def.show_if.operator) || 'equals';
        $('.kgdm-f-condition-value', row).value = (def.show_if && def.show_if.value !== undefined) ? String(def.show_if.value) : '';
        $('.kgdm-f-options', row).value = (def.options || []).join(', ');
        $('.kgdm-f-default', row).value = JSON.stringify(Object.prototype.hasOwnProperty.call(def, 'default') ? def.default : '', null, 2);
        $('.kgdm-f-children', row).value = JSON.stringify(def.children || [], null, 2);
        $('.kgdm-f-min', row).value = def.min ?? '';
        $('.kgdm-f-max', row).value = def.max ?? '';
        $('.kgdm-f-max-items', row).value = def.max_items || 100;
        syncFieldTypeOptions(row);
        return row;
    }

    if (fieldBuilder) {
        fieldBuilder.addEventListener('change', (event) => {
            if (event.target.matches('.kgdm-f-type')) syncFieldTypeOptions(event.target.closest('.kgdm-field-row'));
        });
        fieldBuilder.addEventListener('click', (event) => {
            const remove = event.target.closest('.kgdm-remove-field');
            const duplicate = event.target.closest('.kgdm-duplicate-field');
            const up = event.target.closest('.kgdm-move-field-up');
            const down = event.target.closest('.kgdm-move-field-down');
            if (remove) { remove.closest('.kgdm-field-row').remove(); updateBuilderStatus(); }
            if (duplicate) {
                const source = duplicate.closest('.kgdm-field-row');
                const clone = source.cloneNode(true);
                const keyInput = $('.kgdm-f-key', clone);
                const keys = new Set($$('.kgdm-f-key', fieldBuilder).map(el => el.value));
                const base = slugify(keyInput.value || 'field').replace(/-/g, '_');
                let candidate = base + '_copy', n = 2;
                while (keys.has(candidate)) candidate = base + '_copy_' + n++;
                keyInput.value = candidate;
                source.parentNode.insertBefore(clone, source.nextSibling);
                ensureFormControlIds();
                updateFieldRowState();
                updateBuilderStatus();
            }
            if (up) {
                const row = up.closest('.kgdm-field-row');
                const previous = row.previousElementSibling;
                if (previous) fieldBuilder.insertBefore(row, previous);
            }
            if (down) {
                const row = down.closest('.kgdm-field-row');
                const next = row.nextElementSibling;
                if (next) fieldBuilder.insertBefore(next, row);
            }
        });
        $$('.kgdm-field-row', fieldBuilder).forEach(syncFieldTypeOptions);

        let draggedField = null;
        fieldBuilder.addEventListener('dragstart', (event) => {
            const row = event.target.closest('.kgdm-field-row');
            if (!row) return;
            draggedField = row;
            row.classList.add('is-dragging');
            if (event.dataTransfer) event.dataTransfer.effectAllowed = 'move';
        });
        fieldBuilder.addEventListener('dragend', () => {
            if (draggedField) draggedField.classList.remove('is-dragging');
            draggedField = null;
            updateBuilderStatus();
        });
        fieldBuilder.addEventListener('dragover', (event) => {
            if (!draggedField) return;
            const target = event.target.closest('.kgdm-field-row');
            if (!target || target === draggedField) return;
            event.preventDefault();
            const rect = target.getBoundingClientRect();
            const after = event.clientY > rect.top + rect.height / 2;
            target.parentNode.insertBefore(draggedField, after ? target.nextSibling : target);
        });
    }
    const addField = $('#kgdm-add-field');
    if (addField && fieldBuilder) addField.addEventListener('click', () => {
        const next = fieldBuilder.querySelectorAll('.kgdm-field-row').length + 1;
        fieldBuilder.appendChild(makeFieldRow({ key: 'field_' + next, label: 'Field ' + next, type: 'text' }));
        ensureFormControlIds();
        updateBuilderStatus();
    });

    function updateBuilderStatus() {
        const status = $('#kgdm-builder-status');
        if (!status) return;
        const fields = $$('.kgdm-field-row', fieldBuilder || document).length;
        const templates = $$('.kgdm-template-row', templateBuilder || document).length;
        status.innerHTML = '<span><strong>' + fields + '</strong> fields</span><span><strong>' + templates + '</strong> templates</span><span class="kgdm-builder-ready">Ready for server validation</span>';
    }
    updateBuilderStatus();

    const rawSchemaEditor = $('#kgdm-schema-json-editor');
    const applyRawSchema = $('#kgdm-apply-schema-json');
    const rawSchemaMessage = $('#kgdm-schema-json-message');
    if (applyRawSchema && rawSchemaEditor && fieldBuilder) applyRawSchema.addEventListener('click', () => {
        try {
            const schema = parseArray(rawSchemaEditor.value, 'Collection schema');
            const allowed = new Set(['text','textarea','number','boolean','url','email','date','datetime','select','multiselect','json','image','gallery','color','group','repeater']);
            const seen = new Set();
            schema.forEach((field, index) => {
                if (!field || typeof field !== 'object' || Array.isArray(field)) throw new Error('Field ' + (index + 1) + ' must be a JSON object.');
                const key = slugify(field.key || '').replace(/-/g, '_');
                if (!key || seen.has(key)) throw new Error('Field ' + (index + 1) + ' has a missing or duplicate key.');
                if (['id','_kgdm_template','_kgdm_template_version'].includes(key)) throw new Error('The field key ' + key + ' is reserved.');
                if (!allowed.has(field.type || 'text')) throw new Error('Unsupported field type in ' + key + '.');
                seen.add(key);
            });
            fieldBuilder.replaceChildren();
            schema.forEach((field) => fieldBuilder.appendChild(makeFieldRow(field)));
            const hidden = $('#kgdm-collection-schema');
            if (hidden) hidden.value = JSON.stringify(schema);
            if (rawSchemaMessage) { rawSchemaMessage.textContent = 'Valid JSON loaded into the visual builder. Review the fields and save to continue.'; rawSchemaMessage.className = 'kgdm-json-validation-good'; } updateBuilderStatus();
        } catch (error) {
            if (rawSchemaMessage) { rawSchemaMessage.textContent = error.message; rawSchemaMessage.className = 'kgdm-json-validation-bad'; }
        }
    });

    // Reusable category form templates.
    function makeTemplateRow(def = {}) {
        const row = document.createElement('article');
        row.className = 'kgdm-template-row';
        row.innerHTML = `
            <div class="kgdm-template-main">
                <label>Template name<input class="kgdm-tpl-name" type="text" placeholder="Playable character"></label>
                <label>Category ID<input class="kgdm-tpl-category" type="text" placeholder="playable-character"></label>
                <label>Description<input class="kgdm-tpl-description" type="text" placeholder="Fields used for this record type"></label>
            </div>
            <div class="kgdm-form-grid">
                <label>Visible fields <small>Comma-separated field keys; blank means all fields</small><input class="kgdm-tpl-visible" type="text" placeholder="name, element, weapon"></label>
                <label>Required fields <small>Additional fields required for this category</small><input class="kgdm-tpl-required" type="text" placeholder="name, rarity"></label>
            </div>
            <label>Default values <small>JSON object; keys must exist in the collection schema</small><textarea class="kgdm-tpl-defaults" rows="4">{}</textarea></label>
            <div class="kgdm-field-actions"><button type="button" class="button kgdm-duplicate-template">Duplicate</button><button type="button" class="button-link-delete kgdm-remove-template">Remove template</button></div>`;
        $('.kgdm-tpl-name', row).value = def.name || '';
        $('.kgdm-tpl-category', row).value = def.category || '';
        $('.kgdm-tpl-description', row).value = def.description || '';
        $('.kgdm-tpl-visible', row).value = (def.visible_fields || []).join(', ');
        $('.kgdm-tpl-required', row).value = (def.required_fields || []).join(', ');
        $('.kgdm-tpl-defaults', row).value = JSON.stringify(def.defaults || {}, null, 2);
        return row;
    }

    const loadFactionPresetButton = $('#kgdm-load-faction-form-preset');
    if (loadFactionPresetButton && fieldBuilder && templateBuilder) {
        loadFactionPresetButton.addEventListener('click', () => {
            const presetNode = $('#kgdm-faction-form-preset-data');
            if (!presetNode) return;
            try {
                const preset = JSON.parse(presetNode.textContent || '{}');
                if (!Array.isArray(preset.schema) || !preset.schema.length || !Array.isArray(preset.form_templates) || !preset.form_templates.length) {
                    throw new Error('The bundled Faction form preset is incomplete. Reload the page and try again.');
                }
                const hasUnsavedBuilderData = $$('.kgdm-field-row', fieldBuilder).length > 0 || $$('.kgdm-template-row', templateBuilder).length > 0;
                if (hasUnsavedBuilderData && !window.confirm('Replace the current unsaved field and category-template builder with the Faction / Organization preset? Saved records will not be changed by loading this preset. You will review any schema changes before they are applied.')) return;

                if (collectionMode) {
                    collectionMode.value = 'form';
                    collectionMode.dispatchEvent(new Event('change', { bubbles: true }));
                }
                fieldBuilder.replaceChildren();
                preset.schema.forEach((field) => fieldBuilder.appendChild(makeFieldRow(field)));
                templateBuilder.replaceChildren();
                preset.form_templates.forEach((template) => templateBuilder.appendChild(makeTemplateRow(template)));

                const nameInput = collectionNameInput;
                const singularInput = collectionForm.querySelector('input[name="collection_singular"]');
                const descriptionInput = collectionForm.querySelector('textarea[name="collection_description"]');
                if (nameInput && !nameInput.value.trim()) nameInput.value = preset.name || 'Factions / Organizations';
                if (collectionSlugInput && !collectionSlugInput.value.trim()) collectionSlugInput.value = preset.slug || 'factions';
                if (singularInput && !singularInput.value.trim()) singularInput.value = preset.singular_name || 'Faction';
                if (descriptionInput && !descriptionInput.value.trim()) descriptionInput.value = preset.description || '';
                updateCollectionSlugPreview();

                const schemaInput = $('#kgdm-collection-schema');
                const templatesInput = $('#kgdm-collection-templates');
                if (schemaInput) schemaInput.value = JSON.stringify(preset.schema);
                if (templatesInput) templatesInput.value = JSON.stringify(preset.form_templates);
                if (rawSchemaEditor) rawSchemaEditor.value = JSON.stringify(preset.schema, null, 2);
                if (rawSchemaMessage) {
                    rawSchemaMessage.textContent = 'Faction form preset loaded. Review the fields and templates, then choose Review changes to preview the migration.';
                    rawSchemaMessage.className = 'kgdm-json-validation-good';
                }
                ensureFormControlIds();
                updateBuilderStatus();
                if (nameInput) nameInput.focus();
            } catch (error) {
                if (rawSchemaMessage) {
                    rawSchemaMessage.textContent = error.message || 'The Faction form preset could not be loaded.';
                    rawSchemaMessage.className = 'kgdm-json-validation-bad';
                } else {
                    window.alert(error.message || 'The Faction form preset could not be loaded.');
                }
            }
        });
    }

    if (templateBuilder) {
        templateBuilder.addEventListener('click', (event) => {
            const remove = event.target.closest('.kgdm-remove-template');
            if (remove) { remove.closest('.kgdm-template-row').remove(); updateBuilderStatus(); return; }
            const duplicate = event.target.closest('.kgdm-duplicate-template');
            if (duplicate) {
                const source = duplicate.closest('.kgdm-template-row');
                const clone = source.cloneNode(true);
                const categoryInput = $('.kgdm-tpl-category', clone);
                const nameInput = $('.kgdm-tpl-name', clone);
                const ids = new Set($$('.kgdm-tpl-category', templateBuilder).map(el => el.value));
                const base = slugify((categoryInput && categoryInput.value) || (nameInput && nameInput.value) || 'template');
                let candidate = base + '-copy', n = 2;
                while (ids.has(candidate)) candidate = base + '-copy-' + n++;
                if (categoryInput) categoryInput.value = candidate;
                if (nameInput) nameInput.value = (nameInput.value || 'Template') + ' Copy';
                source.parentNode.insertBefore(clone, source.nextSibling);
                ensureFormControlIds();
                updateBuilderStatus();
            }
        });
    }
    const addTemplate = $('#kgdm-add-template');
    if (addTemplate && templateBuilder) addTemplate.addEventListener('click', () => { templateBuilder.appendChild(makeTemplateRow({ name: 'New template', category: 'new-category', defaults: {} })); ensureFormControlIds(); updateBuilderStatus(); });

    if (collectionForm) collectionForm.addEventListener('submit', (event) => {
        const errorBox = $('#kgdm-form-builder-error');
        if (errorBox) { errorBox.textContent = ''; errorBox.classList.remove('is-error'); }
        try {
            const schema = [];
            const seen = new Set();
            if (!collectionMode || collectionMode.value !== 'list') {
                $$('.kgdm-field-row', fieldBuilder || collectionForm).forEach((row, index) => {
                    const key = slugify($('.kgdm-f-key', row).value).replace(/-/g, '_');
                    if (!key) throw new Error('Field ' + (index + 1) + ' needs a key.');
                    if (seen.has(key)) throw new Error('Duplicate field key: ' + key);
                    if (['id', '_kgdm_template', '_kgdm_template_version'].includes(key)) throw new Error('The field key ' + key + ' is reserved.');
                    seen.add(key);
                    const type = $('.kgdm-f-type', row).value;
                    const item = {
                        key,
                        label: $('.kgdm-f-label', row).value.trim() || key,
                        type,
                        required: $('.kgdm-f-required input', row).checked,
                        section: $('.kgdm-f-section', row).value.trim() || 'General',
                        width: Number($('.kgdm-f-width', row).value || 100),
                        placeholder: $('.kgdm-f-placeholder', row).value.trim(),
                        help: $('.kgdm-f-help', row).value.trim()
                    };
                    const conditionField = $('.kgdm-f-condition-field', row).value.trim().split('.').map(part => slugify(part).replace(/-/g, '_')).filter(Boolean).join('.');
                    if (conditionField) {
                        item.show_if = {
                            field: conditionField,
                            operator: $('.kgdm-f-condition-operator', row).value || 'equals',
                            value: $('.kgdm-f-condition-value', row).value
                        };
                    }
                    const defaultRaw = $('.kgdm-f-default', row).value.trim();
                    if (defaultRaw) {
                        try { item.default = JSON.parse(defaultRaw); }
                        catch (error) { throw new Error('Default value for ' + key + ' is not valid JSON.'); }
                    }
                    if (['select', 'multiselect'].includes(type)) {
                        item.options = $('.kgdm-f-options', row).value.split(',').map((v) => v.trim()).filter(Boolean);
                        if (!item.options.length) throw new Error(type + ' field ' + key + ' needs at least one option.');
                    }
                    if (['group', 'repeater'].includes(type)) {
                        item.children = parseArray($('.kgdm-f-children', row).value, 'Nested fields for ' + key);
                        if (!item.children.length) throw new Error(type + ' field ' + key + ' needs at least one child field.');
                    }
                    if (type === 'number') {
                        const min = $('.kgdm-f-min', row).value;
                        const max = $('.kgdm-f-max', row).value;
                        if (min !== '') item.min = Number(min);
                        if (max !== '') item.max = Number(max);
                        if (min !== '' && max !== '' && Number(min) > Number(max)) throw new Error('Minimum cannot exceed maximum for ' + key + '.');
                    }
                    if (type === 'repeater') item.max_items = Math.max(1, Math.min(500, Number($('.kgdm-f-max-items', row).value || 100)));
                    schema.push(item);
                });
            }
            const templates = [];
            const templateIds = new Set();
            if (templateBuilder && (!collectionMode || collectionMode.value !== 'list')) {
                $$('.kgdm-template-row', templateBuilder).forEach((row, index) => {
                    const name = $('.kgdm-tpl-name', row).value.trim();
                    const categoryInput = $('.kgdm-tpl-category', row);
                    const category = slugify(categoryInput.value || name);
                    if (!name && !category) return;
                    if (!name || !category) throw new Error('Template ' + (index + 1) + ' needs a name and category ID.');
                    categoryInput.value = category;
                    if (templateIds.has(category)) throw new Error('Duplicate category template ID: ' + category);
                    templateIds.add(category);
                    const visible = $('.kgdm-tpl-visible', row).value.split(',').map((v) => v.trim()).filter(Boolean);
                    const required = $('.kgdm-tpl-required', row).value.split(',').map((v) => v.trim()).filter(Boolean);
                    templates.push({
                        name,
                        category,
                        description: $('.kgdm-tpl-description', row).value.trim(),
                        visible_fields: Array.from(new Set(visible)),
                        required_fields: Array.from(new Set(required)),
                        defaults: parseObject($('.kgdm-tpl-defaults', row).value, 'Defaults for template ' + name)
                    });
                });
            }
            const schemaInput = $('#kgdm-collection-schema');
            if (schemaInput) schemaInput.value = JSON.stringify(schema);
            if (rawSchemaEditor) rawSchemaEditor.value = JSON.stringify(schema, null, 2);
            const templatesInput = $('#kgdm-collection-templates');
            if (templatesInput) templatesInput.value = JSON.stringify(templates);
            updateCollectionSlugPreview();
        } catch (error) {
            event.preventDefault();
            if (errorBox) {
                errorBox.textContent = error.message;
                errorBox.classList.add('is-error');
                errorBox.scrollIntoView({ behavior: 'smooth', block: 'center' });
            } else {
                window.alert(error.message);
            }
        }
    });

    // Records tab and nested form values.
    const collectionPicker = $('#kgdm-record-collection');
    if (collectionPicker) collectionPicker.addEventListener('change', () => {
        const url = new URL(window.location.href);
        url.searchParams.set('collection', collectionPicker.value);
        url.searchParams.set('tab', 'records');
        url.searchParams.delete('paged');
        window.location.href = url.toString();
    });

    const cfg = $('#kgdm-ajax-config');
    const editor = $('#kgdm-record-editor');
    const recordForm = $('#kgdm-record-form');
    const msg = $('#kgdm-record-message');
    const templateSelect = $('#kgdm-record-template');

    function message(text, error) {
        if (!msg) return;
        msg.textContent = text;
        msg.className = error ? 'kgdm-message-error' : 'kgdm-message-success';
    }
    function getPath(object, path) {
        return String(path).split('.').reduce((value, part) => value && typeof value === 'object' ? value[part] : undefined, object);
    }
    function setPath(object, path, value) {
        const parts = String(path).split('.');
        let target = object;
        parts.forEach((part, index) => {
            const isLast = index === parts.length - 1;
            if (isLast) { target[part] = value; return; }
            const nextIsIndex = /^\d+$/.test(parts[index + 1]);
            if (!target[part] || typeof target[part] !== 'object' || (Array.isArray(target[part]) && !nextIsIndex)) {
                target[part] = nextIsIndex ? [] : {};
            }
            target = target[part];
        });
    }
    function getInputValue(input) {
        const key = input.dataset.key;
        if (input.type === 'checkbox') return input.checked;
        if (input.multiple) return Array.from(input.selectedOptions).map((option) => option.value);
        if (input.classList.contains('kgdm-json-field')) {
            try { return JSON.parse(input.value || (input.classList.contains('kgdm-repeater-field') ? '[]' : '{}')); }
            catch (error) { throw new Error('The JSON field "' + key + '" contains invalid JSON.'); }
        }
        if (input.classList.contains('kgdm-media-value')) {
            const field = input.closest('.kgdm-media-field');
            if (field && field.dataset.mediaType === 'gallery') {
                try { return JSON.parse(input.value || '[]').map(Number).filter(Boolean); }
                catch (error) { throw new Error('The gallery field "' + key + '" contains invalid JSON.'); }
            }
            return input.value ? Number(input.value) : '';
        }
        if (input.type === 'number' && input.value.trim() !== '') return Number(input.value);
        return input.value;
    }
    function setInputValue(input, value) {
        if (input.type === 'checkbox') input.checked = !!value;
        else if (input.multiple) {
            const values = Array.isArray(value) ? value.map(String) : [];
            Array.from(input.options).forEach((option) => { option.selected = values.includes(option.value); });
        } else if (input.classList.contains('kgdm-json-field')) {
            const fallback = input.classList.contains('kgdm-repeater-field') ? [] : {};
            input.value = JSON.stringify(value === undefined || value === null ? fallback : value, null, 2);
        } else if (input.classList.contains('kgdm-media-value')) {
            const field = input.closest('.kgdm-media-field');
            input.value = field && field.dataset.mediaType === 'gallery'
                ? JSON.stringify(Array.isArray(value) ? value : [])
                : (value === undefined || value === null ? '' : String(value));
        } else {
            input.value = value === undefined || value === null ? '' : String(value);
        }
    }

    function mediaIds(input) {
        if (!input) return [];
        const field = input.closest('.kgdm-media-field');
        if (field && field.dataset.mediaType === 'gallery') {
            try { return JSON.parse(input.value || '[]').map(Number).filter(Boolean); }
            catch (error) { return []; }
        }
        return input.value ? [Number(input.value)] : [];
    }
    function renderMediaPreview(field, ids) {
        const preview = $('.kgdm-media-preview', field);
        if (!preview) return;
        preview.innerHTML = '';
        if (!ids.length) {
            const empty = makeImagePlaceholder('kgdm-media-placeholder', 'No image selected');
            const label = document.createElement('small');
            label.textContent = 'No image selected';
            empty.appendChild(label);
            preview.appendChild(empty);
            return;
        }
        if (!window.wp || !wp.media) {
            const note = document.createElement('small');
            note.textContent = 'Selected media IDs: ' + ids.join(', ');
            preview.appendChild(note);
            return;
        }
        ids.forEach((id) => {
            const attachment = wp.media.attachment(id);
            attachment.fetch().done(() => {
                const data = attachment.toJSON();
                const image = document.createElement('img');
                image.className = 'kgdm-media-thumb';
                image.alt = '';
                image.width = 64;
                image.height = 64;
                image.loading = 'lazy';
                image.decoding = 'async';
                const imageUrl = safeImageUrl((data.sizes && data.sizes.thumbnail && data.sizes.thumbnail.url) || data.url);
                if (!imageUrl) return;
                image.src = imageUrl;
                image.alt = typeof data.alt === 'string' ? data.alt : '';
                preview.appendChild(image);
            }).fail(() => {
                const note = document.createElement('small');
                note.textContent = 'Media item ' + id + ' could not be loaded.';
                preview.appendChild(note);
            });
        });
    }
    function syncMediaField(field) {
        const input = $('.kgdm-media-value', field);
        if (!input) return;
        const ids = mediaIds(input);
        renderMediaPreview(field, ids);
        const choose = $('.kgdm-select-media', field);
        const remove = $('.kgdm-remove-media', field);
        const gallery = field.dataset.mediaType === 'gallery';
        if (choose) choose.textContent = gallery ? (ids.length ? 'Replace images' : 'Choose images') : (ids.length ? 'Replace image' : 'Choose image');
        if (remove) remove.disabled = !ids.length;
    }
    function chooseMedia(field) {
        if (!window.wp || !wp.media) {
            window.alert('WordPress Media Library is unavailable. Reload the Records tab.');
            return;
        }
        const gallery = field.dataset.mediaType === 'gallery';
        const frame = wp.media({
            title: gallery ? 'Choose images' : 'Choose image',
            button: { text: gallery ? 'Use selected images' : 'Use image' },
            library: { type: 'image' },
            multiple: gallery
        });
        frame.on('open', () => {
            const input = $('.kgdm-media-value', field);
            const selection = frame.state().get('selection');
            mediaIds(input).forEach((id) => selection.add(wp.media.attachment(id)));
        });
        frame.on('select', () => {
            const selected = frame.state().get('selection').toJSON().map((item) => Number(item.id)).filter(Boolean);
            const input = $('.kgdm-media-value', field);
            input.value = gallery ? JSON.stringify(selected) : String(selected[0] || '');
            syncMediaField(field);
        });
        frame.open();
    }
    function walkElementsIncludingTemplates(root, callback) {
        if (!root) return;
        const visit = (node) => {
            if (node.nodeType === 1) callback(node);
            if (node.nodeType === 1 && node.tagName === 'TEMPLATE') {
                Array.from(node.content.childNodes).forEach(visit);
            } else {
                Array.from(node.childNodes || []).forEach(visit);
            }
        };
        visit(root);
    }
    function replaceRepeaterToken(row, token, index) {
        const marker = '__INDEX_' + token + '__';
        walkElementsIncludingTemplates(row, (element) => {
            ['id', 'data-key', 'data-key-path', 'data-parent-path', 'data-index'].forEach((attribute) => {
                if (element.hasAttribute(attribute)) element.setAttribute(attribute, element.getAttribute(attribute).split(marker).join(String(index)));
            });
        });
    }
    function directRepeaterRows(items) {
        return items ? Array.from(items.children).filter((child) => child.matches('.kgdm-repeater-row')) : [];
    }
    function updateRepeaterControls(wrapper) {
        if (!wrapper) return;
        const count = directRepeaterRows($('.kgdm-repeater-items', wrapper) || wrapper).length;
        const max = Number(wrapper.dataset.maxItems || 100);
        const add = $('.kgdm-add-repeater-row', wrapper);
        const status = $('.kgdm-repeater-actions small', wrapper);
        if (add) add.disabled = count >= max;
        if (status) status.textContent = count + ' / ' + max + ' entries';
    }
    function addRepeaterRow(wrapper, index) {
        const prototype = $('.kgdm-repeater-prototype', wrapper);
        const items = $('.kgdm-repeater-items', wrapper);
        if (!prototype || !items) return null;
        const token = String(wrapper.dataset.repeaterLevel || (wrapper.dataset.keyPath || '').split('.').length);
        const fragment = prototype.content.cloneNode(true);
        const row = $('.kgdm-repeater-row', fragment);
        if (!row) return null;
        replaceRepeaterToken(row, token, index);
        const title = $('.kgdm-repeater-row-head strong', row);
        if (title) title.textContent = 'Entry ' + (Number(index) + 1);
        items.appendChild(fragment);
        ensureFormControlIds();
        updateRepeaterControls(wrapper);
        return row;
    }
    function reindexRepeaterRows(wrapper) {
        const items = $('.kgdm-repeater-items', wrapper);
        if (!items) return;
        const base = wrapper.dataset.keyPath || '';
        directRepeaterRows(items).forEach((row, newIndex) => {
            const oldIndex = row.dataset.index;
            if (String(oldIndex) !== String(newIndex)) {
                const from = base + '.' + oldIndex + '.';
                const to = base + '.' + newIndex + '.';
                walkElementsIncludingTemplates(row, (element) => {
                    ['data-key', 'data-key-path', 'data-parent-path'].forEach((attribute) => {
                        if (!element.hasAttribute(attribute)) return;
                        const current = element.getAttribute(attribute);
                        if (current.startsWith(from)) element.setAttribute(attribute, to + current.slice(from.length));
                    });
                    const controlId = element.getAttribute('id') || '';
                    const fromId = 'kgdm-record-field-' + base.replace(/\./g, '-') + '-' + oldIndex + '-';
                    if (controlId.startsWith(fromId)) {
                        element.setAttribute('id', 'kgdm-record-field-' + base.replace(/\./g, '-') + '-' + newIndex + '-' + controlId.slice(fromId.length));
                    }
                });
                row.dataset.index = String(newIndex);
            }
            const title = $('.kgdm-repeater-row-head strong', row);
            if (title) title.textContent = 'Entry ' + (newIndex + 1);
        });
        updateRepeaterControls(wrapper);
    }
    function hydrateRepeaters(scope, record) {
        const wrappers = [];
        if (scope && scope.matches && scope.matches('[data-kgdm-repeater]')) wrappers.push(scope);
        wrappers.push(...$$('[data-kgdm-repeater]', scope || editor));
        wrappers.forEach((wrapper) => {
            if (wrapper.dataset.hydrated === '1') return;
            wrapper.dataset.hydrated = '1';
            const saved = getPath(record, wrapper.dataset.keyPath || '');
            if (!Array.isArray(saved)) { updateRepeaterControls(wrapper); return; }
            saved.forEach((entry, index) => {
                const row = addRepeaterRow(wrapper, index);
                if (row) {
                    row.dataset.originalRow = JSON.stringify(entry && typeof entry === 'object' ? entry : {});
                    hydrateRepeaters(row, record);
                }
            });
            updateRepeaterControls(wrapper);
        });
    }
    function clearRepeaterRows(scope) {
        $$('[data-kgdm-repeater]', scope || editor).forEach((wrapper) => {
            const items = $('.kgdm-repeater-items', wrapper);
            if (items) items.replaceChildren();
            delete wrapper.dataset.hydrated;
            updateRepeaterControls(wrapper);
        });
    }
    if (editor) {
        editor.addEventListener('click', (event) => {
            const choose = event.target.closest('.kgdm-select-media');
            const removeMedia = event.target.closest('.kgdm-remove-media');
            const addRow = event.target.closest('.kgdm-add-repeater-row');
            const removeRow = event.target.closest('.kgdm-remove-repeater-row');
            if (choose) chooseMedia(choose.closest('.kgdm-media-field'));
            if (removeMedia) {
                const field = removeMedia.closest('.kgdm-media-field');
                const input = $('.kgdm-media-value', field);
                input.value = field.dataset.mediaType === 'gallery' ? '[]' : '';
                syncMediaField(field);
            }
            if (addRow) {
                const wrapper = addRow.closest('[data-kgdm-repeater]');
                const items = $('.kgdm-repeater-items', wrapper);
                const count = directRepeaterRows(items).length;
                if (count < Number(wrapper.dataset.maxItems || 100)) {
                    const row = addRepeaterRow(wrapper, count);
                    if (row) hydrateRepeaters(row, {});
                    syncTemplateVisibility();
                }
            }
            if (removeRow) {
                const row = removeRow.closest('.kgdm-repeater-row');
                const wrapper = removeRow.closest('[data-kgdm-repeater]');
                if (row) row.remove();
                if (wrapper) reindexRepeaterRows(wrapper);
                syncTemplateVisibility();
            }
        });
    }

    function selectedTemplate() {
        if (!templateSelect || !templateSelect.value) return null;
        return templateSelect.options[templateSelect.selectedIndex] || null;
    }
    function deletePath(object, path) {
        const parts = String(path).split('.');
        if (!parts.length) return;
        let target = object;
        for (let index = 0; index < parts.length - 1; index++) {
            if (!target || typeof target !== 'object') return;
            target = target[parts[index]];
        }
        if (target && typeof target === 'object') delete target[parts[parts.length - 1]];
    }
    function isEmptyFormValue(value) {
        if (value === undefined || value === null || value === '') return true;
        if (Array.isArray(value)) return value.length === 0 || value.every(isEmptyFormValue);
        if (typeof value === 'object') return Object.keys(value).length === 0 || Object.values(value).every(isEmptyFormValue);
        return false; // false and 0 are valid stored values.
    }
    function ensureRepeaterValues(record) {
        const wrappers = $$('[data-kgdm-repeater]', editor).sort((a, b) => (a.dataset.keyPath || '').split('.').length - (b.dataset.keyPath || '').split('.').length);
        wrappers.forEach((wrapper) => {
            const path = wrapper.dataset.keyPath || '';
            if (!path) return;
            let rowsValue = getPath(record, path);
            if (!Array.isArray(rowsValue)) {
                rowsValue = [];
                setPath(record, path, rowsValue);
            }
            const items = $('.kgdm-repeater-items', wrapper);
            const rows = directRepeaterRows(items);
            rows.forEach((row, index) => {
                if (!rowsValue[index] || typeof rowsValue[index] !== 'object' || Array.isArray(rowsValue[index])) {
                    rowsValue[index] = {};
                }
            });
        });
    }
    function stripEmptyOptionalGroups(record) {
        const groups = $$('.kgdm-record-group[data-key-path]', editor).sort((a, b) => (b.dataset.keyPath || '').split('.').length - (a.dataset.keyPath || '').split('.').length);
        groups.forEach((wrapper) => {
            if (wrapper.closest('.kgdm-record-group[hidden],.kgdm-record-repeater[hidden]')) return;
            if (wrapper.dataset.required === '1') return;
            const path = wrapper.dataset.keyPath || '';
            const value = getPath(record, path);
            if (value && typeof value === 'object' && !Array.isArray(value) && isEmptyFormValue(value)) deletePath(record, path);
        });
    }
    function currentFormRecord() {
        const record = {};
        $$('.kgdm-record-value', editor).forEach((input) => {
            try { setPath(record, input.dataset.key, getInputValue(input)); }
            catch (error) { setPath(record, input.dataset.key, input.value); }
        });
        ensureRepeaterValues(record);
        stripEmptyOptionalGroups(record);
        return record;
    }
    function collectRepeaterValue(wrapper) {
        const items = $('.kgdm-repeater-items', wrapper);
        if (!items) return [];
        const base = wrapper.dataset.keyPath || '';
        return directRepeaterRows(items).map((row) => {
            let rowValue = {};
            try {
                const original = JSON.parse(row.dataset.originalRow || '{}');
                if (original && typeof original === 'object' && !Array.isArray(original)) rowValue = original;
            } catch (error) { rowValue = {}; }
            const prefix = base + '.' + row.dataset.index + '.';
            $$('.kgdm-record-value', row).forEach((input) => {
                if (input.closest('[data-kgdm-repeater]') !== wrapper) return;
                const key = input.dataset.key || '';
                if (!key.startsWith(prefix)) return;
                try { setPath(rowValue, key.slice(prefix.length), getInputValue(input)); }
                catch (error) { setPath(rowValue, key.slice(prefix.length), input.value); }
            });
            $$('[data-kgdm-repeater]', row).forEach((nested) => {
                if (!nested.parentElement || nested.parentElement.closest('[data-kgdm-repeater]') !== wrapper) return;
                const nestedPath = nested.dataset.keyPath || '';
                if (!nestedPath.startsWith(prefix)) return;
                setPath(rowValue, nestedPath.slice(prefix.length), collectRepeaterValue(nested));
            });
            return rowValue;
        });
    }
    function applyGeneratedFields(record) {
        $$('.kgdm-record-value', editor).forEach((input) => {
            if (input.closest('[data-kgdm-repeater]')) return;
            try { setPath(record, input.dataset.key, getInputValue(input)); }
            catch (error) { setPath(record, input.dataset.key, input.value); }
        });
        const topRepeaters = $$('[data-kgdm-repeater]', editor).filter((wrapper) => !wrapper.parentElement || !wrapper.parentElement.closest('[data-kgdm-repeater]'));
        topRepeaters.forEach((wrapper) => setPath(record, wrapper.dataset.keyPath, collectRepeaterValue(wrapper)));
        stripEmptyOptionalGroups(record);
    }
    function conditionMatches(condition, wrapper, record) {
        if (!condition || !condition.field) return true;
        let actual;
        const dependency = String(condition.field);
        const parentPath = wrapper.dataset.parentPath || '';
        if (parentPath) {
            actual = getPath(record, parentPath + '.' + dependency);
            if (actual === undefined) actual = getPath(record, dependency);
        } else {
            actual = getPath(record, dependency);
        }
        const present = !(actual === undefined || actual === null || actual === '');
        const expected = String(condition.value ?? '');
        switch (condition.operator || 'equals') {
            case 'not_equals': return !present || (Array.isArray(actual) ? !actual.map(String).includes(expected) : String(actual) !== expected);
            case 'contains': return Array.isArray(actual) ? actual.map(String).includes(expected) : (present && String(actual).toLowerCase().includes(expected.toLowerCase()));
            case 'not_contains': return Array.isArray(actual) ? !actual.map(String).includes(expected) : (!present || !String(actual).toLowerCase().includes(expected.toLowerCase()));
            case 'is_checked': return actual === true || actual === 1 || actual === '1' || actual === 'true';
            case 'is_not_empty': return present && !(Array.isArray(actual) && !actual.length) && !(typeof actual === 'object' && !Array.isArray(actual) && !Object.keys(actual).length);
            case 'is_empty': return !present || (Array.isArray(actual) && !actual.length) || (typeof actual === 'object' && !Array.isArray(actual) && !Object.keys(actual).length);
            case 'equals':
            default: return present && (Array.isArray(actual) ? actual.map(String).includes(expected) : String(actual) === expected);
        }
    }
    function visibleForTemplate(wrapper) {
        const option = selectedTemplate();
        let visible = [];
        if (option) {
            try { visible = JSON.parse(option.dataset.visible || '[]'); } catch (error) { visible = []; }
        }
        return !option || !visible.length || visible.includes(wrapper.dataset.topKey || '');
    }
    function syncTemplateVisibility() {
        if (!editor) return;
        const option = selectedTemplate();
        let visible = [];
        if (option) { try { visible = JSON.parse(option.dataset.visible || '[]'); } catch (error) { visible = []; } }
        const record = currentFormRecord();
        $$('.kgdm-record-field-wrap[data-kgdm-field]', editor).forEach((wrapper) => {
            let show = !option || !visible.length || visible.includes(wrapper.dataset.topKey || '');
            if (show && wrapper.dataset.showIf) {
                try { show = conditionMatches(JSON.parse(wrapper.dataset.showIf), wrapper, record); }
                catch (error) { show = true; }
            }
            wrapper.hidden = !show;
            const input = $('.kgdm-record-value', wrapper);
            if (input) input.required = false;
        });
    }
    function validateDynamicRequired(record) {
        const option = selectedTemplate();
        let requiredOverride = [];
        if (option) { try { requiredOverride = JSON.parse(option.dataset.required || '[]'); } catch (error) { requiredOverride = []; } }
        const errors = [];
        $$('.kgdm-record-field-wrap[data-kgdm-field]', editor).forEach((wrapper) => {
            if (!visibleForTemplate(wrapper)) return;
            if (wrapper.dataset.showIf) {
                try { if (!conditionMatches(JSON.parse(wrapper.dataset.showIf), wrapper, record)) return; }
                catch (error) { /* Server validation remains authoritative. */ }
            }
            if (wrapper.closest('.kgdm-record-group[hidden],.kgdm-record-repeater[hidden]')) return;
            const parentGroup = wrapper.parentElement ? wrapper.parentElement.closest('.kgdm-record-group') : null;
            if (parentGroup) {
                const groupValue = getPath(record, parentGroup.dataset.keyPath || '');
                if (!groupValue || typeof groupValue !== 'object' || !Object.keys(groupValue).length) return;
            }
            const keyPath = wrapper.dataset.keyPath || '';
            const isTemplateRequired = (keyPath === wrapper.dataset.topKey) && requiredOverride.includes(wrapper.dataset.topKey || '');
            if (wrapper.dataset.required !== '1' && !isTemplateRequired) return;
            const type = wrapper.dataset.fieldType || '';
            const value = getPath(record, keyPath);
            const empty = type === 'group'
                ? isEmptyFormValue(value)
                : (value === undefined || value === null || value === '' || (Array.isArray(value) && value.length === 0) || (typeof value === 'object' && !Array.isArray(value) && Object.keys(value).length === 0));
            if (type === 'boolean') return; // false is a valid boolean value.
            if (type === 'image') {
                if (!Number(value || 0)) errors.push(wrapper.querySelector('legend, .kgdm-field-label')?.textContent.replace('*','').trim() || keyPath);
                return;
            }
            if (type === 'gallery' || type === 'repeater') {
                if (!Array.isArray(value) || !value.length) errors.push(wrapper.querySelector('legend, .kgdm-field-label')?.textContent.replace('*','').trim() || keyPath);
                return;
            }
            if (empty) errors.push(wrapper.querySelector('legend, label')?.childNodes?.[0]?.textContent.trim() || keyPath);
        });
        if (errors.length) throw new Error('Complete the required fields: ' + errors.join(', '));
    }
    if (editor) {
        editor.addEventListener('input', syncTemplateVisibility);
        editor.addEventListener('change', syncTemplateVisibility);
    }

    function hydrateRepeaterDefaults(defaults, scope = editor) {
        const wrappers = [];
        if (scope && scope.matches && scope.matches('[data-kgdm-repeater]')) wrappers.push(scope);
        wrappers.push(...$$('[data-kgdm-repeater]', scope || editor));
        wrappers.forEach((wrapper) => {
            const path = wrapper.dataset.keyPath || '';
            const desired = getPath(defaults, path);
            const items = $('.kgdm-repeater-items', wrapper);
            if (!Array.isArray(desired) || !desired.length || !items || directRepeaterRows(items).length) return;
            delete wrapper.dataset.hydrated;
            wrapper.dataset.hydrated = '1';
            desired.forEach((entry, index) => {
                const row = addRepeaterRow(wrapper, index);
                if (row) {
                    row.dataset.originalRow = JSON.stringify(entry && typeof entry === 'object' ? entry : {});
                    hydrateRepeaterDefaults(defaults, row);
                }
            });
            updateRepeaterControls(wrapper);
        });
    }
    function applyTemplateDefaults() {
        const option = selectedTemplate();
        if (!option) { syncTemplateVisibility(); return; }
        let defaults = {};
        try { defaults = JSON.parse(option.dataset.defaults || '{}'); }
        catch (error) { window.alert('This template contains invalid default JSON.'); return; }
        hydrateRepeaterDefaults(defaults);
        $$('.kgdm-record-value', editor).forEach((input) => {
            const value = getPath(defaults, input.dataset.key);
            if (value === undefined) return;
            const current = getInputValue(input);
            const empty = current === '' || current === null || (Array.isArray(current) && current.length === 0) || (current && typeof current === 'object' && !Array.isArray(current) && Object.keys(current).length === 0);
            if (empty) setInputValue(input, value);
            if (input.classList.contains('kgdm-media-value')) syncMediaField(input.closest('.kgdm-media-field'));
        });
        const knownRoots = new Set($$('.kgdm-record-field-wrap[data-top-key]', editor).map((node) => node.dataset.topKey));
        const extras = {};
        Object.keys(defaults).forEach((key) => { if (!knownRoots.has(key)) extras[key] = defaults[key]; });
        if (Object.keys(extras).length) {
            const currentExtras = parseObject($('#kgdm-advanced-json').value, 'Additional JSON data');
            Object.assign(currentExtras, extras);
            $('#kgdm-advanced-json').value = JSON.stringify(currentExtras, null, 2);
        }
        syncTemplateVisibility();
    }
    if (templateSelect) templateSelect.addEventListener('change', applyTemplateDefaults);

    async function api(operation, data = {}) {
        if (!cfg) throw new Error('Record actions are not available on this screen.');
        const body = new FormData();
        body.append('action', 'kgdm_record_ajax');
        body.append('nonce', cfg.dataset.nonce);
        body.append('database_id', cfg.dataset.db);
        body.append('collection_slug', cfg.dataset.collection);
        body.append('operation', operation);
        Object.keys(data).forEach((key) => body.append(key, data[key]));
        const response = await fetch(cfg.dataset.url, { method: 'POST', credentials: 'same-origin', body });
        let json;
        try { json = await response.json(); }
        catch (error) { throw new Error('The server returned an invalid response.'); }
        if (!response.ok || !json.success) throw new Error((json.data && json.data.message) || 'The request failed.');
        return json.data;
    }

    function openEditor(record = { id: '' }) {
        if (!editor) return;
        record = record && typeof record === 'object' && !Array.isArray(record) ? record : { id: '' };
        if (!record.id && recordForm && recordForm.dataset.defaultRecord) {
            try { record = Object.assign(JSON.parse(recordForm.dataset.defaultRecord), record); }
            catch (error) { /* Fall back to the supplied record if defaults cannot be decoded. */ }
        }
        $('#kgdm-editor-title').textContent = record.id ? 'Edit record' : 'Add record';
        $('#kgdm-original-id').value = record.id || '';
        $('#kgdm-record-id').value = record.id || '';
        editor.dataset.originalRecord = JSON.stringify(record || {});
        const assignedSections = Array.isArray(record._kgdm_sections) ? record._kgdm_sections : [];
        $$('.kgdm-record-section-checkbox', editor).forEach((input) => { input.checked = assignedSections.includes(input.value); });
        const publication = record._kgdm_publication && typeof record._kgdm_publication === 'object' ? record._kgdm_publication : {};
        const visibilityInput = $('#kgdm-record-visibility', editor); if (visibilityInput) visibilityInput.value = publication.visibility === 'private' ? 'private' : 'public';
        const publishInput = $('#kgdm-record-publish-at', editor); if (publishInput) publishInput.value = String(publication.publish_at || '').replace(' ', 'T').slice(0,16);
        const hideInput = $('#kgdm-record-hide-at', editor); if (hideInput) hideInput.value = String(publication.hide_at || '').replace(' ', 'T').slice(0,16);
        clearRepeaterRows(editor);
        if (templateSelect) templateSelect.value = record._kgdm_template || '';
        hydrateRepeaters(editor, record || {});
        const knownRoots = new Set();
        $$('.kgdm-record-field-wrap[data-top-key]', editor).forEach((wrapper) => knownRoots.add(wrapper.dataset.topKey));
        $$('.kgdm-record-value', editor).forEach((input) => {
            const value = getPath(record, input.dataset.key);
            setInputValue(input, value);
            if (input.classList.contains('kgdm-media-value')) syncMediaField(input.closest('.kgdm-media-field'));
        });
        const extra = {};
        Object.keys(record).forEach((key) => {
            if (!knownRoots.has(key) && !['id', '_kgdm_template', '_kgdm_template_version', '_kgdm_sections', '_kgdm_publication'].includes(key)) extra[key] = record[key];
        });
        $('#kgdm-advanced-json').value = JSON.stringify(extra, null, 2);
        const templateId = $('#kgdm-record-template-id');
        if (templateId) templateId.value = record._kgdm_template || '';
        syncTemplateVisibility();
        editor.hidden = false;
        editor.scrollIntoView({ behavior: 'smooth', block: 'start' });
        $('#kgdm-record-id').focus();
        message('', false);
    }

    const addRecord = $('#kgdm-add-record');
    if (addRecord) addRecord.addEventListener('click', () => openEditor({ id: '' }));
    ['#kgdm-cancel-record'].forEach((selector) => {
        const button = $(selector);
        if (button) button.addEventListener('click', () => { editor.hidden = true; });
    });

    async function editRecord(button) {
        try {
            button.disabled = true;
            const response = await api('get', { record_id: button.dataset.id });
            openEditor(response.record);
        } catch (error) { window.alert(error.message); }
        finally { button.disabled = false; }
    }
    $$('.kgdm-edit-record').forEach((button) => button.addEventListener('click', () => editRecord(button)));

    // Completeness deep links open the selected record directly, even when it is on another records page.
    const deepLinkParams = new URLSearchParams(window.location.search);
    const deepLinkRecordId = deepLinkParams.get('record');
    if (deepLinkRecordId && cfg && cfg.dataset.deleted !== '1') {
        window.setTimeout(async () => {
            try {
                const visibleButton = $$('.kgdm-edit-record').find((button) => button.dataset.id === deepLinkRecordId);
                if (visibleButton) {
                    await editRecord(visibleButton);
                } else {
                    const response = await api('get', { record_id: deepLinkRecordId });
                    if (!response || !response.record) throw new Error('This record could not be loaded. It may have been moved or deleted.');
                    openEditor(response.record);
                }
                const cleanUrl = new URL(window.location.href);
                cleanUrl.searchParams.delete('record');
                window.history.replaceState({}, document.title, cleanUrl.toString());
                message('Opened from the completeness review.', false);
            } catch (error) {
                message(error.message || 'The selected record could not be opened.', true);
            }
        }, 80);
    }

    function getRowImageValue(record, key, type) {
        const value = getPath(record, key);
        if (type === 'gallery') return Array.isArray(value) ? Number(value[0] || 0) : 0;
        return Number(value || 0);
    }
    function addOrUpdateRow(record, completeness = null, publicationState = null) {
        const tbody = $('#kgdm-record-rows');
        if (!tbody) return;
        const id = record.id;
        let row = $$('[data-kgdm-record-row]', tbody).find((candidate) => candidate.dataset.id === id);
        if (!row) { row = document.createElement('tr'); row.dataset.kgdmRecordRow = ''; tbody.prepend(row); }
        const name = record.name || record.title || record.label || id;
        const sectionTerms = (() => { try { return JSON.parse(tbody.dataset.sections || '[]'); } catch (error) { return []; } })();
        const sectionMap = new Map(sectionTerms.map((term) => [term.slug, term.path || term.name || term.slug]));
        const assigned = Array.isArray(record._kgdm_sections) ? record._kgdm_sections : [];
        const sectionNames = assigned.map((slug) => sectionMap.get(slug)).filter(Boolean);
        const publication = record._kgdm_publication && typeof record._kgdm_publication === 'object' ? record._kgdm_publication : {};
        let visibility = ['public','private','scheduled','hidden'].includes(publicationState) ? publicationState : (publication.visibility === 'private' ? 'private' : 'public');
        if (!['public','private','scheduled','hidden'].includes(publicationState)) {
            const now = new Date();
            const parseLocal = (value) => value ? new Date(String(value).replace(' ', 'T')) : null;
            const publishAt = parseLocal(publication.publish_at);
            const hideAt = parseLocal(publication.hide_at);
            if (visibility === 'public' && publishAt && publishAt > now) visibility = 'scheduled';
            else if (visibility === 'public' && hideAt && hideAt <= now) visibility = 'hidden';
        }
        row.dataset.id = id;
        row.dataset.name = name;
        row.dataset.sections = assigned.join(',');
        row.dataset.visibility = visibility;
        row.dataset.search = (id + ' ' + name + ' ' + JSON.stringify(record)).toLowerCase();
        row.replaceChildren();
        const selectCell = row.insertCell();
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox'; checkbox.className = 'kgdm-record-select'; checkbox.name = 'record_ids[]'; checkbox.value = id;
        checkbox.setAttribute('form', 'kgdm-bulk-records-form'); checkbox.setAttribute('aria-label', 'Select ' + name);
        selectCell.appendChild(checkbox);
        const thumbCell = row.insertCell();
        thumbCell.className = 'kgdm-thumb-cell';
        const imageKey = tbody.dataset.imageKey || '';
        const imageType = tbody.dataset.imageType || '';
        const imageId = getRowImageValue(record, imageKey, imageType);
        if (imageId && window.wp && wp.media) {
            wp.media.attachment(imageId).fetch().done(() => {
                const data = wp.media.attachment(imageId).toJSON();
                const image = document.createElement('img');
                image.className = 'kgdm-record-thumb'; image.width = 48; image.height = 48;
                image.loading = 'lazy'; image.decoding = 'async';
                const imageUrl = safeImageUrl((data.sizes && data.sizes.thumbnail && data.sizes.thumbnail.url) || data.url);
                if (!imageUrl) { thumbCell.replaceChildren(makeImagePlaceholder('kgdm-record-thumb-placeholder', 'No profile image')); return; }
                image.src = imageUrl; image.alt = typeof data.alt === 'string' ? data.alt : '';
                thumbCell.replaceChildren(image);
            });
        } else { thumbCell.replaceChildren(makeImagePlaceholder('kgdm-record-thumb-placeholder', 'No profile image')); }
        const nameCell = row.insertCell(); const strong = document.createElement('strong'); strong.className = 'kgdm-row-name'; strong.textContent = name; nameCell.appendChild(strong);
        const idCell = row.insertCell(); const code = document.createElement('code'); code.textContent = id; idCell.appendChild(code);
        const sectionsCell = row.insertCell(); sectionsCell.textContent = sectionNames.length ? sectionNames.join(', ') : 'Unassigned';
        const visibilityCell = row.insertCell(); const visibilityBadge = document.createElement('span'); visibilityBadge.className = 'kgdm-visibility-pill kgdm-visibility-' + visibility; visibilityBadge.textContent = visibility.charAt(0).toUpperCase() + visibility.slice(1); visibilityCell.appendChild(visibilityBadge);
        const originCell = row.insertCell(); originCell.textContent = 'Website database';
        const completenessCell = row.insertCell(); const completenessBadge = document.createElement('span');
        completenessBadge.className = 'kgdm-completeness kgdm-completeness-' + ((completeness && completeness.state) || 'unknown');
        completenessBadge.textContent = (completeness && completeness.label) || 'Saved'; completenessCell.appendChild(completenessBadge);
        const actionCell = row.insertCell(); actionCell.className = 'kgdm-actions';
        const edit = document.createElement('button'); edit.type = 'button'; edit.className = 'button kgdm-edit-record'; edit.dataset.id = id; edit.textContent = 'Edit'; edit.addEventListener('click', () => editRecord(edit));
        const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'button-link-delete kgdm-delete-record'; remove.dataset.id = id; remove.textContent = 'Move to Trash'; remove.addEventListener('click', () => deleteRecord(remove));
        actionCell.append(edit, document.createTextNode(' '), remove);
        const empty = $('.kgdm-empty-row', tbody); if (empty) empty.remove();
        applyRecordListFilters();
    }

    async function deleteRecord(button) {
        if (!window.confirm('Move this record to Trash? It can be restored.')) return;
        try {
            button.disabled = true;
            const response = await api('delete', { record_id: button.dataset.id });
            const row = button.closest('tr'); if (row) row.remove();
            message(response.message || 'Record moved to Deleted records.', false);
        } catch (error) { window.alert(error.message); button.disabled = false; }
    }
    $$('.kgdm-delete-record').forEach((button) => button.addEventListener('click', () => deleteRecord(button)));
    $$('.kgdm-restore-record').forEach((button) => button.addEventListener('click', async () => {
        try {
            button.disabled = true;
            const response = await api('restore', { record_id: button.dataset.id });
            const row = button.closest('tr'); if (row) row.remove();
            message(response.message || 'Record restored.', false);
        } catch (error) { window.alert(error.message); button.disabled = false; }
    }));

    if (recordForm) recordForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        const save = $('#kgdm-save-record');
        save.disabled = true;
        message('Saving…', false);
        try {
            const original = $('#kgdm-original-id').value;
            let record = {};
            try { record = JSON.parse(editor.dataset.originalRecord || '{}'); }
            catch (error) { record = {}; }
            if (!record || typeof record !== 'object' || Array.isArray(record)) record = {};
            applyGeneratedFields(record);
            const extras = parseObject($('#kgdm-advanced-json').value, 'Legacy / additional JSON data');
            const knownRoots = new Set($$('.kgdm-record-field-wrap[data-top-key]', editor).map((node) => node.dataset.topKey));
            Object.keys(record).forEach((key) => {
                if (!knownRoots.has(key) && !['id', '_kgdm_template', '_kgdm_template_version', '_kgdm_sections', '_kgdm_publication'].includes(key)) delete record[key];
            });
            Object.keys(extras).forEach((key) => { record[key] = extras[key]; });
            record.id = $('#kgdm-record-id').value.trim();
            const currentTemplate = templateSelect ? templateSelect.value : '';
            if (currentTemplate) record._kgdm_template = currentTemplate;
            else delete record._kgdm_template;
            record._kgdm_sections = $$('.kgdm-record-section-checkbox:checked', editor).map((input) => input.value);
            const visibility = $('#kgdm-record-visibility', editor);
            const publishAt = $('#kgdm-record-publish-at', editor);
            const hideAt = $('#kgdm-record-hide-at', editor);
            const publishValue = publishAt && publishAt.value ? publishAt.value.replace('T', ' ') + ':00' : '';
            const hideValue = hideAt && hideAt.value ? hideAt.value.replace('T', ' ') + ':00' : '';
            if (publishValue && hideValue && hideValue <= publishValue) throw new Error('The Hide after date must be later than the Show from date.');
            record._kgdm_publication = { visibility: visibility && visibility.value === 'private' ? 'private' : 'public', publish_at: publishValue, hide_at: hideValue };
            validateDynamicRequired(record);
            const response = await api('save', { record_json: JSON.stringify(record), original_record_id: original });
            if (original && original !== response.id) {
                const oldRow = $$('[data-kgdm-record-row]').find((candidate) => candidate.dataset.id === original);
                if (oldRow) oldRow.remove();
            }
            addOrUpdateRow(response.record, response.completeness, response.publication_state || null);
            editor.hidden = true;
            message(response.message || 'Record saved.', false);
            recordForm.reset();
        } catch (error) { message(error.message, true); }
        finally { save.disabled = false; }
    });

    const search = $('#kgdm-record-search');
    const sectionFilter = $('#kgdm-record-section-filter');
    function applyRecordListFilters() {
        const query = String(search ? search.value : '').trim().toLowerCase();
        const selectedSection = sectionFilter ? sectionFilter.value : 'all';
        let visible = 0;
        $$('[data-kgdm-record-row]').forEach((row) => {
            const matchesSearch = !query || String(row.dataset.search || '').includes(query);
            const sections = String(row.dataset.sections || '').split(',').filter(Boolean);
            const matchesSection = selectedSection === 'all' || (selectedSection === 'unassigned' ? sections.length === 0 : sections.includes(selectedSection));
            row.hidden = !(matchesSearch && matchesSection);
            if (row.hidden) {
                // Never let a filtered-out row remain selected for a bulk edit.
                const rowCheckbox = $('.kgdm-record-select', row);
                if (rowCheckbox) rowCheckbox.checked = false;
            } else {
                visible++;
            }
        });
        const noResults = $('.kgdm-no-search-results');
        if (noResults) noResults.hidden = visible !== 0;
        const selectAll = $('#kgdm-select-all-records');
        if (selectAll) selectAll.checked = false;
    }
    if (search) search.addEventListener('input', applyRecordListFilters);
    if (sectionFilter) sectionFilter.addEventListener('change', applyRecordListFilters);
    const selectAllRecords = $('#kgdm-select-all-records');
    if (selectAllRecords) selectAllRecords.addEventListener('change', () => {
        $$('[data-kgdm-record-row]').forEach((row) => {
            const checkbox = $('.kgdm-record-select', row);
            if (checkbox && !row.hidden) checkbox.checked = selectAllRecords.checked;
        });
    });
    applyRecordListFilters();

    // Copy PHP examples without adding a dependency.
    $$('.kgdm-copy-code').forEach((button) => button.addEventListener('click', async () => {
        const pre = $('pre', button.parentElement);
        if (!pre) return;
        try {
            if (navigator.clipboard && navigator.clipboard.writeText) await navigator.clipboard.writeText(pre.textContent);
            else {
                const area = document.createElement('textarea');
                area.value = pre.textContent; area.style.position = 'fixed'; area.style.opacity = '0';
                document.body.appendChild(area); area.select(); document.execCommand('copy'); area.remove();
            }
            const original = button.textContent; button.textContent = 'Copied';
            window.setTimeout(() => { button.textContent = original; }, 1400);
        } catch (error) { button.textContent = 'Select code to copy'; }
    }));

    // Lightweight client-side import preflight; server-side validation remains authoritative.
    const validateJsonButton = $('#kgdm-validate-json');
    const importJsonField = $('#kgdm-import-json');
    const importFileField = $('#kgdm-import-form input[type="file"]');
    const importJsonMessage = $('#kgdm-json-validation');
    function validateImportDocument(documentData) {
        if (!documentData || typeof documentData !== 'object' || Array.isArray(documentData)) throw new Error('Top-level JSON value must be an object.');
        const version = Number(documentData.format_version);
        if (!((documentData.format === 'kgdm-database' && version === 1) || (documentData.format === 'kumar-database-manager' && version === 2))) throw new Error('Unsupported backup format.');
        if (!documentData.database || typeof documentData.database !== 'object' || !documentData.database.name) throw new Error('The database object needs a name.');
        if (!Array.isArray(documentData.collections) && (!documentData.collections || typeof documentData.collections !== 'object')) throw new Error('Collections must be an array or object.');
        const collections = Array.isArray(documentData.collections) ? documentData.collections : Object.values(documentData.collections);
        const collectionIds = new Set();
        let records = 0;
        collections.forEach((collection, index) => {
            if (!collection || typeof collection !== 'object' || Array.isArray(collection)) throw new Error('Collection ' + (index + 1) + ' must be an object.');
            const slug = String(collection.slug || collection.id || '');
            if (!slug || collectionIds.has(slug)) throw new Error('Missing or duplicate collection ID: ' + slug);
            collectionIds.add(slug);
            const fields = collection.schema || collection.fields || [];
            if (!Array.isArray(fields)) throw new Error('Fields for ' + slug + ' must be an array.');
            const rows = collection.records || [];
            const list = Array.isArray(rows) ? rows : (rows && typeof rows === 'object' ? Object.values(rows) : null);
            if (!list) throw new Error('Records for ' + slug + ' must be an array or object.');
            const ids = new Set();
            list.forEach((entry) => {
                const record = entry && entry.record ? entry.record : entry;
                if (!record || typeof record !== 'object' || Array.isArray(record) || !record.id) throw new Error('Every record in ' + slug + ' needs an ID.');
                if (ids.has(String(record.id))) throw new Error('Duplicate record ID in ' + slug + ': ' + record.id);
                ids.add(String(record.id)); records++;
            });
        });
        return { collections: collections.length, records };
    }
    async function readImportJson() {
        const pasted = importJsonField && importJsonField.value.trim();
        if (pasted) return pasted;
        const file = importFileField && importFileField.files && importFileField.files[0];
        if (!file) throw new Error('Paste JSON or choose a JSON file first.');
        if (file.size > 26214400) throw new Error('The file exceeds the 25 MB limit.');
        return file.text();
    }
    if (validateJsonButton) validateJsonButton.addEventListener('click', async () => {
        validateJsonButton.disabled = true;
        if (importJsonMessage) { importJsonMessage.textContent = 'Checking JSON…'; importJsonMessage.className = 'kgdm-muted'; }
        try {
            const raw = await readImportJson();
            const summary = validateImportDocument(JSON.parse(raw));
            if (importJsonMessage) {
                importJsonMessage.textContent = 'Structure looks valid: ' + summary.collections + ' collections and ' + summary.records + ' records. Server validation will run again before import.';
                importJsonMessage.className = 'kgdm-json-validation-good';
            }
        } catch (error) {
            if (importJsonMessage) { importJsonMessage.textContent = error.message; importJsonMessage.className = 'kgdm-json-validation-bad'; }
        } finally { validateJsonButton.disabled = false; }
    });
})();

// Completeness checker: client-side filtering only; the audit itself is server-generated.
(function initCompletenessChecker() {
    const $ = (selector, root = document) => root.querySelector(selector);
    const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
    const select = $('#kgdm-completeness-collection');
    if (select) {
        select.addEventListener('change', () => {
            const url = new URL(window.location.href);
            url.searchParams.set('tab', 'completeness');
            url.searchParams.set('collection', select.value);
            window.location.href = url.toString();
        });
    }
    const rows = $$('#kgdm-completeness-rows [data-completeness-row]');
    const search = $('#kgdm-completeness-search');
    const empty = $('#kgdm-completeness-empty');
    let filter = 'all';
    function apply() {
        const query = String(search ? search.value : '').trim().toLowerCase();
        let visible = 0;
        rows.forEach((row) => {
            const matchesState = filter === 'all' || row.dataset.state === filter;
            const matchesSearch = !query || String(row.dataset.search || '').includes(query);
            row.hidden = !(matchesState && matchesSearch);
            if (!row.hidden) visible++;
        });
        if (empty) empty.hidden = visible !== 0;
    }
    $$('.kgdm-completeness-filters [data-completeness-filter]').forEach((button) => {
        button.addEventListener('click', () => {
            filter = button.dataset.completenessFilter || 'all';
            $$('.kgdm-completeness-filters [data-completeness-filter]').forEach((candidate) => candidate.classList.toggle('button-primary', candidate === button));
            apply();
        });
    });
    if (search) search.addEventListener('input', apply);
    apply();

    const trashSearch = document.getElementById('kgdm-trash-search');
    if (trashSearch) {
        trashSearch.addEventListener('input', () => {
            const term = (trashSearch.value || '').trim().toLocaleLowerCase();
            const affectedTypes = new Set();
            document.querySelectorAll('[data-kgdm-trash-row]').forEach((row) => {
                const haystack = (row.dataset.search || row.textContent || '').toLocaleLowerCase();
                row.hidden = term !== '' && !haystack.includes(term);
                if (row.hidden) {
                    const selection = row.querySelector('[data-trash-select-item]');
                    if (selection) {
                        selection.checked = false;
                        affectedTypes.add(selection.getAttribute('data-trash-select-item'));
                    }
                }
            });
            affectedTypes.forEach((type) => updateTrashSelection(type));
        });
    }
})();


// 3.2.16 — live preview of Light / Dark / System appearance selection.
document.addEventListener('change', function (event) {
    var target = event.target;
    if (!target || !target.matches || !target.matches('input[name="appearance_mode"]')) return;
    var root = document.querySelector('.kgdm-wrap');
    if (!root) return;
    root.classList.remove('kgdm-theme-system', 'kgdm-theme-light', 'kgdm-theme-dark');
    var mode = ['system', 'light', 'dark'].indexOf(target.value) !== -1 ? target.value : 'system';
    root.classList.add('kgdm-theme-' + mode);
    var cards = document.querySelectorAll('.kgdm-theme-option');
    cards.forEach(function (card) {
        var radio = card.querySelector('input[name="appearance_mode"]');
        card.classList.toggle('is-selected', !!(radio && radio.checked));
    });
});


// Database appearance media selection uses the native WordPress Media Library.
document.addEventListener('click', function (event) {
    const choose = event.target.closest('.kgdm-visual-media-choose');
    const clear = event.target.closest('.kgdm-visual-media-clear');
    const control = choose || clear;
    if (!control) return;
    const selector = control.getAttribute('data-target');
    const input = selector ? document.querySelector(selector) : null;
    if (!input) return;
    const preview = input.parentElement.querySelector('.kgdm-visual-media-preview');
    if (clear) {
        input.value = '0';
        if (preview) {
            const placeholder = document.createElement('span');
            placeholder.className = 'kgdm-visual-placeholder';
            placeholder.textContent = preview.dataset.empty || 'No image selected';
            preview.replaceChildren(placeholder);
        }
        return;
    }
    if (!window.wp || !wp.media) { window.alert('The WordPress Media Library is unavailable on this screen.'); return; }
    const frame = wp.media({ title: 'Choose an image', button: { text: 'Use image' }, library: { type: 'image' }, multiple: false });
    frame.on('select', function () {
        const attachment = frame.state().get('selection').first().toJSON();
        if (!attachment || attachment.type !== 'image' || !Number(attachment.id)) return;
        const candidate = (attachment.sizes && attachment.sizes.medium && attachment.sizes.medium.url) || attachment.url || '';
        let safe = '';
        try { const parsed = new URL(candidate, window.location.href); if (parsed.protocol === 'http:' || parsed.protocol === 'https:') safe = parsed.href; } catch (error) { safe = ''; }
        if (!safe) return;
        input.value = String(attachment.id);
        if (preview) {
            const image = document.createElement('img'); image.className = 'kgdm-visual-media-preview-img';
            image.loading = 'lazy'; image.decoding = 'async'; image.src = safe;
            image.alt = typeof attachment.alt === 'string' ? attachment.alt : '';
            preview.replaceChildren(image);
        }
    });
    frame.open();
});


// 3.2.21 — KGDM view-header theme quick toggle (Light / Dark).
(function () {
    'use strict';
    const button = document.getElementById('kgdm-theme-toggle');
    const root = button ? button.closest('.kgdm-wrap') : null;
    if (!button || !root) return;

    const media = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
    const allowed = ['system', 'light', 'dark'];
    let mode = allowed.includes(button.dataset.mode) ? button.dataset.mode : 'system';
    let saving = false;

    const effectiveMode = (value) => value === 'system' ? (media && media.matches ? 'dark' : 'light') : value;
    const paint = (value) => {
        mode = allowed.includes(value) ? value : 'system';
        root.classList.remove('kgdm-theme-system', 'kgdm-theme-light', 'kgdm-theme-dark');
        root.classList.add('kgdm-theme-' + mode);
        button.dataset.mode = mode;
        const current = effectiveMode(mode);
        const sun = button.querySelector('[data-theme-icon="light"]');
        const moon = button.querySelector('[data-theme-icon="dark"]');
        if (sun) sun.hidden = current !== 'light';
        if (moon) moon.hidden = current !== 'dark';
        const nextLabel = current === 'dark' ? 'Switch to light mode' : 'Switch to dark mode';
        button.setAttribute('aria-label', nextLabel);
        button.setAttribute('title', nextLabel);
        button.setAttribute('aria-pressed', current === 'dark' ? 'true' : 'false');
        const sr = button.querySelector('.screen-reader-text');
        if (sr) sr.textContent = nextLabel;
    };

    paint(mode);
    if (media) {
        const onSystemChange = () => { if (mode === 'system') paint('system'); };
        if (typeof media.addEventListener === 'function') media.addEventListener('change', onSystemChange);
        else if (typeof media.addListener === 'function') media.addListener(onSystemChange);
    }

    button.addEventListener('click', async () => {
        if (saving) return;
        const previous = mode;
        const next = effectiveMode(mode) === 'dark' ? 'light' : 'dark';
        const url = button.dataset.ajaxUrl || '';
        const nonce = button.dataset.nonce || '';
        if (!url || !nonce || typeof window.fetch !== 'function') return;
        saving = true;
        button.disabled = true;
        button.classList.add('is-saving');
        paint(next);
        try {
            const body = new URLSearchParams({
                action: 'kgdm_set_appearance',
                nonce: nonce,
                mode: next
            });
            const response = await window.fetch(url, {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                body: body.toString()
            });
            const result = await response.json();
            if (!response.ok || !result || result.success !== true || !result.data || result.data.mode !== next) {
                throw new Error((result && result.data && result.data.message) || 'Could not save appearance preference.');
            }
            paint(next);
        } catch (error) {
            paint(previous);
            button.setAttribute('title', 'Theme was not saved. Please try again.');
        } finally {
            saving = false;
            button.disabled = false;
            button.classList.remove('is-saving');
        }
    });
})();


// 3.2.23 — Trash single/multiple selection and page-scoped bulk controls.
document.addEventListener('change', function (event) {
    const target = event.target;
    if (!target || !target.matches) return;
    if (target.matches('[data-trash-select-all]')) {
        const type = target.getAttribute('data-trash-select-all');
        const items = document.querySelectorAll('[data-trash-select-item="' + type + '"]');
        items.forEach((checkbox) => {
            const row = checkbox.closest('[data-kgdm-trash-row]');
            if (!row || !row.hidden) checkbox.checked = target.checked;
        });
        updateTrashSelection(type);
    } else if (target.matches('[data-trash-select-item]')) {
        updateTrashSelection(target.getAttribute('data-trash-select-item'));
    }
});

function updateTrashSelection(type) {
    const items = Array.from(document.querySelectorAll('[data-trash-select-item="' + type + '"]'));
    const visibleItems = items.filter((checkbox) => {
        const row = checkbox.closest('[data-kgdm-trash-row]');
        return !row || !row.hidden;
    });
    const selected = items.filter((checkbox) => checkbox.checked);
    items.forEach((checkbox) => {
        const row = checkbox.closest('[data-kgdm-trash-row]');
        if (row) row.classList.toggle('is-selected', checkbox.checked);
    });
    const selectAll = document.querySelector('[data-trash-select-all="' + type + '"]');
    const count = document.querySelector('[data-trash-selected-count="' + type + '"]');
    const form = document.querySelector('[data-trash-bulk-form][data-trash-type="' + type + '"]');
    if (selectAll) {
        const visibleSelected = visibleItems.filter((checkbox) => checkbox.checked).length;
        selectAll.checked = visibleItems.length > 0 && visibleSelected === visibleItems.length;
        selectAll.indeterminate = visibleSelected > 0 && visibleSelected < visibleItems.length;
    }
    if (count) count.textContent = selected.length + ' selected';
    if (form) form.querySelectorAll('[data-trash-bulk-button]').forEach((button) => { button.disabled = selected.length === 0; });
}

document.querySelectorAll('[data-trash-bulk-form]').forEach((form) => {
    form.addEventListener('submit', (event) => {
        const submitter = event.submitter;
        if (submitter && submitter.value === 'purge') {
            const selected = form.querySelectorAll('input[name="selected[]"]:checked').length;
            if (!window.confirm('Permanently delete ' + selected + ' selected item(s)? This cannot be undone.')) event.preventDefault();
        }
    });
    updateTrashSelection(form.getAttribute('data-trash-type'));
});
